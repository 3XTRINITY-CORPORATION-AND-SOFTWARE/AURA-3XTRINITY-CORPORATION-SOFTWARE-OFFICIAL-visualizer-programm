# 08_git_monolith.py
import os
from typing import Optional

from 05_rules_engine import Operation
from 06_operation_executor import OperationExecutor, ExecutionContext
from 09_gitignore_profiles import get_gitignore_profile


class GitMonolith:
    def __init__(self, root: str, profile_name: str = "giga_orchestrator"):
        self.root = os.path.abspath(root)
        self.profile_name = profile_name

    def _git_dir_exists(self) -> bool:
        return os.path.isdir(os.path.join(self.root, ".git"))

    def ensure_repo(self) -> None:
        if self._git_dir_exists():
            print("[GIT] Repo already initialized.")
            return

        print("[GIT] Initializing repo...")
        ctx = ExecutionContext(root=self.root, dry_run=False)
        executor = OperationExecutor(ctx)

        git_init_op = Operation(kind="GIT_INIT", args={"path": "."})
        self._ensure_gitignore()
        git_commit_op = Operation(kind="GIT_COMMIT_INITIAL", args={"path": ".", "message": "Initial commit"})

        executor.run_plan([git_init_op, git_commit_op])

    def _ensure_gitignore(self, content: Optional[str] = None) -> None:
        gi_path = os.path.join(self.root, ".gitignore")
        if os.path.exists(gi_path):
            print("[GIT] .gitignore already exists.")
            return

        text = content or get_gitignore_profile(self.profile_name)
        with open(gi_path, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"[GIT] .gitignore created using profile '{self.profile_name}'.")