# AURA CORE

Installable analog 44.1 music visualizer.

Original fundamentals stay dry. An analog mirror sits beside them. Sample rate and bit format do not change.

## What it is

- Microphone, track, or ambient demo
- Bars, ring, wave, bloom
- Analog desk: genre → spectrogram + tempo → curve comment
- Media library: wav, mp3, flac, mp4, pictures, drawings, lyrics
- PWA install on phone and desktop
- License: €49 CORE studio seat

## Tonight

Launch key: `CORE-1900`

Checkout (test): https://buy.stripe.com/test_8x29ASemJ3pXb7w9S2gjC00

After a paid seat, redeem `CORE-STUDIO`.

## Keys

| Key | Action |
|---|---|
| L | Library |
| E | Export frame |
| K | License |
| A | Analog on/off |
| F | Fullscreen |
| 1–4 | Modes |

## Kernel

Requested clock 44.1 kHz. Internal path 32-bit float. Dry 0.62 / wet 0.38. Cut before boost. Conservative master.
