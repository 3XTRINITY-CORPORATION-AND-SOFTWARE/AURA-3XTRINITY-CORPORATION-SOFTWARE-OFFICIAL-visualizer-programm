---
name: aura-visualizer
description: "Edit the AURA music visualizer: analog 44.1/ASIO4ALL EQ, spectrogram/tempo genre path, and import/export of audio, video, images, drawings, and text. Use when the user mentions analog mirror, asio4all, 44100, bit-format, spectrogram, tempo, import, export, wav, mp3, flac, mp4, pictures, lyrics, or visualizer media library."
type: workflow
lifecycle: active
---

# AURA Visualizer — Analog path + media edit

Keep the analyser connected. Import media into the library. Mix original fundamentals with analog mirroring. Never change the source bit format.

## When this skill applies

- Analog / ASIO4ALL / 44.1 kHz / spectrogram / tempo / bit-format cleanup
- Import or export pictures, video, drawings, txt, wav, mp3, flac, mp4
- Visualizer modes, field notes, library, frame export

Do **not** use for generic audio players, DAW plugins, or documents that are not AURA.

## Workflow

1. **Keep the graph connected.** Source → bus → AnalogPath (dry/wet) → analyser → master. Bypass is dry/wet, never a disconnect.
2. **Import into the library**, not a one-shot play. Classify, store, then route:
   - audio / video → analog path + visualizer
   - image / drawing / svg → backdrop
   - txt / lrc / md → lyrics overlay
   - `aura-project.json` → restore theme, mode, analog, backdrop, lyrics
3. **Analyze tracks** (genre detector → spectrogram + tempo → curve comment) then apply the matching analog curve.
4. **Cut before boost.** Light even-order rounding. Makeup < 1. Same sample rate and bit depth as source.
5. **Export** a PNG frame and/or `aura-project.json`. Do not requantize audio.

See `references/analog-path.md` for curves and mix. See `references/media-import.md` for formats, IndexedDB, and routing.

## Hard rules

| Rule | Detail |
|---|---|
| Sample rate | Request 44100. If the device is 48000, report it. Never resample the file. |
| Bit format | 32-bit float through the graph. No dither, no encode. |
| Mix | Dry 0.62 (fundamentals) / wet 0.38 (mirror). Bypass = dry 1 / wet 0. |
| Phase | Series IIR only. No Haas, no stereo width. |
| Master | Conservative makeup. Hardware-agnostic. |
| Library | Persist blobs in IndexedDB `aura-media-v1`. Built-in plates stay. |
| Drop | Any mix of files on the stage → classify → import → auto-route first of each kind. |

## UI contract

- Library panel: Import / Frame / Project. Filter All · Audio · Image · Video · Text.
- Start: Microphone, Open track, Play demo, Import media, Field notes.
- Keys: `L` library, `E` export frame, `A` analog, `F` fullscreen, `G` civil door, `K` license, `1–4` modes.
- Controls stay unobtrusive. Visualization stays on canvas.

## Output when the user asks for analog notes

Ship a short curve comment, reported sample rate, and "source format preserved". Optional Word spec via the `docx` skill using plates in `public/notes/plates/`.
