# Changelog

## 2026-09-05
- Initial skill creation
- Analog 44.1 / ASIO4ALL path: dry/wet mix, cut-before-boost curves, same bit format
- Media library: import audio/video/image/text, export frame + aura-project.json
- Trigger words: asio4all, analog mirror, spectrogram, tempo, bit-format, import, export, wav, mp3, flac, mp4
