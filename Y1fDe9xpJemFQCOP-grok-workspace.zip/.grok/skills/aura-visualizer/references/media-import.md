---
description: "Import/export formats, IndexedDB library, and routing into the visualizer."
connections: [analog-path]
---

# Media import and export

## Classify

`classifyFile` in `src/lib/visualizer/media.ts`. Extension wins when MIME is empty.

| Kind | Extensions |
|---|---|
| Audio | mp3 wav ogg flac fl m4a aac aiff opus weba caf |
| Video | mp4 webm mov m4v ogv flv mkv |
| Image / drawing | jpg jpeg png webp gif avif bmp svg |
| Text | txt lrc md json csv srt |
| Project | `aura-project.json` (`kind: "aura-project"`) |

`.fl` is treated as audio (FLAC-style). FL Studio `.flp` is skipped.

Max size 90 MB per file. Unsupported names go to `skipped`.

## Routing after import

| Kind | Action |
|---|---|
| Audio | Play through analog path. Analyse genre/tempo. |
| Video | Play audio through analog path. Frames drawn as backdrop. |
| Image / SVG | Set as visualizer backdrop (cover-crop). |
| Text | Lyrics overlay (first 8 non-empty lines). |
| Project JSON | Restore theme, mode, sensitivity, analog, volume, backdrop, lyrics by name. |

Drop on the stage imports a mixed selection. First of each kind auto-routes. Library stays open.

## Persistence

IndexedDB `aura-media-v1`: `meta` + `blobs`. Built-in dusk plates (`public/notes/plates/`) are not stored.

## Export

| Action | File |
|---|---|
| Frame (`E`) | `aura-frame-<ts>.png` from the canvas |
| Project | `aura-project.json` — settings + media names, not blobs |
| Field notes | PDF / PPTX / DOCX / XLSX under `/notes/` |

Re-importing a project restores settings if matching media names are already in the library. Blobs are not packed into the JSON.

## UI files

- Library: `src/components/visualizer/media-library.tsx`
- Overlay: `src/components/visualizer/lyrics-overlay.tsx`
- Wiring: `src/components/visualizer/aura-app.tsx`
- Canvas backdrop: `src/lib/visualizer/renderer.ts` `drawMedia`
