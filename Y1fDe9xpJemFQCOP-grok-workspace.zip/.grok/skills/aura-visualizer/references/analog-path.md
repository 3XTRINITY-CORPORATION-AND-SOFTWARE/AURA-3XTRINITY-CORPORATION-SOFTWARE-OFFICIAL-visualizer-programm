---
description: "Analog 44.1 curve recipes, mix ratios, and processing order for AURA."
connections: [media-import]
---

# Analog 44.1 path

Always-connected dry/wet. Cuts first, then boosts, then even-order shaper, then makeup.

## Mix

| Bus | Gain | Role |
|---|---|---|
| Dry | 0.62 | Original fundamentals |
| Wet | 0.38 | Analog mirror (EQ + light even harmonics) |
| Makeup | < 1.0 | Conservative master |
| Oversample | 2x | Waveshaper only |

## Desk order

1. Genre detector (spectral bass/mid/high)
2. Decision maker (spectrogram + tempo, 70–180 BPM)
3. Track info + short curve comment

## Curves

Cut A and Cut B land before Lift A / Lift B.

| Genre | Cut A | Cut B | Lift A | Lift B | Drive | Makeup |
|---|---|---|---|---|---|---|
| Electronic | 300 −2.6 | 4.2k −1.3 | 80 +1.2 | 11k +0.8 | 0.22 | 0.90 |
| Hip-hop | 350 −2.2 | 3.1k −1.5 | 62 +1.6 | 8.5k +0.5 | 0.18 | 0.88 |
| Rock | 280 −1.8 | 4k −1.1 | 120 +0.7 | 2.2k +1.3 | 0.20 | 0.91 |
| Acoustic | 400 −1.4 | 2.5k −0.6 | 5.2k +1.1 | 12k +0.7 | 0.12 | 0.93 |
| Ambient | 250 −1.1 | 5k −0.4 | 10k +0.5 | 180 +0.3 | 0.14 | 0.94 |
| Pop | 320 −2.0 | 3.5k −1.0 | 100 +1.0 | 3k +1.0 | 0.16 | 0.90 |

HPF ~28 Hz (acoustic 40 Hz, ambient 24 Hz) is always the first cut.

## Code

- Graph: `src/lib/visualizer/audio.ts`
- Recipes: `src/lib/visualizer/analog-eq.ts`
- Genre + BPM: `src/lib/visualizer/analyze.ts`
- Desk UI: `src/components/visualizer/analog-desk.tsx`
