#!/usr/bin/env python3
"""Build AURA Analog 44.1 field notes: pptx, pdf, docx, xlsx."""

from __future__ import annotations

import os
from io import BytesIO

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.oxml.ns import nsmap
from pptx.util import Emu, Inches, Pt
from pptx.oxml import parse_xml
from lxml import etree

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Cm, Inches as DocInches, Pt as DocPt, RGBColor as DocRGB

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.drawing.image import Image as XLImage

from reportlab.lib.colors import Color, HexColor
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

ROOT = "/workspace"
PLATES = os.path.join(ROOT, "attachments")
OUT = os.path.join(ROOT, "public", "notes")
ART = os.path.join(ROOT, "artifacts")
os.makedirs(OUT, exist_ok=True)
os.makedirs(ART, exist_ok=True)

# Widescreen 16:9
SW, SH = Inches(13.333), Inches(7.5)
PW, PH = 13.333 * 72, 7.5 * 72  # pdf points

BG = RGBColor(0x07, 0x07, 0x08)
FG = RGBColor(0xF2, 0xF2, 0xF3)
MUTED = RGBColor(0x8B, 0x8B, 0x93)
SUBTLE = RGBColor(0x6A, 0x6A, 0x72)
SURFACE = RGBColor(0x12, 0x12, 0x14)

BG_HEX = "#070708"
FG_HEX = "#F2F2F3"
MUTED_HEX = "#8B8B93"
SURFACE_HEX = "#121214"

FONT_REG = "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"
FONT_BOLD = "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"
pdfmetrics.registerFont(TTFont("Lib", FONT_REG))
pdfmetrics.registerFont(TTFont("LibBd", FONT_BOLD))

PLATE_META = [
    ("158.jpg", "Blue hour", "Crescent over the field. Analog path keeps the fundamental; the haze is the mirror."),
    ("114.jpg", "Canopy", "Sun through leaves — cut mud before any lift, same as this light through branches."),
    ("110.jpg", "Waterline", "Moon over still water. Phase-coherent series path, no stereo width tricks."),
    ("89.jpg", "Pink hour", "Same sky, quieter take. Conservative master so it holds on any DAC."),
    ("87.jpg", "Still", "Dusk with the play cue. Original format in, original format out."),
    ("90.jpg", "Bloom", "Flower and moon. Light even-harmonic rounding — barely on."),
    ("159.jpg", "Road", "Sunrise on dirt. Hardware-agnostic: the curve scales with the speakers, not against them."),
    ("120.jpg", "Mark", "Identity plate. Same bit format through the chain."),
]

CURVES = [
    ("Electronic", 300, -2.6, 4200, -1.3, 80, 1.2, 11000, 0.8, 0.22, 0.90,
     "Cut 300 Hz and 4.2 kHz before an 80 Hz shelf. Fundamentals stay dry."),
    ("Hip-hop", 350, -2.2, 3100, -1.5, 62, 1.6, 8500, 0.5, 0.18, 0.88,
     "Cut 350 Hz mud before a 60 Hz shelf. Kick fundamental untouched."),
    ("Rock", 280, -1.8, 4000, -1.1, 120, 0.7, 2200, 1.3, 0.20, 0.91,
     "Cut 280 Hz and 4 kHz before a 2.2 kHz presence lift."),
    ("Acoustic", 400, -1.4, 2500, -0.6, 5200, 1.1, 12000, 0.7, 0.12, 0.93,
     "Cut 400 Hz boxiness before 5 kHz air. Rounding barely on."),
    ("Ambient", 250, -1.1, 5000, -0.4, 10000, 0.5, 180, 0.3, 0.14, 0.94,
     "Gentle 250 Hz cut, no hype. Soft even-order haze."),
    ("Pop", 320, -2.0, 3500, -1.0, 100, 1.0, 3000, 1.0, 0.16, 0.90,
     "Cut 320 Hz before a 1 dB 100 Hz shelf and 3 kHz presence."),
]


def cover(path: str, w: int, h: int) -> Image.Image:
    im = Image.open(path).convert("RGB")
    ir, wr = im.width / im.height, w / h
    if ir > wr:
        nw = int(im.height * wr)
        x = (im.width - nw) // 2
        im = im.crop((x, 0, x + nw, im.height))
    else:
        nh = int(im.width / wr)
        y = (im.height - nh) // 2
        im = im.crop((0, y, im.width, y + nh))
    return im.resize((w, h), Image.Resampling.LANCZOS)


def tmp_cover(name: str, w: int, h: int) -> str:
    im = cover(os.path.join(PLATES, name), w, h)
    dest = os.path.join("/tmp", f"cover-{w}x{h}-{name}")
    im.save(dest, "JPEG", quality=88)
    return dest


def set_run(run, size, color, bold=False, name="Liberation Sans"):
    run.font.size = Pt(size)
    run.font.color.rgb = color
    run.font.bold = bold
    run.font.name = name


def add_textbox(slide, l, t, w, h, text, size, color, bold=False, align=PP_ALIGN.LEFT):
    box = slide.shapes.add_textbox(l, t, w, h)
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    set_run(run, size, color, bold)
    return box


def fill_bg(slide, color=BG):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_rect(slide, l, t, w, h, color):
    sh = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, l, t, w, h)
    sh.fill.solid()
    sh.fill.fore_color.rgb = color
    sh.line.fill.background()
    return sh


def build_pptx():
    prs = Presentation()
    prs.slide_width = SW
    prs.slide_height = SH
    blank = prs.slide_layouts[6]

    # 1 Cover
    s = prs.slides.add_slide(blank)
    fill_bg(s)
    img = tmp_cover("158.jpg", 1920, 1080)
    s.shapes.add_picture(img, 0, 0, SW, SH)
    add_rect(s, 0, 0, SW, SH, RGBColor(0x07, 0x07, 0x08))
    # overlay via extra dark shape at 55% — pptx can't do alpha easily.
    # Use a left gradient-like panel
    add_rect(s, 0, 0, Inches(6.4), SH, BG)
    s.shapes.add_picture(img, Inches(5.4), 0, Inches(7.94), SH)
    add_rect(s, Inches(5.2), 0, Inches(0.35), SH, BG)
    add_textbox(s, Inches(0.55), Inches(1.7), Inches(5), Inches(0.4),
                "FIELD NOTES  ·  44.1 kHz", 12, MUTED, True)
    add_textbox(s, Inches(0.55), Inches(2.15), Inches(5.2), Inches(1.6),
                "AURA", 60, FG, True)
    add_textbox(s, Inches(0.55), Inches(3.55), Inches(4.8), Inches(1.4),
                "Analog 44.1 path.\nOriginal fundamentals,\nmirrored, not converted.", 18, MUTED)
    add_textbox(s, Inches(0.55), Inches(6.55), Inches(4.8), Inches(0.4),
                "Same bit format  ·  cut before boost  ·  conservative master", 11, SUBTLE)

    # 2 Contract
    s = prs.slides.add_slide(blank)
    fill_bg(s)
    add_textbox(s, Inches(0.6), Inches(0.4), Inches(12), Inches(0.35),
                "01  /  CONTRACT", 11, SUBTLE, True)
    add_textbox(s, Inches(0.6), Inches(0.85), Inches(12), Inches(0.7),
                "Keep the source. Mirror the analog.", 28, FG, True)
    points = [
        ("Sample rate", "Request 44.1 kHz. If the hardware is 48 kHz, report it — never resample in software."),
        ("Bit format", "32-bit float through the graph. No requantize, no dither pass, no encode."),
        ("Fundamentals", "Dry path stays connected at 0.62. The original tone is the source of truth."),
        ("Analog mirror", "Wet path 0.38 — cuts first, then boosts, then even-order rounding."),
        ("Master", "Makeup under unity. Hardware-agnostic so cheap DACs and good monitors agree."),
    ]
    for i, (k, v) in enumerate(points):
        y = Inches(1.75 + i * 1.0)
        add_rect(s, Inches(0.6), y, Inches(0.08), Inches(0.78), FG)
        add_textbox(s, Inches(0.9), y, Inches(3.2), Inches(0.4), k, 16, FG, True)
        add_textbox(s, Inches(4.2), y, Inches(8.4), Inches(0.8), v, 15, MUTED)

    # 3 Path
    s = prs.slides.add_slide(blank)
    fill_bg(s)
    add_textbox(s, Inches(0.6), Inches(0.4), Inches(12), Inches(0.35),
                "02  /  SIGNAL PATH", 11, SUBTLE, True)
    add_textbox(s, Inches(0.6), Inches(0.85), Inches(12), Inches(0.6),
                "Always connected. Bypass is dry/wet, not a disconnect.", 24, FG, True)
    steps = [
        ("IN", "Source bus"),
        ("CUT", "HPF · mud · harsh"),
        ("LIFT", "Shelf · presence"),
        ("MIRROR", "Even-order shaper"),
        ("MIX", "Dry 62 / wet 38"),
        ("OUT", "Analyser · master"),
    ]
    for i, (k, v) in enumerate(steps):
        x = Inches(0.55 + i * 2.15)
        add_rect(s, x, Inches(2.4), Inches(1.95), Inches(2.2), SURFACE)
        add_textbox(s, x + Inches(0.12), Inches(2.6), Inches(1.7), Inches(0.45),
                    f"{i+1:02d}", 12, SUBTLE, True)
        add_textbox(s, x + Inches(0.12), Inches(3.1), Inches(1.7), Inches(0.5),
                    k, 16, FG, True)
        add_textbox(s, x + Inches(0.12), Inches(3.65), Inches(1.7), Inches(0.7),
                    v, 12, MUTED)
    add_textbox(s, Inches(0.6), Inches(5.2), Inches(12), Inches(1.5),
                "Genre detector reads spectrum + tempo, then the decision maker picks a curve. "
                "Cuts land before boosts. The shaper adds a little even-harmonic haze so the "
                "result feels analog without changing format.", 16, MUTED)

    # 4 Desk
    s = prs.slides.add_slide(blank)
    fill_bg(s)
    add_textbox(s, Inches(0.6), Inches(0.4), Inches(12), Inches(0.35),
                "03  /  DESK ORDER", 11, SUBTLE, True)
    cols = [
        ("1", "Genre", "Spectral bass / mid / high plus BPM. Six rooms: electronic, hip-hop, rock, acoustic, ambient, pop."),
        ("2", "Decision", "Live spectrogram and tempo. The curve is chosen here, then ramped into the filters."),
        ("3", "Track", "Name, rate, channel count, bit-format note, and a short comment of the curve."),
    ]
    for i, (n, t, b) in enumerate(cols):
        x = Inches(0.55 + i * 4.2)
        add_rect(s, x, Inches(1.5), Inches(3.95), Inches(4.8), SURFACE)
        add_textbox(s, x + Inches(0.3), Inches(1.8), Inches(3.3), Inches(0.5), n, 28, FG, True)
        add_textbox(s, x + Inches(0.3), Inches(2.5), Inches(3.3), Inches(0.5), t, 20, FG, True)
        add_textbox(s, x + Inches(0.3), Inches(3.2), Inches(3.3), Inches(2.6), b, 15, MUTED)

    # 5 Curves
    s = prs.slides.add_slide(blank)
    fill_bg(s)
    add_textbox(s, Inches(0.6), Inches(0.35), Inches(12), Inches(0.3),
                "04  /  CURVES", 11, SUBTLE, True)
    add_textbox(s, Inches(0.6), Inches(0.7), Inches(12), Inches(0.45),
                "Cut first. Boost second. Drive last.", 22, FG, True)
    headers = ["Genre", "Cut A", "Cut B", "Lift A", "Lift B", "Drive", "Makeup"]
    xs = [0.55, 2.3, 4.2, 6.1, 8.0, 9.9, 11.4]
    ws = [1.7, 1.85, 1.85, 1.85, 1.85, 1.4, 1.4]
    for h, x, w in zip(headers, xs, ws):
        add_textbox(s, Inches(x), Inches(1.35), Inches(w), Inches(0.35), h, 11, SUBTLE, True)
    add_rect(s, Inches(0.55), Inches(1.72), Inches(12.2), Inches(0.015), RGBColor(0x2A, 0x2A, 0x2E))
    rows = [
        ("Electronic", "300 −2.6", "4.2k −1.3", "80 +1.2", "11k +0.8", "0.22", "0.90"),
        ("Hip-hop", "350 −2.2", "3.1k −1.5", "62 +1.6", "8.5k +0.5", "0.18", "0.88"),
        ("Rock", "280 −1.8", "4k −1.1", "120 +0.7", "2.2k +1.3", "0.20", "0.91"),
        ("Acoustic", "400 −1.4", "2.5k −0.6", "5.2k +1.1", "12k +0.7", "0.12", "0.93"),
        ("Ambient", "250 −1.1", "5k −0.4", "10k +0.5", "180 +0.3", "0.14", "0.94"),
        ("Pop", "320 −2.0", "3.5k −1.0", "100 +1.0", "3k +1.0", "0.16", "0.90"),
    ]
    for i, row in enumerate(rows):
        y = Inches(1.9 + i * 0.78)
        if i % 2 == 0:
            add_rect(s, Inches(0.5), y - Inches(0.1), Inches(12.3), Inches(0.72), SURFACE)
        for cell, x, w in zip(row, xs, ws):
            add_textbox(s, Inches(x), y, Inches(w), Inches(0.5), cell, 14, FG, i == 0 and False)

    # Photo plates
    for idx, (fn, title, blurb) in enumerate(PLATE_META):
        s = prs.slides.add_slide(blank)
        fill_bg(s)
        pic = tmp_cover(fn, 1280, 1080)
        s.shapes.add_picture(pic, Inches(0), 0, Inches(8.0), SH)
        add_textbox(s, Inches(8.3), Inches(1.6), Inches(4.5), Inches(0.35),
                    f"PLATE  {idx+1:02d}  /  {len(PLATE_META):02d}", 11, SUBTLE, True)
        add_textbox(s, Inches(8.3), Inches(2.15), Inches(4.5), Inches(1.0),
                    title, 28, FG, True)
        add_textbox(s, Inches(8.3), Inches(3.3), Inches(4.5), Inches(2.4),
                    blurb, 16, MUTED)
        add_textbox(s, Inches(8.3), Inches(6.5), Inches(4.5), Inches(0.4),
                    "Analog 44.1  ·  same bit format", 11, SUBTLE)

    # Close
    s = prs.slides.add_slide(blank)
    fill_bg(s)
    img = tmp_cover("159.jpg", 1920, 1080)
    s.shapes.add_picture(img, 0, 0, SW, SH)
    add_rect(s, 0, Inches(4.6), SW, Inches(2.9), BG)
    add_textbox(s, Inches(0.7), Inches(4.9), Inches(12), Inches(0.4),
                "OUTPUT CONTRACT", 12, SUBTLE, True)
    add_textbox(s, Inches(0.7), Inches(5.35), Inches(12), Inches(1.4),
                "Same bit format. Short comment of the curve.\nA conservative master that holds on every device.", 22, FG, True)

    path = os.path.join(OUT, "AURA-Analog-44.1.pptx")
    prs.save(path)
    prs.save(os.path.join(ART, "AURA-Analog-44.1.pptx"))
    return path


def rl_color(hexstr):
    return HexColor(hexstr)


def pdf_cover(c, name, w, h):
    path = tmp_cover(name, int(w * 2), int(h * 2))
    c.drawImage(path, 0, 0, width=w, height=h, preserveAspectRatio=True, anchor="c")


def build_pdf():
    path = os.path.join(OUT, "AURA-Analog-44.1.pdf")
    c = canvas.Canvas(path, pagesize=(PW, PH))

    def bg():
        c.setFillColor(rl_color(BG_HEX))
        c.rect(0, 0, PW, PH, fill=1, stroke=0)

    def t(text, x, y, size=12, bold=False, color=FG_HEX):
        c.setFillColor(rl_color(color))
        c.setFont("LibBd" if bold else "Lib", size)
        c.drawString(x, y, text)

    def wrapped(text, x, y, size, width, color=MUTED_HEX, leading=None):
        c.setFillColor(rl_color(color))
        c.setFont("Lib", size)
        lead = leading or size * 1.35
        words = text.split()
        line = ""
        yy = y
        for w in words:
            trial = (line + " " + w).strip()
            if c.stringWidth(trial, "Lib", size) > width:
                c.drawString(x, yy, line)
                yy -= lead
                line = w
            else:
                line = trial
        if line:
            c.drawString(x, yy, line)
        return yy

    # Cover
    bg()
    pic = tmp_cover("158.jpg", 1100, 1080)
    c.drawImage(pic, 380, 0, width=580, height=PH)
    c.setFillColor(rl_color(BG_HEX))
    c.rect(0, 0, 430, PH, fill=1, stroke=0)
    t("FIELD NOTES  ·  44.1 kHz", 40, 400, 11, True, MUTED_HEX)
    t("AURA", 40, 340, 48, True)
    wrapped("Analog 44.1 path. Original fundamentals, mirrored, not converted.",
            40, 300, 14, 340)
    t("Same bit format  ·  cut before boost", 40, 50, 10, False, MUTED_HEX)
    c.showPage()

    # Contract
    bg()
    t("01  /  CONTRACT", 40, 500, 11, True, MUTED_HEX)
    t("Keep the source. Mirror the analog.", 40, 468, 24, True)
    items = [
        ("Sample rate", "Request 44.1 kHz. If the hardware is 48 kHz, report it — never resample in software."),
        ("Bit format", "32-bit float through the graph. No requantize, no dither, no encode."),
        ("Fundamentals", "Dry path stays connected at 0.62. The original tone is the source of truth."),
        ("Analog mirror", "Wet path 0.38 — cuts first, then boosts, then even-order rounding."),
        ("Master", "Makeup under unity. Hardware-agnostic so cheap DACs and good monitors agree."),
    ]
    y = 410
    for k, v in items:
        c.setFillColor(rl_color(FG_HEX))
        c.rect(40, y - 6, 6, 46, fill=1, stroke=0)
        t(k, 58, y + 22, 13, True)
        wrapped(v, 220, y + 22, 12, 680)
        y -= 70
    c.showPage()

    # Path + desk
    bg()
    t("02  /  SIGNAL PATH", 40, 500, 11, True, MUTED_HEX)
    t("Always connected. Bypass is dry/wet, not a disconnect.", 40, 468, 18, True)
    steps = ["IN  source", "CUT  mud/harsh", "LIFT  shelf", "MIRROR  even", "MIX  62/38", "OUT  master"]
    for i, label in enumerate(steps):
        x = 40 + i * 150
        c.setFillColor(rl_color(SURFACE_HEX))
        c.roundRect(x, 300, 138, 110, 6, fill=1, stroke=0)
        t(f"{i+1:02d}", x + 12, 382, 10, True, MUTED_HEX)
        t(label, x + 12, 348, 11, True)
    wrapped(
        "Genre detector reads spectrum + tempo. Decision maker picks a curve. "
        "Cuts land before boosts. The shaper adds a little even-harmonic haze "
        "so the result feels analog without changing format.",
        40, 250, 13, 880,
    )
    t("03  /  DESK ORDER", 40, 160, 11, True, MUTED_HEX)
    t("1  Genre          2  Decision (spectrogram + tempo)          3  Track info + curve comment",
      40, 125, 13, False, FG_HEX)
    c.showPage()

    # Curves table
    bg()
    t("04  /  CURVES", 40, 500, 11, True, MUTED_HEX)
    t("Cut first. Boost second. Drive last.", 40, 470, 18, True)
    headers = ["Genre", "Cut A", "Cut B", "Lift A", "Lift B", "Drive", "Makeup"]
    rows = [
        ["Electronic", "300 −2.6", "4.2k −1.3", "80 +1.2", "11k +0.8", "0.22", "0.90"],
        ["Hip-hop", "350 −2.2", "3.1k −1.5", "62 +1.6", "8.5k +0.5", "0.18", "0.88"],
        ["Rock", "280 −1.8", "4k −1.1", "120 +0.7", "2.2k +1.3", "0.20", "0.91"],
        ["Acoustic", "400 −1.4", "2.5k −0.6", "5.2k +1.1", "12k +0.7", "0.12", "0.93"],
        ["Ambient", "250 −1.1", "5k −0.4", "10k +0.5", "180 +0.3", "0.14", "0.94"],
        ["Pop", "320 −2.0", "3.5k −1.0", "100 +1.0", "3k +1.0", "0.16", "0.90"],
    ]
    xs = [40, 160, 290, 430, 560, 700, 800]
    y = 420
    for h, x in zip(headers, xs):
        t(h, x, y, 10, True, MUTED_HEX)
    y = 390
    for i, row in enumerate(rows):
        if i % 2 == 0:
            c.setFillColor(rl_color(SURFACE_HEX))
            c.rect(32, y - 12, 900, 36, fill=1, stroke=0)
        for cell, x in zip(row, xs):
            t(cell, x, y, 12, False, FG_HEX)
        y -= 42
    c.showPage()

    # Plates
    for i, (fn, title, blurb) in enumerate(PLATE_META):
        bg()
        pic = tmp_cover(fn, 1100, 1080)
        c.drawImage(pic, 0, 0, width=560, height=PH)
        t(f"PLATE  {i+1:02d}  /  {len(PLATE_META):02d}", 590, 380, 11, True, MUTED_HEX)
        t(title, 590, 340, 26, True)
        wrapped(blurb, 590, 300, 13, 340)
        t("Analog 44.1  ·  same bit format", 590, 50, 10, False, MUTED_HEX)
        c.showPage()

    # Close
    bg()
    pic = tmp_cover("159.jpg", 1920, 1080)
    c.drawImage(pic, 0, 0, width=PW, height=PH)
    c.setFillColor(rl_color(BG_HEX))
    c.rect(0, 0, PW, 160, fill=1, stroke=0)
    t("OUTPUT CONTRACT", 40, 120, 11, True, MUTED_HEX)
    t("Same bit format. Short comment of the curve.", 40, 90, 18, True)
    t("A conservative master that holds on every device.", 40, 62, 18, True)
    c.save()
    import shutil
    shutil.copy(path, os.path.join(ART, "AURA-Analog-44.1.pdf"))
    return path


def shade_run(run, size, color, bold=False):
    run.font.size = DocPt(size)
    run.font.color.rgb = color
    run.bold = bold
    run.font.name = "Liberation Sans"
    r = run._element
    rPr = r.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = rPr.makeelement(qn("w:rFonts"), {})
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:ascii"), "Liberation Sans")
    rFonts.set(qn("w:hAnsi"), "Liberation Sans")


def build_docx():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width = DocInches(8.5)
    sec.page_height = DocInches(11)
    sec.left_margin = DocInches(0.9)
    sec.right_margin = DocInches(0.9)
    sec.top_margin = DocInches(0.9)
    sec.bottom_margin = DocInches(0.9)

    def p(text, size=12, color=DocRGB(0x22, 0x22, 0x24), bold=False, space_after=8, space_before=0):
        para = doc.add_paragraph()
        para.paragraph_format.space_after = DocPt(space_after)
        para.paragraph_format.space_before = DocPt(space_before)
        run = para.add_run(text)
        shade_run(run, size, color, bold)
        return para

    p("AURA  ·  FIELD NOTES", 11, DocRGB(0x6A, 0x6A, 0x72), True, 4)
    p("Analog 44.1 path", 28, DocRGB(0x11, 0x11, 0x12), True, 8)
    p("Original fundamentals combined with analog-style mirroring. "
      "Same bit format in and out. Cut before boost. Conservative master "
      "that stays comparable on every device.", 12, space_after=16)

    cover = tmp_cover("158.jpg", 1600, 700)
    doc.add_picture(cover, width=DocInches(6.7))

    p("1. Contract", 18, bold=True, space_before=18, space_after=8)
    contract = [
        ("Sample rate", "The graph requests 44.1 kHz (ASIO4ALL-style). If the device clocks at 48 kHz, that rate is reported. Software never resamples the file."),
        ("Bit format", "Processing stays 32-bit float. The source bit depth is not requantized. Integration stays connected so the analyser and the speakers hear the same path."),
        ("Fundamentals + mirror", "Dry 0.62 / wet 0.38. The dry path is the original tone. The wet path is analog-style even-harmonic rounding after the EQ."),
        ("Cut before boost", "High-pass, mud, and harsh cuts land first. Shelves and presence come second. Drive is last and light."),
        ("Master", "Makeup gain under unity. The curve is conservative so it translates from phone speakers to a proper DAC."),
    ]
    for k, v in contract:
        p(k, 13, bold=True, space_after=2)
        p(v, 12, space_after=10)

    p("2. Desk order", 18, bold=True, space_before=12, space_after=8)
    p("Genre detector  →  decision maker (spectrogram + tempo)  →  track info and curve comment.", 12)
    p("The desk does not change format. It only names the room and applies a matching analog curve.", 12)

    p("3. Curves", 18, bold=True, space_before=12, space_after=8)
    table = doc.add_table(rows=1 + len(CURVES), cols=5)
    table.style = "Table Grid"
    hdr = ["Genre", "Drive", "Makeup", "Primary cut", "Note"]
    for i, h in enumerate(hdr):
        cell = table.rows[0].cells[i]
        cell.text = ""
        r = cell.paragraphs[0].add_run(h)
        shade_run(r, 10, DocRGB(0x11, 0x11, 0x12), True)
    for i, row in enumerate(CURVES):
        vals = [row[0], f"{row[9]:.2f}", f"{row[10]:.2f}", f"{row[1]} Hz {row[2]:+.1f} dB", row[11]]
        for j, v in enumerate(vals):
            table.rows[i + 1].cells[j].text = ""
            r = table.rows[i + 1].cells[j].paragraphs[0].add_run(v)
            shade_run(r, 10, DocRGB(0x22, 0x22, 0x24))

    p("4. Plates", 18, bold=True, space_before=18, space_after=8)
    p("Field stills used as reference for the analog mood — dusk, water, canopy, road. "
      "The processing should feel like these pictures: quiet, a little grain, no hype.", 12, space_after=12)
    for fn, title, blurb in PLATE_META:
        p(title, 14, bold=True, space_before=8, space_after=4)
        pic = tmp_cover(fn, 1400, 800)
        doc.add_picture(pic, width=DocInches(6.7))
        p(blurb, 11, DocRGB(0x55, 0x55, 0x5A), space_after=10)

    p("5. Output", 18, bold=True, space_before=12)
    p("Same bit format. Short comment of the curve. A conservative master that holds on every device.", 12)
    p("Git note: keep the analog path in the audio graph across commits. Do not disconnect on bypass.", 12, space_after=16)
    p("AURA  ·  Analog 44.1  ·  field notes", 10, DocRGB(0x6A, 0x6A, 0x72))

    path = os.path.join(OUT, "AURA-Analog-44.1.docx")
    doc.save(path)
    doc.save(os.path.join(ART, "AURA-Analog-44.1.docx"))
    return path


def build_xlsx():
    wb = Workbook()
    fill_head = PatternFill("solid", fgColor="121214")
    fill_alt = PatternFill("solid", fgColor="F4F4F5")
    fill_bg = PatternFill("solid", fgColor="FFFFFF")
    font_h = Font(name="Liberation Sans", bold=True, color="F2F2F3", size=11)
    font_t = Font(name="Liberation Sans", bold=True, color="121214", size=16)
    font_b = Font(name="Liberation Sans", color="222224", size=11)
    thin = Border(
        left=Side(style="thin", color="E4E4E7"),
        right=Side(style="thin", color="E4E4E7"),
        top=Side(style="thin", color="E4E4E7"),
        bottom=Side(style="thin", color="E4E4E7"),
    )
    wrap = Alignment(wrap_text=True, vertical="center")

    # Curves
    ws = wb.active
    ws.title = "Curves"
    ws["A1"] = "AURA Analog 44.1 — genre curves"
    ws["A1"].font = font_t
    ws.merge_cells("A1:K1")
    ws["A2"] = "Cut before boost. Drive is even-harmonic mirror amount. Makeup is linear, always under unity."
    ws["A2"].font = Font(name="Liberation Sans", italic=True, color="6A6A72", size=10)
    ws.merge_cells("A2:K2")

    headers = [
        "Genre", "Cut A Hz", "Cut A dB", "Cut B Hz", "Cut B dB",
        "Lift A Hz", "Lift A dB", "Lift B Hz", "Lift B dB", "Drive", "Makeup", "Comment",
    ]
    for i, h in enumerate(headers, 1):
        cell = ws.cell(4, i, h)
        cell.fill = fill_head
        cell.font = font_h
        cell.alignment = Alignment(vertical="center")
        cell.border = thin
    for r, row in enumerate(CURVES, 5):
        vals = [row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11]]
        for c, v in enumerate(vals, 1):
            cell = ws.cell(r, c, v)
            cell.font = font_b
            cell.border = thin
            cell.alignment = wrap
            if (r - 5) % 2:
                cell.fill = fill_alt
    ws.row_dimensions[1].height = 24
    ws.row_dimensions[4].height = 22
    widths = [14, 12, 12, 12, 12, 12, 12, 12, 12, 10, 10, 56]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A5"
    ws.auto_filter.ref = "A4:L10"

    # Mix
    mix = wb.create_sheet("Mix")
    mix["A1"] = "Always-connected mix"
    mix["A1"].font = font_t
    mix.merge_cells("A1:B1")
    rows = [
        ("Dry (fundamentals)", 0.62),
        ("Wet (analog mirror)", 0.38),
        ("Requested sample rate", "44100"),
        ("Internal bit format", "32-bit float"),
        ("Oversample on shaper", "2x"),
        ("Bypass", "Dry → 1.0, wet → 0 (nodes stay connected)"),
        ("Master policy", "Makeup < 1.0, hardware-agnostic"),
    ]
    mix["A3"] = "Parameter"
    mix["B3"] = "Value"
    for col in (1, 2):
        mix.cell(3, col).fill = fill_head
        mix.cell(3, col).font = font_h
        mix.cell(3, col).border = thin
    for i, (k, v) in enumerate(rows, 4):
        mix.cell(i, 1, k).font = font_b
        mix.cell(i, 1).border = thin
        mix.cell(i, 2, v).font = font_b
        mix.cell(i, 2).border = thin
        if i % 2 == 0:
            mix.cell(i, 1).fill = fill_alt
            mix.cell(i, 2).fill = fill_alt
    mix.column_dimensions["A"].width = 36
    mix.column_dimensions["B"].width = 44

    # Rules
    rules = wb.create_sheet("Rules")
    rules["A1"] = "Processing rules"
    rules["A1"].font = font_t
    body = [
        "Trigger words: asio4all, analog mirror, spectrogram, tempo, bit-format cleanup.",
        "Analog mirror path keeps the source sample rate and bit depth (default 44.1 / 48 kHz).",
        "Combine original fundamentals with analog-style mirroring instead of changing format.",
        "Dashboard order: genre detector → decision maker (spectrogram + tempo) → track info and comments.",
        "Cut before boost.",
        "Light analog rounding (even-order waveshaper, 2x oversample).",
        "Phase-coherent series path — no Haas, no stereo width.",
        "Result scales with DAC / speakers via a conservative master.",
        "Output: same bit format, short comment of the curve, hardware-agnostic master.",
    ]
    rules["A3"] = "Rule"
    rules["A3"].fill = fill_head
    rules["A3"].font = font_h
    for i, line in enumerate(body, 4):
        cell = rules.cell(i, 1, line)
        cell.font = font_b
        cell.alignment = wrap
        cell.border = thin
        rules.row_dimensions[i].height = 22
        if i % 2 == 0:
            cell.fill = fill_alt
    rules.column_dimensions["A"].width = 110

    # Plates
    plates = wb.create_sheet("Plates")
    plates["A1"] = "Field plates"
    plates["A1"].font = font_t
    for i, h in enumerate(["File", "Title", "Note"], 1):
        cell = plates.cell(3, i, h)
        cell.fill = fill_head
        cell.font = font_h
        cell.border = thin
    for r, (fn, title, blurb) in enumerate(PLATE_META, 4):
        for c, v in enumerate((fn, title, blurb), 1):
            cell = plates.cell(r, c, v)
            cell.font = font_b
            cell.border = thin
            cell.alignment = wrap
            if r % 2 == 0:
                cell.fill = fill_alt
        plates.row_dimensions[r].height = 36
    plates.column_dimensions["A"].width = 14
    plates.column_dimensions["B"].width = 16
    plates.column_dimensions["C"].width = 80

    path = os.path.join(OUT, "AURA-Analog-44.1.xlsx")
    wb.save(path)
    wb.save(os.path.join(ART, "AURA-Analog-44.1.xlsx"))
    return path


if __name__ == "__main__":
    print("pptx", build_pptx())
    print("pdf", build_pdf())
    print("docx", build_docx())
    print("xlsx", build_xlsx())
