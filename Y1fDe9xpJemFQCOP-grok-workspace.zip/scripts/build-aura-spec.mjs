import fs from "node:fs";
import {
  AlignmentType,
  BorderStyle,
  Document,
  Footer,
  Header,
  HeadingLevel,
  ImageRun,
  LevelFormat,
  Packer,
  PageNumber,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableRow,
  TextRun,
  WidthType,
} from "docx";

const PLATES = "/workspace/public/notes/plates";
const OUT = "/workspace/public/notes/AURA-Import-Export.docx";
const ART = "/workspace/artifacts/AURA-Import-Export.docx";

const ink = "111112";
const mute = "6A6A72";
const line = "D4D4D8";
const fillHead = "121214";
const fillAlt = "F4F4F5";
const white = "FFFFFF";

const border = { style: BorderStyle.SINGLE, size: 4, color: line };
const borders = { top: border, bottom: border, left: border, right: border };
const cellPad = { top: 80, bottom: 80, left: 120, right: 120 };
const TW = 9360;

function p(text, opts = {}) {
  const {
    size = 22,
    color = ink,
    bold = false,
    after = 160,
    before = 0,
    align = AlignmentType.LEFT,
  } = opts;
  return new Paragraph({
    alignment: align,
    spacing: { after, before, line: 276 },
    children: [
      new TextRun({ text, font: "Arial", size, color, bold }),
    ],
  });
}

function h(text, level) {
  return new Paragraph({
    heading: level,
    spacing: { before: level === HeadingLevel.HEADING_1 ? 280 : 200, after: 140 },
    children: [new TextRun({ text, font: "Arial", bold: true })],
  });
}

function cell(text, width, { header = false, alt = false, bold = false } = {}) {
  return new TableCell({
    borders,
    width: { size: width, type: WidthType.DXA },
    shading: {
      type: ShadingType.CLEAR,
      fill: header ? fillHead : alt ? fillAlt : white,
    },
    margins: cellPad,
    children: [
      new Paragraph({
        children: [
          new TextRun({
            text,
            font: "Arial",
            size: header ? 18 : 20,
            bold: header || bold,
            color: header ? white : ink,
          }),
        ],
      }),
    ],
  });
}

function table(headers, rows, widths) {
  return new Table({
    width: { size: TW, type: WidthType.DXA },
    columnWidths: widths,
    rows: [
      new TableRow({
        children: headers.map((h, i) => cell(h, widths[i], { header: true })),
      }),
      ...rows.map((row, r) =>
        new TableRow({
          children: row.map((c, i) =>
            cell(String(c), widths[i], { alt: r % 2 === 1, bold: i === 0 }),
          ),
        }),
      ),
    ],
  });
}

function img(path, maxW, maxH, alt) {
  const buf = fs.readFileSync(path);
  // Natural sizes known from plates; caller passes computed px.
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 200 },
    children: [
      new ImageRun({
        type: "jpg",
        data: buf,
        transformation: { width: maxW, height: maxH },
        altText: {
          name: alt,
          description: alt,
          title: alt,
        },
      }),
    ],
  });
}

const cover = `${PLATES}/158.jpg`; // 843 x 1500
const road = `${PLATES}/159.jpg`;
const water = `${PLATES}/110.jpg`;

// Keep aspect: 843/1500. Target width 480 → height 854 too tall.
// Use width 220 → height 391 for inline plates.
const plateW = 220;
const plateH = Math.round(220 * (1500 / 843));

const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 22, color: ink } } },
    paragraphStyles: [
      {
        id: "Heading1",
        name: "Heading 1",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: { size: 32, bold: true, font: "Arial", color: ink },
        paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 0 },
      },
      {
        id: "Heading2",
        name: "Heading 2",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: { size: 26, bold: true, font: "Arial", color: ink },
        paragraph: { spacing: { before: 220, after: 120 }, outlineLevel: 1 },
      },
    ],
  },
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [
          {
            level: 0,
            format: LevelFormat.BULLET,
            text: "•",
            alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } },
          },
        ],
      },
      {
        reference: "steps",
        levels: [
          {
            level: 0,
            format: LevelFormat.DECIMAL,
            text: "%1.",
            alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } },
          },
        ],
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 1440, bottom: 1080, left: 1440 },
        },
      },
      headers: {
        default: new Header({
          children: [
            new Paragraph({
              border: {
                bottom: { style: BorderStyle.SINGLE, size: 6, color: "121214", space: 1 },
              },
              spacing: { after: 120 },
              children: [
                new TextRun({
                  text: "AURA  ·  Field spec",
                  font: "Arial",
                  size: 16,
                  color: mute,
                  bold: true,
                }),
              ],
            }),
          ],
        }),
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              border: {
                top: { style: BorderStyle.SINGLE, size: 6, color: "D4D4D8", space: 8 },
              },
              spacing: { before: 80 },
              children: [
                new TextRun({
                  text: "Analog 44.1  ·  same bit format  ·  ",
                  font: "Arial",
                  size: 16,
                  color: mute,
                }),
                new TextRun({
                  children: [PageNumber.CURRENT],
                  font: "Arial",
                  size: 16,
                  color: mute,
                }),
              ],
            }),
          ],
        }),
      },
      children: [
        p("IMPORT  ·  ANALOG  ·  EXPORT", {
          size: 18,
          color: mute,
          bold: true,
          after: 80,
        }),
        p("AURA visualizer", { size: 56, bold: true, after: 80 }),
        p(
          "Original fundamentals mixed with analog-style mirroring. Import a track, still, clip, drawing, or lyric. Same bit format in and out.",
          { size: 22, color: mute, after: 240 },
        ),
        img(cover, plateW, plateH, "Blue hour plate — crescent over the field"),
        p("Blue hour  ·  built-in plate", {
          size: 16,
          color: mute,
          align: AlignmentType.CENTER,
          after: 280,
        }),

        h("1. Import", HeadingLevel.HEADING_1),
        p(
          "Drop files on the stage or use Import media. Files land in the library, persist in the browser, and route into the visualizer so editing can start immediately.",
        ),
        table(
          ["Kind", "Formats", "What happens"],
          [
            ["Audio", "wav, mp3, flac, ogg, m4a, aac, .fl", "Plays through analog 44.1 path"],
            ["Video", "mp4, webm, mov, m4v, flv", "Audio to analog; frames as backdrop"],
            ["Image / drawing", "jpg, png, webp, gif, svg, bmp", "Cover-cropped visualizer backdrop"],
            ["Text", "txt, lrc, md, srt, csv", "Lyrics overlay, first eight lines"],
            ["Project", "aura-project.json", "Restores theme, mode, analog, names"],
          ],
          [2200, 3360, 3800],
        ),
        p("", { after: 80 }),
        new Paragraph({
          numbering: { reference: "steps", level: 0 },
          spacing: { after: 80 },
          children: [
            new TextRun({
              text: "Classify by MIME, then extension. Skip unknown types.",
              font: "Arial",
              size: 22,
            }),
          ],
        }),
        new Paragraph({
          numbering: { reference: "steps", level: 0 },
          spacing: { after: 80 },
          children: [
            new TextRun({
              text: "Store blob + meta in IndexedDB (aura-media-v1).",
              font: "Arial",
              size: 22,
            }),
          ],
        }),
        new Paragraph({
          numbering: { reference: "steps", level: 0 },
          spacing: { after: 80 },
          children: [
            new TextRun({
              text: "Auto-route the first audio/video, first image, and first text.",
              font: "Arial",
              size: 22,
            }),
          ],
        }),
        new Paragraph({
          numbering: { reference: "steps", level: 0 },
          spacing: { after: 200 },
          children: [
            new TextRun({
              text: "Keep the analogue path connected. Bypass is dry/wet, not a disconnect.",
              font: "Arial",
              size: 22,
            }),
          ],
        }),
        p(
          "Maximum 90 MB per file. Built-in dusk plates stay in the library and are not deleted.",
          { size: 20, color: mute },
        ),

        h("2. Analog 44.1 path", HeadingLevel.HEADING_1),
        p(
          "The graph requests 44.1 kHz (ASIO4ALL-style). If the device clocks at 48 kHz, that rate is reported. Software never resamples the file. Processing stays 32-bit float.",
        ),
        table(
          ["Bus", "Value", "Role"],
          [
            ["Dry", "0.62", "Original fundamentals"],
            ["Wet", "0.38", "Analog mirror after EQ"],
            ["Makeup", "< 1.0", "Conservative, hardware-agnostic master"],
            ["Shaper", "even-order, 2×", "Light analog rounding"],
          ],
          [2200, 2800, 4360],
        ),
        p("", { after: 80 }),
        h("Desk order", HeadingLevel.HEADING_2),
        p(
          "Genre detector → decision maker (spectrogram + tempo) → track info and a short comment of the curve.",
        ),
        h("Curves — cut before boost", HeadingLevel.HEADING_2),
        table(
          ["Genre", "Cut A", "Lift A", "Drive", "Makeup"],
          [
            ["Electronic", "300 −2.6", "80 +1.2", "0.22", "0.90"],
            ["Hip-hop", "350 −2.2", "62 +1.6", "0.18", "0.88"],
            ["Rock", "280 −1.8", "120 +0.7", "0.20", "0.91"],
            ["Acoustic", "400 −1.4", "5.2k +1.1", "0.12", "0.93"],
            ["Ambient", "250 −1.1", "10k +0.5", "0.14", "0.94"],
            ["Pop", "320 −2.0", "100 +1.0", "0.16", "0.90"],
          ],
          [2000, 1960, 1960, 1720, 1720],
        ),

        h("3. Export", HeadingLevel.HEADING_1),
        table(
          ["Action", "File", "Contains"],
          [
            ["Frame (E)", "aura-frame-….png", "Current canvas, including backdrop"],
            ["Project", "aura-project.json", "Theme, mode, analog, media names"],
            ["Notes", "/notes/*", "PDF, slides, this spec, curve sheet"],
          ],
          [2400, 3000, 3960],
        ),
        p("", { after: 120 }),
        p(
          "The project file does not pack blobs. Re-import restores settings when matching names are already in the library. Audio is never requantized on export.",
        ),

        h("4. Keys", HeadingLevel.HEADING_1),
        table(
          ["Key", "Action"],
          [
            ["L", "Toggle media library"],
            ["E", "Export current frame"],
            ["A", "Analog path on/off"],
            ["F", "Fullscreen"],
            ["Space", "Play / pause"],
            ["1–4", "Bars / ring / wave / bloom"],
          ],
          [2800, 6560],
        ),

        h("5. Field plates", HeadingLevel.HEADING_1),
        p(
          "Built-in stills set the analog mood — quiet grain, no hype. Use them as backdrops while a track plays.",
        ),
        img(water, plateW, plateH, "Waterline plate — moon over still water"),
        p("Waterline", {
          size: 16,
          color: mute,
          align: AlignmentType.CENTER,
          after: 200,
        }),
        img(road, plateW, plateH, "Road plate — sunrise on dirt"),
        p("Road", {
          size: 16,
          color: mute,
          align: AlignmentType.CENTER,
          after: 200,
        }),

        h("6. Output contract", HeadingLevel.HEADING_1),
        new Paragraph({
          numbering: { reference: "bullets", level: 0 },
          spacing: { after: 80 },
          children: [
            new TextRun({
              text: "Same bit format as the source.",
              font: "Arial",
              size: 22,
            }),
          ],
        }),
        new Paragraph({
          numbering: { reference: "bullets", level: 0 },
          spacing: { after: 80 },
          children: [
            new TextRun({
              text: "Short comment of the curve.",
              font: "Arial",
              size: 22,
            }),
          ],
        }),
        new Paragraph({
          numbering: { reference: "bullets", level: 0 },
          spacing: { after: 200 },
          children: [
            new TextRun({
              text: "A conservative master that holds on every device.",
              font: "Arial",
              size: 22,
            }),
          ],
        }),
        p("AURA  ·  Analog 44.1  ·  import / export spec", {
          size: 16,
          color: mute,
          after: 0,
        }),
      ],
    },
  ],
});

const buf = await Packer.toBuffer(doc);
fs.writeFileSync(OUT, buf);
fs.writeFileSync(ART, buf);
console.log("wrote", OUT, buf.length);
