import { useCallback, useEffect, useRef, useState } from "react";
import { AudioEngine } from "@/lib/visualizer/audio";
import { analyzeTrack } from "@/lib/visualizer/analyze";
import { ANALOG_CURVES } from "@/lib/visualizer/analog-eq";
import { isLicensed } from "@/lib/visualizer/core";
import {
  downloadBlob,
  useLibrary,
  type AuraProject,
  type MediaItem,
} from "@/lib/visualizer/media";
import { useViz } from "@/lib/visualizer/store";
import type { ThemeId, VizMode } from "@/lib/visualizer/types";
import { AnalogDesk } from "./analog-desk";
import { BootScreen } from "./boot-screen";
import { CanvasStage } from "./canvas-stage";
import { CivilDoor } from "./civil-door";
import { ControlDock } from "./control-dock";
import { FieldNotes } from "./field-notes";
import { KernelBar } from "./kernel-bar";
import { LicenseDesk } from "./license-desk";
import { LyricsOverlay } from "./lyrics-overlay";
import { MediaLibrary } from "./media-library";
import { StartPanel } from "./start-panel";

const IMPORT_ACCEPT =
  "audio/*,video/*,image/*,text/plain,.mp3,.wav,.ogg,.flac,.fl,.m4a,.aac,.mp4,.webm,.mov,.m4v,.jpg,.jpeg,.png,.webp,.gif,.svg,.txt,.lrc,.md,.json,.srt,.csv,.aura.json";

export function AuraApp() {
  const engineRef = useRef<AudioEngine | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const canvasOut = useRef<HTMLCanvasElement | null>(null);
  const hideTimer = useRef<number>(0);
  const installRef = useRef<{ prompt: () => Promise<unknown> } | null>(null);
  const [canInstall, setCanInstall] = useState(true);

  const source = useViz((s) => s.source);
  const volume = useViz((s) => s.volume);
  const analogOn = useViz((s) => s.analogOn);
  const hydrate = useViz((s) => s.hydrate);
  const setSource = useViz((s) => s.setSource);
  const setPlaying = useViz((s) => s.setPlaying);
  const setFileMeta = useViz((s) => s.setFileMeta);
  const setCurrentTime = useViz((s) => s.setCurrentTime);
  const setError = useViz((s) => s.setError);
  const setFullscreen = useViz((s) => s.setFullscreen);
  const setControlsOpen = useViz((s) => s.setControlsOpen);
  const setDragging = useViz((s) => s.setDragging);
  const setVolume = useViz((s) => s.setVolume);
  const setAnalogOn = useViz((s) => s.setAnalogOn);
  const setAnalyzing = useViz((s) => s.setAnalyzing);
  const setTrackReport = useViz((s) => s.setTrackReport);
  const clearTrackReport = useViz((s) => s.clearTrackReport);
  const setLibraryOpen = useViz((s) => s.setLibraryOpen);
  const setOverlayText = useViz((s) => s.setOverlayText);

  useEffect(() => {
    hydrate();
    void useLibrary.getState().hydrate();
    const engine = new AudioEngine();
    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [hydrate]);

  useEffect(() => {
    const engine = engineRef.current;
    if (!engine) return;
    if (useViz.getState().source === "mic") return;
    engine.setVolume(volume);
  }, [volume]);

  useEffect(() => {
    engineRef.current?.setAnalog(analogOn);
  }, [analogOn]);

  const bumpControls = useCallback(() => {
    setControlsOpen(true);
    window.clearTimeout(hideTimer.current);
    const state = useViz.getState();
    if (state.source === "none") return;
    hideTimer.current = window.setTimeout(() => {
      if (useViz.getState().source !== "none") setControlsOpen(false);
    }, 3200);
  }, [setControlsOpen]);

  useEffect(() => {
    if (source === "none") setControlsOpen(true);
    else bumpControls();
  }, [source, bumpControls, setControlsOpen]);

  const runAnalysis = useCallback(
    async (file: File) => {
      const engine = engineRef.current;
      if (!engine?.ctx) return;
      setAnalyzing(true);
      try {
        const report = await analyzeTrack(engine.ctx, file);
        engine.applyCurve(report.curve);
        setTrackReport({
          genre: report.genreLabel,
          bpm: report.bpm,
          curveComment: report.curve.comment,
          sampleRate: engine.sampleRate,
          channels: report.channels,
          bitLabel: report.bitLabel,
          spectrum: report.spectrum,
        });
      } catch {
        engine.applyCurve(ANALOG_CURVES.pop);
        setTrackReport({
          genre: "Pop",
          bpm: 120,
          curveComment: ANALOG_CURVES.pop.comment,
          sampleRate: engine.sampleRate,
          channels: 2,
          bitLabel: "32-bit float path · source format preserved",
          spectrum: [],
        });
      }
    },
    [setAnalyzing, setTrackReport],
  );

  const onMic = useCallback(async () => {
    setError(null);
    try {
      const engine = engineRef.current;
      if (!engine) return;
      await engine.unlock();
      engine.setAnalog(useViz.getState().analogOn);
      await engine.startMic();
      engine.setVolume(0);
      setSource("mic");
      setPlaying(true);
      setFileMeta(null, 0);
      setCurrentTime(0);
      clearTrackReport();
    } catch {
      setError("Microphone permission was denied or is unavailable.");
    }
  }, [
    clearTrackReport,
    setCurrentTime,
    setError,
    setFileMeta,
    setPlaying,
    setSource,
  ]);

  const playFile = useCallback(
    async (file: File) => {
      setError(null);
      try {
        const engine = engineRef.current;
        if (!engine) return;
        await engine.unlock();
        engine.setAnalog(useViz.getState().analogOn);
        const el = await engine.startFile(file);
        engine.setVolume(useViz.getState().volume);
        setSource("file");
        setPlaying(true);
        setFileMeta(file.name, Number.isFinite(el.duration) ? el.duration : 0);
        setCurrentTime(0);
        el.onloadedmetadata = () => {
          setFileMeta(file.name, el.duration || 0);
        };
        el.onended = () => {
          setPlaying(false);
        };
        void runAnalysis(file);
      } catch {
        setError("Could not play that file. Try another audio or video format.");
      }
    },
    [runAnalysis, setCurrentTime, setError, setFileMeta, setPlaying, setSource],
  );

  const playItem = useCallback(
    async (item: MediaItem) => {
      const blob = await useLibrary.getState().blobFor(item);
      if (!blob) {
        setError("That file is no longer in the library.");
        return;
      }
      if (item.kind === "video" || item.kind === "image") {
        useLibrary.getState().setBackdrop(item.id);
      }
      const file = new File([blob], item.name, { type: item.mime || blob.type });
      await playFile(file);
    },
    [playFile, setError],
  );

  const applyProject = useCallback(
    (project: AuraProject) => {
      const viz = useViz.getState();
      viz.setTheme(project.theme as ThemeId);
      viz.setMode(project.mode as VizMode);
      viz.setSensitivity(project.sensitivity);
      viz.setAnalogOn(project.analogOn);
      viz.setVolume(project.volume);
      const lib = useLibrary.getState();
      if (project.backdropName) {
        const hit = lib.items.find((i) => i.name === project.backdropName);
        if (hit) lib.setBackdrop(hit.id);
      }
      if (project.lyricsName) {
        const hit = lib.items.find((i) => i.name === project.lyricsName);
        if (hit) {
          lib.setLyrics(hit.id);
          void lib.readText(hit).then(setOverlayText);
        }
      }
    },
    [setOverlayText],
  );

  const ingestFiles = useCallback(
    async (files: File[]) => {
      if (!files.length) return;
      setLibraryOpen(true);
      const result = await useLibrary.getState().importFiles(files);
      if (result.project) applyProject(result.project);
      if (result.skipped.length) {
        setError(`Skipped ${result.skipped.slice(0, 3).join(", ")}.`);
      } else {
        setError(null);
      }
      const firstSound = result.items.find(
        (i) => i.kind === "audio" || i.kind === "video",
      );
      const firstImage = result.items.find((i) => i.kind === "image");
      const firstText = result.items.find((i) => i.kind === "text");
      if (firstImage) useLibrary.getState().setBackdrop(firstImage.id);
      if (firstText) {
        useLibrary.getState().setLyrics(firstText.id);
        setOverlayText(firstText.text ?? (await useLibrary.getState().readText(firstText)));
      }
      if (firstSound) await playItem(firstSound);
    },
    [applyProject, playItem, setError, setLibraryOpen, setOverlayText],
  );

  const onFile = useCallback(() => {
    fileRef.current?.click();
  }, []);

  const onDemo = useCallback(async () => {
    setError(null);
    try {
      const engine = engineRef.current;
      if (!engine) return;
      await engine.unlock();
      engine.setAnalog(useViz.getState().analogOn);
      await engine.startDemo();
      engine.setVolume(useViz.getState().volume);
      setSource("demo");
      setPlaying(true);
      setFileMeta(null, 0);
      setCurrentTime(0);
      setTrackReport({
        genre: "Ambient",
        bpm: 94,
        curveComment: ANALOG_CURVES.ambient.comment,
        sampleRate: engine.sampleRate,
        channels: 2,
        bitLabel: "32-bit float path · source format preserved",
        spectrum: Array.from({ length: 24 }, (_, i) =>
          Math.max(0.08, 0.55 * Math.exp(-((i - 6) * (i - 6)) / 40)),
        ),
      });
    } catch {
      setError("Could not start the demo.");
    }
  }, [
    setCurrentTime,
    setError,
    setFileMeta,
    setPlaying,
    setSource,
    setTrackReport,
  ]);

  const onTogglePlay = useCallback(async () => {
    const engine = engineRef.current;
    const state = useViz.getState();
    if (!engine) return;
    if (state.source === "file") {
      if (state.playing) {
        engine.pauseFile();
        setPlaying(false);
      } else {
        await engine.unlock();
        await engine.resumeFile();
        engine.setVolume(state.volume);
        setPlaying(true);
      }
      return;
    }
    if (state.source === "demo") {
      if (state.playing) {
        engine.halt();
        setPlaying(false);
      } else {
        await onDemo();
      }
    }
  }, [onDemo, setPlaying]);

  const onSeek = useCallback(
    (time: number) => {
      engineRef.current?.seek(time);
      setCurrentTime(time);
    },
    [setCurrentTime],
  );

  const onFullscreen = useCallback(async () => {
    const root = rootRef.current;
    if (!root) return;
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else {
        await root.requestFullscreen();
      }
    } catch {
      setError("Fullscreen is not available here.");
    }
  }, [setError]);

  const onToggleAnalog = useCallback(() => {
    const next = !useViz.getState().analogOn;
    setAnalogOn(next);
    engineRef.current?.setAnalog(next);
  }, [setAnalogOn]);

  const exportFrame = useCallback(() => {
    const canvas = canvasOut.current;
    if (!canvas) {
      setError("Nothing to export yet.");
      return;
    }
    const licensed = isLicensed(useViz.getState().license.plan);
    if (!licensed) {
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.save();
        ctx.fillStyle = "rgba(242,242,243,0.55)";
        ctx.font = "500 14px Outfit, system-ui, sans-serif";
        ctx.fillText("AURA CORE demo", 18, canvas.height - 22);
        ctx.restore();
      }
    }
    canvas.toBlob((blob) => {
      if (!blob) {
        setError("Could not export the frame.");
        return;
      }
      downloadBlob(blob, `aura-frame-${Date.now()}.png`);
    }, "image/png");
  }, [setError]);

  const exportProject = useCallback(() => {
    const viz = useViz.getState();
    const lib = useLibrary.getState();
    const backdrop = lib.items.find((i) => i.id === lib.backdropId);
    const lyrics = lib.items.find((i) => i.id === lib.lyricsId);
    const project: AuraProject = {
      version: 1,
      kind: "aura-project",
      theme: viz.theme,
      mode: viz.mode,
      sensitivity: viz.sensitivity,
      analogOn: viz.analogOn,
      volume: viz.volume,
      backdropName: backdrop?.name ?? null,
      lyricsName: lyrics?.name ?? null,
      media: lib.items
        .filter((i) => !i.builtin)
        .map((i) => ({ name: i.name, kind: i.kind, mime: i.mime })),
    };
    downloadBlob(
      new Blob([JSON.stringify(project, null, 2)], { type: "application/json" }),
      "aura-project.json",
    );
  }, []);

  useEffect(() => {
    const onChange = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, [setFullscreen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === " " || e.code === "Space") {
        e.preventDefault();
        void onTogglePlay();
      } else if (e.key === "f" || e.key === "F") {
        e.preventDefault();
        void onFullscreen();
      } else if (e.key === "m" || e.key === "M") {
        const v = useViz.getState().volume;
        setVolume(v <= 0.01 ? 0.72 : 0);
      } else if (e.key === "a" || e.key === "A") {
        onToggleAnalog();
      } else if (e.key === "l" || e.key === "L") {
        e.preventDefault();
        setLibraryOpen(!useViz.getState().libraryOpen);
      } else if (e.key === "k" || e.key === "K") {
        e.preventDefault();
        const openStore = !useViz.getState().storeOpen;
        useViz.getState().setStoreOpen(openStore);
        if (openStore) useViz.getState().setCivilOpen(false);
      } else if (e.key === "g" || e.key === "G") {
        e.preventDefault();
        const openCivil = !useViz.getState().civilOpen;
        useViz.getState().setCivilOpen(openCivil);
        if (openCivil) useViz.getState().setStoreOpen(false);
      } else if (e.key === "e" || e.key === "E") {
        e.preventDefault();
        exportFrame();
      } else if (e.key === "1") useViz.getState().setMode("bars");
      else if (e.key === "2") useViz.getState().setMode("ring");
      else if (e.key === "3") useViz.getState().setMode("wave");
      else if (e.key === "4") useViz.getState().setMode("bloom");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [exportFrame, onFullscreen, onToggleAnalog, onTogglePlay, setLibraryOpen, setVolume]);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    const onOver = (e: DragEvent) => {
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
      setDragging(true);
    };
    const onLeave = (e: DragEvent) => {
      if (e.currentTarget === root && !root.contains(e.relatedTarget as Node)) {
        setDragging(false);
      }
    };
    const onDrop = (e: DragEvent) => {
      e.preventDefault();
      setDragging(false);
      const files = e.dataTransfer?.files;
      if (files?.length) void ingestFiles(Array.from(files));
    };
    root.addEventListener("dragover", onOver);
    root.addEventListener("dragleave", onLeave);
    root.addEventListener("drop", onDrop);
    return () => {
      root.removeEventListener("dragover", onOver);
      root.removeEventListener("dragleave", onLeave);
      root.removeEventListener("drop", onDrop);
    };
  }, [ingestFiles, setDragging]);

  const onInstall = useCallback(async () => {
    const pending = installRef.current;
    if (pending) {
      try {
        await pending.prompt();
        installRef.current = null;
        setCanInstall(false);
        return;
      } catch {
        /* fall through */
      }
    }
    window.location.assign("?install=1");
  }, []);

  useEffect(() => {
    const onPrompt = (event: Event) => {
      event.preventDefault();
      installRef.current = event as Event & { prompt: () => Promise<unknown> };
      setCanInstall(true);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  const dragging = useViz((s) => s.dragging);

  return (
    <div
      ref={rootRef}
      id="aura-root"
      className="relative h-dvh w-full overflow-hidden bg-bg text-fg"
      onPointerMove={bumpControls}
      onPointerDown={bumpControls}
    >
      <CanvasStage engineRef={engineRef} canvasOut={canvasOut} />
      <KernelBar onInstall={onInstall} canInstall={canInstall} />
      <BootScreen />
      <StartPanel
        onMic={onMic}
        onFile={onFile}
        onDemo={onDemo}
        onLibrary={() => {
          setLibraryOpen(true);
          fileRef.current?.click();
        }}
      />
      <AnalogDesk />
      <CivilDoor />
      <LyricsOverlay />
      <FieldNotes />
      <LicenseDesk />
      <MediaLibrary
        onPlayItem={(item) => void playItem(item)}
        onExportFrame={exportFrame}
        onExportProject={exportProject}
        onImportFiles={(files) => void ingestFiles(files)}
      />
      <ControlDock
        onMic={onMic}
        onFile={onFile}
        onDemo={onDemo}
        onTogglePlay={() => void onTogglePlay()}
        onSeek={onSeek}
        onFullscreen={() => void onFullscreen()}
        onToggleAnalog={onToggleAnalog}
        onLibrary={() => setLibraryOpen(!useViz.getState().libraryOpen)}
      />
      {dragging ? (
        <div className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center bg-bg/55">
          <p className="rounded-xl bg-surface px-6 py-3 text-sm font-medium text-fg shadow-[var(--shadow-border)]">
            Drop to import
          </p>
        </div>
      ) : null}
      <input
        ref={fileRef}
        type="file"
        multiple
        accept={IMPORT_ACCEPT}
        className="hidden"
        onChange={(e) => {
          const list = e.target.files;
          if (list?.length) void ingestFiles(Array.from(list));
          e.target.value = "";
        }}
      />
    </div>
  );
}
