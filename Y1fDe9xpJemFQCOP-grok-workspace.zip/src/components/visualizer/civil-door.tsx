import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { probeCivil } from "@/lib/visualizer/geo.functions";
import { useViz } from "@/lib/visualizer/store";
import type { GeoMask } from "@/lib/visualizer/types";

function unwrap(
  res: unknown,
): { ok: true; geo: GeoMask } | { ok: false; error: string } {
  const root = res && typeof res === "object" ? (res as Record<string, unknown>) : null;
  const payload =
    root && "result" in root && root.result && typeof root.result === "object"
      ? (root.result as Record<string, unknown>)
      : root;
  if (payload?.ok === true && payload.geo && typeof payload.geo === "object") {
    return { ok: true, geo: payload.geo as GeoMask };
  }
  const error =
    typeof payload?.error === "string" && payload.error
      ? payload.error
      : "Civil door returned no mask.";
  return { ok: false, error };
}

export function CivilDoor() {
  const open = useViz((s) => s.civilOpen);
  const setCivilOpen = useViz((s) => s.setCivilOpen);
  const geo = useViz((s) => s.geo);
  const setGeo = useViz((s) => s.setGeo);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setCivilOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, setCivilOpen]);

  if (!open) return null;

  const flags = geo
    ? [
        geo.hosting ? "hosting" : null,
        geo.proxy ? "proxy" : null,
        geo.mobile ? "mobile" : null,
      ]
        .filter(Boolean)
        .join(" · ") || "none"
    : "";

  return (
    <aside className="pointer-events-auto absolute top-12 left-0 z-30 w-full max-w-sm p-3">
      <div className="max-h-[min(70dvh,36rem)] overflow-y-auto rounded-xl bg-surface/95 p-4 shadow-[var(--shadow-border)]">
        <div className="flex items-start gap-2">
          <div className="min-w-0 flex-1">
            <p className="font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase">
              Civil door
            </p>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              One backend GET. Same field mask. Not an extra on the analog path.
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Close civil door"
            onClick={() => setCivilOpen(false)}
          >
            <X />
          </Button>
        </div>

        {geo ? (
          <dl className="mt-4 space-y-1 font-mono text-xs text-fg">
            <Row k="engine" v={geo.source} />
            <Row k="country" v={`${geo.country} (${geo.countryCode})`} />
            <Row k="city" v={geo.city || "—"} />
            <Row k="region" v={geo.regionName || geo.region || "—"} />
            <Row k="zip" v={geo.zip || "—"} />
            <Row
              k="coord"
              v={
                geo.lat != null && geo.lon != null
                  ? `${geo.lat.toFixed(2)}, ${geo.lon.toFixed(2)}`
                  : "—"
              }
            />
            <Row k="timezone" v={geo.timezone || "—"} />
            <Row k="isp" v={geo.isp || "—"} />
            <Row k="org" v={geo.org || "—"} />
            <Row k="as" v={geo.as || "—"} />
            <Row k="query" v={geo.query} />
            <Row k="flags" v={flags} />
            <Row
              k="rate"
              v={`X-Rl ${geo.remaining ?? "—"} · X-Ttl ${geo.ttl ?? "—"}`}
            />
          </dl>
        ) : !error && !busy ? (
          <p className="mt-4 text-sm text-muted">No probe yet.</p>
        ) : null}

        {error ? (
          <p className="mt-3 text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}

        <label className="mt-4 block text-xs font-medium tracking-wide text-subtle uppercase">
          Query
        </label>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="caller, or an IP"
          className="mt-1 h-11 w-full rounded-lg bg-surface-2 px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none focus-visible:ring-2 focus-visible:ring-fg/40"
          aria-label="Civil query"
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck={false}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              void runProbe(query, setBusy, setError, setGeo);
            }
          }}
        />

        <Button
          variant="solid"
          className="mt-3 w-full"
          disabled={busy}
          onClick={() => void runProbe(query, setBusy, setError, setGeo)}
        >
          {busy ? "Probing…" : "Probe caller"}
        </Button>

        <p className="mt-4 font-mono text-[0.65rem] leading-relaxed text-subtle">
          bus · analog kernel (curve) · civil door (ip-api)
          <br />
          once-only mask · no hidden listener · coordinates stay off analog extras
        </p>
      </div>
    </aside>
  );
}

async function runProbe(
  query: string,
  setBusy: (v: boolean) => void,
  setError: (v: string | null) => void,
  setGeo: (geo: GeoMask | null) => void,
) {
  setBusy(true);
  setError(null);
  const ac = new AbortController();
  const timer = window.setTimeout(() => ac.abort(), 12000);
  try {
    const res = await probeCivil({ data: { query }, signal: ac.signal });
    const parsed = unwrap(res);
    if (!parsed.ok) {
      setError(parsed.error);
      return;
    }
    setGeo(parsed.geo);
  } catch {
    setError("Civil door failed.");
  } finally {
    window.clearTimeout(timer);
    setBusy(false);
  }
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex gap-2">
      <dt className="w-20 shrink-0 text-subtle">{k}</dt>
      <dd className="min-w-0 truncate" title={v}>
        {v}
      </dd>
    </div>
  );
}
