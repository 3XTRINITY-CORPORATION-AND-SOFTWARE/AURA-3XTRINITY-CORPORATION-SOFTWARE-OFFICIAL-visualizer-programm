import { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  CHECKOUT_URL,
  CORE_PRICE,
  GITHUB_REPO,
  isLicensed,
  redeemKey,
} from "@/lib/visualizer/core";
import { useViz } from "@/lib/visualizer/store";

export function LicenseDesk() {
  const open = useViz((s) => s.storeOpen);
  const setStoreOpen = useViz((s) => s.setStoreOpen);
  const license = useViz((s) => s.license);
  const setLicense = useViz((s) => s.setLicense);
  const [key, setKey] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  if (!open) return null;

  const licensed = isLicensed(license.plan);

  return (
    <aside className="absolute top-12 right-0 z-30 w-full max-w-sm p-3 sm:top-12">
      <div className="rounded-xl bg-surface/95 p-4 shadow-[var(--shadow-border)]">
        <div className="flex items-start gap-2">
          <div className="min-w-0 flex-1">
            <p className="font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase">
              License
            </p>
            <h2 className="font-display mt-2 text-2xl font-semibold tracking-[-0.04em]">
              AURA CORE
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              Installable kernel. Analog 44.1 path. Same bit format. Clean
              exports without a demo stamp.
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Close license"
            onClick={() => setStoreOpen(false)}
          >
            <X />
          </Button>
        </div>

        <p className="mt-4 font-display text-3xl font-semibold">{CORE_PRICE}</p>
        <p className="text-xs text-subtle">one-time · CORE studio seat</p>

        {licensed ? (
          <p className="mt-4 rounded-lg bg-fg/10 px-3 py-2 text-sm text-fg">
            Licensed · {license.plan} · {license.key}
          </p>
        ) : (
          <>
            <a
              href={CHECKOUT_URL}
              target="_blank"
              rel="noreferrer"
              className="mt-4 inline-flex h-11 w-full items-center justify-center rounded-lg bg-fg text-sm font-medium text-bg hover:opacity-90"
            >
              Buy CORE
            </a>
            <Button
              variant="secondary"
              className="mt-2 w-full"
              onClick={() => {
                const next = redeemKey("CORE-1900");
                if (next) {
                  setLicense(next);
                  setMsg("Tonight’s launch seat is active.");
                }
              }}
            >
              Unlock tonight
            </Button>
            <label className="mt-4 block text-xs font-medium tracking-wide text-subtle uppercase">
              License key
            </label>
            <input
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="CORE-1900"
              className="mt-1 h-11 w-full rounded-lg bg-surface-2 px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none focus-visible:ring-2 focus-visible:ring-fg/40"
              aria-label="License key"
            />
            <Button
              variant="secondary"
              className="mt-2 w-full"
              onClick={() => {
                const next = redeemKey(key);
                if (!next) {
                  setMsg("That key is not valid.");
                  return;
                }
                setLicense(next);
                setMsg("Seat unlocked.");
              }}
            >
              Redeem
            </Button>
            {msg ? <p className="mt-2 text-sm text-muted">{msg}</p> : null}
            <p className="mt-3 text-xs leading-relaxed text-subtle">
              Tonight’s launch key is CORE-1900. After checkout, redeem the
              key from the receipt.
            </p>
          </>
        )}

        <a
          href={GITHUB_REPO}
          target="_blank"
          rel="noreferrer"
          className="mt-4 inline-block text-xs text-muted underline-offset-2 hover:text-fg hover:underline"
        >
          Source on GitHub
        </a>
      </div>
    </aside>
  );
}
