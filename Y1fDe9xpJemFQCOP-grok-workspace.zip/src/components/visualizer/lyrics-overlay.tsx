import { useViz } from "@/lib/visualizer/store";

export function LyricsOverlay() {
  const text = useViz((s) => s.overlayText);
  if (!text.trim()) return null;
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .slice(0, 8);
  if (!lines.length) return null;
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-24 z-10 flex justify-center px-6 sm:bottom-28">
      <p className="max-w-xl text-center font-display text-sm leading-relaxed text-fg/90 text-balance sm:text-base">
        {lines.join(" · ")}
      </p>
    </div>
  );
}
