import { useViz } from "@/lib/visualizer/store";
import { cn } from "@/lib/utils";

export function AnalogDesk() {
  const analogOn = useViz((s) => s.analogOn);
  const analyzing = useViz((s) => s.analyzing);
  const genre = useViz((s) => s.genre);
  const bpm = useViz((s) => s.bpm);
  const curveComment = useViz((s) => s.curveComment);
  const sampleRate = useViz((s) => s.sampleRate);
  const channels = useViz((s) => s.channels);
  const bitLabel = useViz((s) => s.bitLabel);
  const spectrum = useViz((s) => s.spectrum);
  const fileName = useViz((s) => s.fileName);
  const source = useViz((s) => s.source);
  const controlsOpen = useViz((s) => s.controlsOpen);

  if (source === "none") return null;
  if (!analogOn && !genre && !analyzing) return null;

  const rateLabel =
    sampleRate != null
      ? `${(sampleRate / 1000).toFixed(1)} kHz`
      : "44.1 kHz";

  return (
    <aside
      className={cn(
        "pointer-events-none absolute top-10 left-0 z-20 max-w-sm p-3 pt-[max(0.75rem,env(safe-area-inset-top))]",
        "transition-opacity duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
        controlsOpen ? "opacity-100" : "opacity-0",
      )}
    >
      <div className="pointer-events-auto rounded-xl bg-surface/92 p-3 shadow-[var(--shadow-border)]">
        <p className="font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase">
          Analog desk
        </p>
        <ol className="mt-3 space-y-3">
          <li>
            <p className="text-xs font-medium tracking-wide text-subtle uppercase">
              1 · Genre
            </p>
            <p className="mt-1 text-sm font-medium text-fg">
              {analyzing ? "Reading the room…" : (genre ?? "Awaiting a track")}
            </p>
          </li>
          <li>
            <p className="text-xs font-medium tracking-wide text-subtle uppercase">
              2 · Decision
            </p>
            <div className="mt-2 flex h-8 items-end gap-px">
              {(spectrum.length ? spectrum : Array.from({ length: 24 }, () => 0.12)).map(
                (v, i) => (
                  <span
                    key={i}
                    className="min-w-0 flex-1 rounded-sm bg-fg/70"
                    style={{ height: `${Math.max(8, Math.round(v * 100))}%` }}
                  />
                ),
              )}
            </div>
            <p className="mt-1.5 font-mono text-xs tabular-nums text-muted">
              {bpm != null ? `${bpm} BPM` : "— BPM"} · spectrogram
            </p>
          </li>
          <li>
            <p className="text-xs font-medium tracking-wide text-subtle uppercase">
              3 · Track
            </p>
            <p className="mt-1 truncate text-sm text-fg">
              {fileName ?? (source === "demo" ? "Ambient demo" : "Live input")}
            </p>
            <p className="mt-0.5 font-mono text-xs text-subtle">
              {rateLabel}
              {channels ? ` · ${channels} ch` : ""} · {bitLabel || "same bit format"}
            </p>
            {curveComment ? (
              <p className="mt-2 line-clamp-3 text-xs leading-relaxed text-muted text-pretty">
                {curveComment}
              </p>
            ) : (
              <p className="mt-2 text-xs leading-relaxed text-muted">
                Original fundamentals mixed with analog mirroring. Cut before
                boost. No resample.
              </p>
            )}
          </li>
        </ol>
      </div>
    </aside>
  );
}
