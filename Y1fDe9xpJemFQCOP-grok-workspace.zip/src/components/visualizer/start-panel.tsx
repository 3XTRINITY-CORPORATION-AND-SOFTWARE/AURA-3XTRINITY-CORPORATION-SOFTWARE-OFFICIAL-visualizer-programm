import { AudioLines, BookOpen, FolderOpen, Mic, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useViz } from "@/lib/visualizer/store";

export function StartPanel({
  onMic,
  onFile,
  onDemo,
  onLibrary,
}: {
  onMic: () => void;
  onFile: () => void;
  onDemo: () => void;
  onLibrary: () => void;
}) {
  const error = useViz((s) => s.error);
  const source = useViz((s) => s.source);
  const notesOpen = useViz((s) => s.notesOpen);
  const libraryOpen = useViz((s) => s.libraryOpen);
  const storeOpen = useViz((s) => s.storeOpen);
  const civilOpen = useViz((s) => s.civilOpen);
  const booting = useViz((s) => s.booting);
  const setNotesOpen = useViz((s) => s.setNotesOpen);
  const setStoreOpen = useViz((s) => s.setStoreOpen);
  if (source !== "none") return null;
  if (booting || notesOpen || libraryOpen || storeOpen || civilOpen) return null;

  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center p-4">
      <div className="pointer-events-auto w-full max-w-md rounded-2xl bg-surface/90 p-6 text-center shadow-[var(--shadow-border)]">
        <p className="font-display text-xs font-medium tracking-[0.22em] text-muted uppercase">
          CORE 0.9
        </p>
        <h1 className="font-display mt-3 text-4xl font-semibold tracking-[-0.04em] text-fg text-balance sm:text-5xl">
          AURA
        </h1>
        <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-muted text-pretty">
          Analog kernel. Install it. Import a track. Same bit format out.
        </p>
        {error ? (
          <p className="mt-4 text-sm text-danger" role="alert">
            {error}
          </p>
        ) : null}
        <div className="mt-6 flex flex-col gap-2 min-[520px]:grid min-[520px]:grid-cols-3">
          <Button variant="solid" onClick={onMic} className="w-full rounded-sm">
            <Mic />
            Microphone
          </Button>
          <Button variant="secondary" onClick={onFile} className="w-full rounded-sm">
            <Upload />
            Open track
          </Button>
          <Button variant="outline" onClick={onDemo} className="w-full rounded-sm">
            <AudioLines />
            Play demo
          </Button>
        </div>
        <div className="mt-2 flex flex-col gap-2 min-[520px]:grid min-[520px]:grid-cols-3">
          <Button variant="ghost" className="w-full" onClick={onLibrary}>
            <FolderOpen />
            Import
          </Button>
          <Button variant="ghost" className="w-full" onClick={() => setNotesOpen(true)}>
            <BookOpen />
            Notes
          </Button>
          <Button variant="ghost" className="w-full" onClick={() => setStoreOpen(true)}>
            License
          </Button>
        </div>
        <p className="mt-3 text-xs text-subtle">
          Install from the kernel bar. L library · E frame · K license.
        </p>
      </div>
    </div>
  );
}
