import { useEffect, useState } from "react";
import { BOOT_LINES } from "@/lib/visualizer/core";
import { useViz } from "@/lib/visualizer/store";

export function BootScreen() {
  const booting = useViz((s) => s.booting);
  const setBooting = useViz((s) => s.setBooting);
  const [n, setN] = useState(1);

  useEffect(() => {
    if (!booting) return;
    const id = window.setInterval(() => {
      setN((v) => {
        if (v >= BOOT_LINES.length) {
          window.clearInterval(id);
          window.setTimeout(() => setBooting(false), 280);
          return v;
        }
        return v + 1;
      });
    }, 220);
    return () => window.clearInterval(id);
  }, [booting, setBooting]);

  if (!booting) return null;

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-bg">
      <div className="w-full max-w-sm px-6 font-mono text-xs leading-6 text-muted">
        {BOOT_LINES.slice(0, n).map((line) => (
          <p key={line} className={line.startsWith("AURA") ? "text-fg" : undefined}>
            {line}
          </p>
        ))}
        <p className="mt-4 text-subtle">ok</p>
      </div>
    </div>
  );
}
