import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { NOTE_FILES, PLATES } from "@/lib/visualizer/plates";
import { useViz } from "@/lib/visualizer/store";
import { cn } from "@/lib/utils";

export function FieldNotes() {
  const open = useViz((s) => s.notesOpen);
  const setNotesOpen = useViz((s) => s.setNotesOpen);
  const [i, setI] = useState(0);
  const plate = PLATES[i]!;

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setNotesOpen(false);
      if (e.key === "ArrowRight") setI((n) => (n + 1) % PLATES.length);
      if (e.key === "ArrowLeft")
        setI((n) => (n - 1 + PLATES.length) % PLATES.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, setNotesOpen]);

  if (!open) return null;

  return (
    <div className="absolute inset-0 z-40 flex bg-bg text-fg">
      <div className="relative min-w-0 flex-1 bg-surface">
        <img
          src={`/notes/plates/${plate.file}`}
          alt={plate.title}
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-x-0 bottom-0 bg-bg/70 p-4 sm:hidden">
          <p className="font-display text-lg font-semibold">{plate.title}</p>
          <p className="mt-1 text-sm text-muted">{plate.note}</p>
        </div>
      </div>
      <aside className="hidden w-[min(100%,22rem)] shrink-0 flex-col justify-between overflow-y-auto p-5 sm:flex">
        <div>
          <p className="font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase">
            Field notes
          </p>
          <h2 className="font-display mt-3 text-3xl font-semibold tracking-[-0.04em]">
            Analog 44.1
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-muted text-pretty">
            Original fundamentals mixed with analog mirroring. Same bit format.
            Cut before boost.
          </p>
          <p className="mt-8 text-xs font-medium tracking-wide text-subtle uppercase">
            Plate {String(i + 1).padStart(2, "0")} / {String(PLATES.length).padStart(2, "0")}
          </p>
          <p className="mt-2 font-display text-xl font-semibold">{plate.title}</p>
          <p className="mt-2 text-sm leading-relaxed text-muted">{plate.note}</p>
        </div>
        <div>
          <p className="text-xs font-medium tracking-wide text-subtle uppercase">
            Downloads
          </p>
          <div className="mt-2 grid grid-cols-2 gap-2">
            {NOTE_FILES.map((f) => (
              <a
                key={f.href}
                href={f.href}
                download
                className={cn(
                  "inline-flex h-11 items-center justify-center rounded-lg text-sm font-medium",
                  "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:bg-surface-2/80",
                )}
              >
                {f.label}
              </a>
            ))}
          </div>
        </div>
      </aside>
      <div className="absolute top-3 right-3 flex gap-1">
        <Button
          variant="ghost"
          size="icon-sm"
          aria-label="Previous plate"
          onClick={() => setI((n) => (n - 1 + PLATES.length) % PLATES.length)}
        >
          <ChevronLeft />
        </Button>
        <Button
          variant="ghost"
          size="icon-sm"
          aria-label="Next plate"
          onClick={() => setI((n) => (n + 1) % PLATES.length)}
        >
          <ChevronRight />
        </Button>
        <Button
          variant="ghost"
          size="icon-sm"
          aria-label="Close field notes"
          onClick={() => setNotesOpen(false)}
        >
          <X />
        </Button>
      </div>
      <div className="absolute right-3 bottom-3 grid grid-cols-2 gap-2 sm:hidden">
        {NOTE_FILES.map((f) => (
          <a
            key={f.href}
            href={f.href}
            download
            className="inline-flex h-10 items-center justify-center rounded-md bg-surface px-3 text-xs font-medium text-fg shadow-[var(--shadow-border)]"
          >
            {f.label}
          </a>
        ))}
      </div>
    </div>
  );
}
