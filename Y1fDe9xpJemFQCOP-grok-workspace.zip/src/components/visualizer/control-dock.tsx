import type { ReactNode } from "react";
import {
  Aperture,
  BarChart3,
  CircleDot,
  Disc3,
  FolderOpen,
  Maximize2,
  Mic,
  Minimize2,
  Pause,
  Play,
  Upload,
  Volume2,
  VolumeX,
  Waves,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { cn, formatTime } from "@/lib/utils";
import { THEMES } from "@/lib/visualizer/themes";
import type { ThemeId, VizMode } from "@/lib/visualizer/types";
import { THEME_IDS } from "@/lib/visualizer/types";
import { useViz } from "@/lib/visualizer/store";

const MODE_ICONS: Record<VizMode, typeof BarChart3> = {
  bars: BarChart3,
  ring: CircleDot,
  wave: Waves,
  bloom: Aperture,
};

export function ControlDock({
  onMic,
  onFile,
  onDemo,
  onTogglePlay,
  onSeek,
  onFullscreen,
  onToggleAnalog,
  onLibrary,
}: {
  onMic: () => void;
  onFile: () => void;
  onDemo: () => void;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onFullscreen: () => void;
  onToggleAnalog: () => void;
  onLibrary: () => void;
}) {
  const source = useViz((s) => s.source);
  const playing = useViz((s) => s.playing);
  const mode = useViz((s) => s.mode);
  const theme = useViz((s) => s.theme);
  const sensitivity = useViz((s) => s.sensitivity);
  const volume = useViz((s) => s.volume);
  const fileName = useViz((s) => s.fileName);
  const duration = useViz((s) => s.duration);
  const currentTime = useViz((s) => s.currentTime);
  const fullscreen = useViz((s) => s.fullscreen);
  const open = useViz((s) => s.controlsOpen);
  const analogOn = useViz((s) => s.analogOn);
  const libraryOpen = useViz((s) => s.libraryOpen);
  const setMode = useViz((s) => s.setMode);
  const setTheme = useViz((s) => s.setTheme);
  const setSensitivity = useViz((s) => s.setSensitivity);
  const setVolume = useViz((s) => s.setVolume);

  const canPlay = source === "file" || source === "demo";
  const showProgress = source === "file" && duration > 0;
  const status =
    source === "mic"
      ? "Listening"
      : source === "demo"
        ? "Ambient demo"
        : source === "file"
          ? fileName ?? "Track"
          : "Idle";

  return (
    <div
      className={cn(
        "pointer-events-none absolute inset-x-0 bottom-0 z-20 flex justify-center px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-10",
        "transition-[opacity,transform] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
        open
          ? "opacity-100 translate-y-0"
          : "opacity-0 translate-y-2 pointer-events-none",
      )}
    >
      <div
        className={cn(
          "pointer-events-auto w-full max-w-4xl rounded-xl bg-surface/92 p-2 shadow-[var(--shadow-border)]",
          "flex flex-col gap-2",
        )}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 px-1">
          <span
            className={cn(
              "size-1.5 shrink-0 rounded-full",
              source === "mic" && playing
                ? "bg-fg animate-pulse"
                : source !== "none" && playing
                  ? "bg-fg"
                  : "bg-subtle",
            )}
            aria-hidden
          />
          <p className="min-w-0 flex-1 truncate text-xs font-medium text-muted">
            {status}
          </p>
          {showProgress ? (
            <span className="shrink-0 font-mono text-[0.7rem] tabular-nums text-subtle">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>
          ) : null}
        </div>

        {showProgress ? (
          <Slider
            min={0}
            max={duration}
            step={0.1}
            value={[currentTime]}
            onValueChange={(v) => onSeek(v[0] ?? 0)}
            aria-label="Seek"
            className="px-1 py-1"
          />
        ) : null}

        <div className="flex flex-col gap-1.5 sm:flex-row sm:items-center sm:gap-1.5">
          <div className="flex items-center gap-1">
            <IconBtn
              label="Microphone"
              pressed={source === "mic"}
              onClick={onMic}
            >
              <Mic />
            </IconBtn>
            <IconBtn
              label="Open track"
              pressed={source === "file"}
              onClick={onFile}
            >
              <Upload />
            </IconBtn>
            {canPlay ? (
              <IconBtn
                label={playing ? "Pause" : "Play"}
                onClick={onTogglePlay}
              >
                {playing ? <Pause /> : <Play className="ml-px" />}
              </IconBtn>
            ) : (
              <IconBtn label="Play demo" onClick={onDemo}>
                <Play className="ml-px" />
              </IconBtn>
            )}
            <div className="mx-1 hidden h-6 w-px bg-border sm:block" />
            <div
              className="flex items-center"
              role="group"
              aria-label="Visualization mode"
            >
              {(["bars", "ring", "wave", "bloom"] as VizMode[]).map((id) => {
                const Icon = MODE_ICONS[id];
                return (
                  <IconBtn
                    key={id}
                    label={id[0]!.toUpperCase() + id.slice(1)}
                    pressed={mode === id}
                    onClick={() => setMode(id)}
                  >
                    <Icon />
                  </IconBtn>
                );
              })}
            </div>
          </div>

          <div className="flex min-w-0 flex-1 items-center gap-2">
            <div
              className="flex items-center gap-1.5 px-1"
              role="group"
              aria-label="Color theme"
            >
              {THEME_IDS.map((id) => (
                <ThemeDot
                  key={id}
                  id={id}
                  active={theme === id}
                  onClick={() => setTheme(id)}
                />
              ))}
            </div>
            <label className="hidden shrink-0 text-[0.65rem] font-medium tracking-wide text-subtle uppercase md:block">
              Sense
            </label>
            <Slider
              min={0.4}
              max={2.2}
              step={0.01}
              value={[sensitivity]}
              onValueChange={(v) => setSensitivity(v[0] ?? 1)}
              aria-label="Sensitivity"
              className="min-w-0 flex-1 py-2"
            />
            <IconBtn
              label={volume <= 0.01 ? "Unmute" : "Mute"}
              onClick={() => setVolume(volume <= 0.01 ? 0.72 : 0)}
            >
              {volume <= 0.01 ? <VolumeX /> : <Volume2 />}
            </IconBtn>
            <Slider
              min={0}
              max={1}
              step={0.01}
              value={[volume]}
              onValueChange={(v) => setVolume(v[0] ?? 0)}
              aria-label="Volume"
              className="hidden min-w-16 max-w-24 py-2 sm:flex"
            />
            <IconBtn
              label={analogOn ? "Analog path on" : "Analog path off"}
              pressed={analogOn}
              onClick={onToggleAnalog}
            >
              <Disc3 />
            </IconBtn>
            <IconBtn
              label="Media library"
              pressed={libraryOpen}
              onClick={onLibrary}
            >
              <FolderOpen />
            </IconBtn>
            <IconBtn
              label={fullscreen ? "Exit fullscreen" : "Fullscreen"}
              onClick={onFullscreen}
            >
              {fullscreen ? <Minimize2 /> : <Maximize2 />}
            </IconBtn>
          </div>
        </div>
      </div>
    </div>
  );
}

function IconBtn({
  label,
  pressed,
  onClick,
  children,
}: {
  label: string;
  pressed?: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon-sm"
      aria-label={label}
      aria-pressed={pressed}
      title={label}
      onClick={onClick}
      className={cn(pressed && "bg-fg/10 text-fg")}
    >
      {children}
    </Button>
  );
}

function ThemeDot({
  id,
  active,
  onClick,
}: {
  id: ThemeId;
  active: boolean;
  onClick: () => void;
}) {
  const t = THEMES[id];
  return (
    <button
      type="button"
      title={t.label}
      aria-label={`${t.label} theme`}
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "size-6 rounded-full transition-[transform,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)]",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40",
        active ? "scale-110" : "opacity-80 hover:opacity-100",
      )}
      style={{
        background: `rgb(${t.a[0]}, ${t.a[1]}, ${t.a[2]})`,
        boxShadow: active
          ? `0 0 0 2px var(--color-bg), 0 0 0 4px rgb(${t.c[0]} ${t.c[1]} ${t.c[2]})`
          : "0 0 0 1px rgb(242 242 243 / 0.18)",
      }}
    />
  );
}
