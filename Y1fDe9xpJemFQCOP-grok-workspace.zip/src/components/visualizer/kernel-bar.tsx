import { Download, Globe, KeyRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CORE_VERSION, isLicensed, isStandalone } from "@/lib/visualizer/core";
import { useViz } from "@/lib/visualizer/store";
import { cn } from "@/lib/utils";

export function KernelBar({
  onInstall,
  canInstall,
}: {
  onInstall: () => void;
  canInstall: boolean;
}) {
  const analogOn = useViz((s) => s.analogOn);
  const sampleRate = useViz((s) => s.sampleRate);
  const license = useViz((s) => s.license);
  const storeOpen = useViz((s) => s.storeOpen);
  const setStoreOpen = useViz((s) => s.setStoreOpen);
  const civilOpen = useViz((s) => s.civilOpen);
  const setCivilOpen = useViz((s) => s.setCivilOpen);
  const geo = useViz((s) => s.geo);
  const installed = isStandalone();
  const rate =
    sampleRate != null ? `${(sampleRate / 1000).toFixed(1)}` : "44.1";

  return (
    <header className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-center justify-between gap-2 px-3 pt-[max(0.4rem,env(safe-area-inset-top))]">
      <p className="pointer-events-none min-w-0 truncate font-mono text-[0.65rem] tracking-wide text-subtle">
        CORE {CORE_VERSION}
        <span className="mx-2 text-border-strong">·</span>
        {analogOn ? "analog" : "dry"}
        <span className="mx-2 text-border-strong">·</span>
        {rate} kHz
        <span className="mx-2 text-border-strong">·</span>
        {isLicensed(license.plan) ? license.plan : "demo"}
        {geo?.countryCode ? (
          <>
            <span className="mx-2 text-border-strong">·</span>
            {geo.countryCode}
          </>
        ) : null}
      </p>
      <div className="pointer-events-auto flex shrink-0 items-center gap-1">
        {canInstall && !installed ? (
          <Button variant="ghost" size="sm" onClick={onInstall}>
            <Download />
            Install
          </Button>
        ) : null}
        <Button
          variant="ghost"
          size="sm"
          aria-pressed={civilOpen}
          onClick={() => {
            const next = !civilOpen;
            setCivilOpen(next);
            if (next) setStoreOpen(false);
          }}
          className={cn(civilOpen && "bg-fg/10 text-fg")}
        >
          <Globe />
          Civil
        </Button>
        <Button
          variant="ghost"
          size="sm"
          aria-pressed={storeOpen}
          onClick={() => {
            const next = !storeOpen;
            setStoreOpen(next);
            if (next) setCivilOpen(false);
          }}
          className={cn(storeOpen && "bg-fg/10 text-fg")}
        >
          <KeyRound />
          License
        </Button>
      </div>
    </header>
  );
}
