import { useEffect, useRef, type MutableRefObject } from "react";
import { AudioEngine, type Analysis } from "@/lib/visualizer/audio";
import { useLibrary } from "@/lib/visualizer/media";
import { VisualizerRenderer } from "@/lib/visualizer/renderer";
import { useViz } from "@/lib/visualizer/store";

export function CanvasStage({
  engineRef,
  canvasOut,
}: {
  engineRef: MutableRefObject<AudioEngine | null>;
  canvasOut: MutableRefObject<HTMLCanvasElement | null>;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const loopVideoRef = useRef<HTMLVideoElement | null>(null);
  const mode = useViz((s) => s.mode);
  const theme = useViz((s) => s.theme);
  const sensitivity = useViz((s) => s.sensitivity);
  const source = useViz((s) => s.source);
  const playing = useViz((s) => s.playing);
  const backdropId = useLibrary((s) => s.backdropId);
  const items = useLibrary((s) => s.items);

  useEffect(() => {
    canvasOut.current = canvasRef.current;
  });

  useEffect(() => {
    const item = items.find((x) => x.id === backdropId);
    let dead = false;
    const prevLoop = loopVideoRef.current;
    if (prevLoop) {
      prevLoop.pause();
      loopVideoRef.current = null;
    }
    if (!item || (item.kind !== "image" && item.kind !== "video")) {
      imgRef.current = null;
      return;
    }
    void useLibrary.getState().objectUrl(item).then((url) => {
      if (!url || dead) return;
      if (item.kind === "image") {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
          if (!dead) imgRef.current = img;
        };
        img.src = url;
        return;
      }
      const v = document.createElement("video");
      v.crossOrigin = "anonymous";
      v.muted = true;
      v.loop = true;
      v.playsInline = true;
      v.src = url;
      v.onloadeddata = () => {
        if (dead) return;
        loopVideoRef.current = v;
        void v.play().catch(() => undefined);
      };
    });
    return () => {
      dead = true;
    };
  }, [backdropId, items]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const renderer = new VisualizerRenderer(canvas);
    let raf = 0;
    let last = performance.now();
    const empty: Analysis | null = null;

    const loop = (now: number) => {
      const raw = (now - last) / 1000;
      const dt = Math.min(raw, 0.1);
      last = now;
      const state = useViz.getState();
      const engine = engineRef.current;
      const live =
        state.source !== "none" &&
        (state.source === "mic" || state.playing);
      const analysis = live && engine ? engine.sample() : empty;
      const media =
        engine?.visualVideo && engine.visualVideo.readyState >= 2
          ? engine.visualVideo
          : loopVideoRef.current && loopVideoRef.current.readyState >= 2
            ? loopVideoRef.current
            : imgRef.current;
      renderer.frame(
        dt,
        analysis,
        live,
        state.mode,
        state.theme,
        state.sensitivity,
        now / 1000,
        media,
      );
      const el = engine?.mediaEl;
      if (state.source === "file" && el) {
        const t = el.currentTime;
        if (Math.abs(t - state.currentTime) > 0.15) {
          useViz.getState().setCurrentTime(t);
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const onVis = () => {
      if (document.visibilityState === "visible") {
        void engineRef.current?.unlock();
      }
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [engineRef]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 size-full touch-none"
      aria-hidden="true"
      data-mode={mode}
      data-theme={theme}
      data-sensitivity={sensitivity}
      data-source={source}
      data-playing={playing ? "1" : "0"}
    />
  );
}
