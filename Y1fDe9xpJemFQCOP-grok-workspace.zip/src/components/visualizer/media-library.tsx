import { useEffect, useMemo, useRef, useState } from "react";
import {
  Download,
  FileText,
  Film,
  ImageIcon,
  Music,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  formatBytes,
  useLibrary,
  type MediaKind,
  type MediaItem,
} from "@/lib/visualizer/media";
import { useViz } from "@/lib/visualizer/store";
import { cn } from "@/lib/utils";

const ACCEPT =
  "audio/*,video/*,image/*,text/plain,.mp3,.wav,.ogg,.flac,.fl,.m4a,.aac,.mp4,.webm,.mov,.m4v,.jpg,.jpeg,.png,.webp,.gif,.svg,.txt,.lrc,.md,.json,.srt,.csv,.aura.json";

const FILTERS: { id: "all" | MediaKind; label: string }[] = [
  { id: "all", label: "All" },
  { id: "audio", label: "Audio" },
  { id: "image", label: "Image" },
  { id: "video", label: "Video" },
  { id: "text", label: "Text" },
];

export function MediaLibrary({
  onPlayItem,
  onExportFrame,
  onExportProject,
  onImportFiles,
}: {
  onPlayItem: (item: MediaItem) => void;
  onExportFrame: () => void;
  onExportProject: () => void;
  onImportFiles: (files: File[]) => void;
}) {
  const open = useViz((s) => s.libraryOpen);
  const setLibraryOpen = useViz((s) => s.setLibraryOpen);
  const items = useLibrary((s) => s.items);
  const backdropId = useLibrary((s) => s.backdropId);
  const lyricsId = useLibrary((s) => s.lyricsId);
  const remove = useLibrary((s) => s.remove);
  const setBackdrop = useLibrary((s) => s.setBackdrop);
  const setLyrics = useLibrary((s) => s.setLyrics);
  const setOverlayText = useViz((s) => s.setOverlayText);
  const inputRef = useRef<HTMLInputElement>(null);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");

  const visible = useMemo(
    () => (filter === "all" ? items : items.filter((i) => i.kind === filter)),
    [filter, items],
  );

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLibraryOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, setLibraryOpen]);

  if (!open) return null;

  return (
    <aside className="absolute top-0 right-0 z-30 flex h-full w-full max-w-sm flex-col bg-surface/95 p-3 pt-[max(0.75rem,env(safe-area-inset-top))] shadow-[var(--shadow-border)] sm:m-3 sm:h-auto sm:max-h-[min(34rem,calc(100dvh-6rem))] sm:rounded-xl">
      <div className="flex items-center gap-2">
        <div className="min-w-0 flex-1">
          <p className="font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase">
            Library
          </p>
          <p className="mt-1 truncate text-sm text-muted">
            Import a track, still, clip, or text.
          </p>
        </div>
        <Button
          variant="ghost"
          size="icon-sm"
          aria-label="Close library"
          onClick={() => setLibraryOpen(false)}
        >
          <X />
        </Button>
      </div>

      <div className="mt-3 flex gap-1">
        <Button
          variant="solid"
          size="sm"
          className="flex-1"
          onClick={() => inputRef.current?.click()}
        >
          <Upload />
          Import
        </Button>
        <Button variant="secondary" size="sm" onClick={onExportFrame}>
          <Download />
          Frame
        </Button>
        <Button variant="outline" size="sm" onClick={onExportProject}>
          Project
        </Button>
      </div>

      <div className="mt-3 flex gap-1" role="tablist" aria-label="Media type">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            role="tab"
            aria-selected={filter === f.id}
            onClick={() => setFilter(f.id)}
            className={cn(
              "h-9 flex-1 rounded-md text-xs font-medium",
              filter === f.id ? "bg-fg/10 text-fg" : "text-muted hover:text-fg",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <ul className="mt-2 min-h-0 flex-1 space-y-1 overflow-y-auto">
        {visible.length === 0 ? (
          <li className="px-1 py-6 text-center text-sm text-muted">
            Nothing here yet. Import a file or drop it on the stage.
          </li>
        ) : (
          visible.map((item) => (
            <li
              key={item.id}
              className={cn(
                "flex items-center gap-2 rounded-lg px-2 py-1.5",
                backdropId === item.id || lyricsId === item.id
                  ? "bg-fg/10"
                  : "hover:bg-fg/5",
              )}
            >
              <KindIcon kind={item.kind} />
              <button
                type="button"
                className="min-w-0 flex-1 text-left"
                onClick={() => {
                  if (item.kind === "audio" || item.kind === "video") {
                    onPlayItem(item);
                  } else if (item.kind === "image") {
                    setBackdrop(item.id);
                  } else {
                    void useLibrary.getState().readText(item).then((t) => {
                      setOverlayText(t);
                      setLyrics(item.id);
                    });
                  }
                }}
              >
                <p className="truncate text-sm font-medium text-fg">{item.name}</p>
                <p className="truncate text-xs text-subtle">
                  {item.kind} · {formatBytes(item.size)}
                </p>
              </button>
              {!item.builtin ? (
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label={`Remove ${item.name}`}
                  onClick={() => void remove(item.id)}
                >
                  <Trash2 />
                </Button>
              ) : null}
            </li>
          ))
        )}
      </ul>

      <input
        ref={inputRef}
        type="file"
        multiple
        accept={ACCEPT}
        className="hidden"
        onChange={(e) => {
          const list = e.target.files;
          if (list?.length) onImportFiles(Array.from(list));
          e.target.value = "";
        }}
      />
    </aside>
  );
}

function KindIcon({ kind }: { kind: MediaKind }) {
  const Icon =
    kind === "audio"
      ? Music
      : kind === "video"
        ? Film
        : kind === "text"
          ? FileText
          : ImageIcon;
  return (
    <span className="flex size-9 shrink-0 items-center justify-center rounded-md bg-surface-2 text-muted">
      <Icon className="size-4" />
    </span>
  );
}
