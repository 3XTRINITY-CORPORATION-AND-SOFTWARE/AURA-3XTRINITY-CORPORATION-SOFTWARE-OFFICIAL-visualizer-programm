import * as React from "react";
import * as SliderPrimitive from "@radix-ui/react-slider";
import { cn } from "@/lib/utils";

function Slider({
  className,
  defaultValue,
  value,
  min = 0,
  max = 100,
  ...props
}: React.ComponentProps<typeof SliderPrimitive.Root>) {
  const _values = React.useMemo(
    () =>
      Array.isArray(value)
        ? value
        : Array.isArray(defaultValue)
          ? defaultValue
          : [min],
    [value, defaultValue, min],
  );

  return (
    <SliderPrimitive.Root
      data-slot="slider"
      defaultValue={defaultValue}
      value={value}
      min={min}
      max={max}
      className={cn(
        "relative flex w-full touch-none items-center select-none py-3",
        className,
      )}
      {...props}
    >
      <SliderPrimitive.Track className="bg-fg/15 relative h-1 w-full grow overflow-hidden rounded-full">
        <SliderPrimitive.Range className="bg-fg absolute h-full" />
      </SliderPrimitive.Track>
      {_values.map((_, i) => (
        <SliderPrimitive.Thumb
          key={i}
          className="border-bg bg-fg block size-3.5 rounded-full border-2 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-[var(--motion-micro)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40"
        />
      ))}
    </SliderPrimitive.Root>
  );
}

export { Slider };
