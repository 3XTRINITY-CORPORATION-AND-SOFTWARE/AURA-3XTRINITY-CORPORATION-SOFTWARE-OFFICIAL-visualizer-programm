import { ANALOG_CURVES, type AnalogCurve, type GenreId } from "./analog-eq";

export type TrackReport = {
  genre: GenreId;
  genreLabel: string;
  bpm: number;
  curve: AnalogCurve;
  sampleRate: number;
  channels: number;
  duration: number;
  bitLabel: string;
  spectrum: number[];
};

function monoMix(buffer: AudioBuffer, maxSeconds: number): Float32Array {
  const sr = buffer.sampleRate;
  const len = Math.min(buffer.length, Math.floor(sr * maxSeconds));
  const out = new Float32Array(len);
  const ch = buffer.numberOfChannels;
  for (let c = 0; c < ch; c++) {
    const data = buffer.getChannelData(c);
    for (let i = 0; i < len; i++) out[i] += data[i]! / ch;
  }
  return out;
}

function estimateBpm(samples: Float32Array, sr: number): number {
  const hop = 512;
  const win = 1024;
  const env: number[] = [];
  const limit = Math.min(samples.length, sr * 8);
  for (let i = 0; i + win < limit; i += hop) {
    let e = 0;
    for (let j = 0; j < win; j++) e += Math.abs(samples[i + j]!);
    env.push(e / win);
  }
  if (env.length < 24) return 120;
  const flux = env.map((v, i) => (i === 0 ? 0 : Math.max(0, v - env[i - 1]!)));
  const hopTime = hop / sr;
  let bestBpm = 120;
  let best = 0;
  for (let bpm = 70; bpm <= 180; bpm++) {
    const lag = Math.round(60 / bpm / hopTime);
    if (lag < 1 || lag >= flux.length) continue;
    let s = 0;
    for (let i = 0; i < flux.length - lag; i++) s += flux[i]! * flux[i + lag]!;
    if (s > best) {
      best = s;
      bestBpm = bpm;
    }
  }
  return bestBpm;
}

function dftRadix2(re: Float32Array, im: Float32Array) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      const tr = re[i]!;
      re[i] = re[j]!;
      re[j] = tr;
      const ti = im[i]!;
      im[i] = im[j]!;
      im[j] = ti;
    }
  }
  for (let size = 2; size <= n; size <<= 1) {
    const half = size >> 1;
    const step = (2 * Math.PI) / size;
    for (let i = 0; i < n; i += size) {
      for (let k = 0; k < half; k++) {
        const c = Math.cos(step * k);
        const s = -Math.sin(step * k);
        const tr = c * re[i + k + half]! - s * im[i + k + half]!;
        const ti = s * re[i + k + half]! + c * im[i + k + half]!;
        re[i + k + half] = re[i + k]! - tr;
        im[i + k + half] = im[i + k]! - ti;
        re[i + k] += tr;
        im[i + k] += ti;
      }
    }
  }
}

function spectralFeatures(samples: Float32Array, sr: number, bands: number) {
  const fftSize = 2048;
  const hop = 2048;
  const half = fftSize / 2;
  const mag = new Float32Array(half);
  const re = new Float32Array(fftSize);
  const im = new Float32Array(fftSize);
  let frames = 0;
  const limit = Math.min(samples.length, sr * 6);
  for (let off = 0; off + fftSize < limit; off += hop) {
    re.fill(0);
    im.fill(0);
    for (let i = 0; i < fftSize; i++) {
      const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (fftSize - 1));
      re[i] = samples[off + i]! * w;
    }
    dftRadix2(re, im);
    for (let k = 0; k < half; k++) mag[k] += re[k]! * re[k]! + im[k]! * im[k]!;
    frames++;
  }
  if (frames) {
    for (let k = 0; k < half; k++) mag[k] = mag[k]! / frames;
  }

  const sumRange = (lo: number, hi: number) => {
    const i0 = Math.max(1, Math.floor((lo / sr) * fftSize));
    const i1 = Math.min(half - 1, Math.ceil((hi / sr) * fftSize));
    let e = 0;
    for (let k = i0; k <= i1; k++) e += mag[k]!;
    return e / Math.max(1, i1 - i0 + 1);
  };

  const spectrum: number[] = [];
  let max = 1e-9;
  for (let i = 0; i < bands; i++) {
    const t0 = i / bands;
    const t1 = (i + 1) / bands;
    const f0 = 40 * Math.pow((sr / 2 - 40) / 40, t0);
    const f1 = 40 * Math.pow((sr / 2 - 40) / 40, t1);
    const v = Math.sqrt(sumRange(f0, f1));
    spectrum.push(v);
    if (v > max) max = v;
  }
  return {
    bass: sumRange(30, 140),
    mid: sumRange(140, 2000),
    high: sumRange(2000, 10000),
    spectrum: spectrum.map((v) => Math.min(1, v / max)),
  };
}

function pickGenre(
  bass: number,
  mid: number,
  high: number,
  bpm: number,
): GenreId {
  const tot = bass + mid + high + 1e-6;
  const b = bass / tot;
  const m = mid / tot;
  const h = high / tot;
  if (bpm < 88 && h < 0.28 && b < 0.4) return "ambient";
  if (b > 0.42 && bpm <= 102) return "hiphop";
  if (b > 0.34 && bpm >= 118 && h > 0.22) return "electronic";
  if (m > 0.36 && b < 0.4 && bpm >= 90 && bpm <= 160) return "rock";
  if (h + m > 0.7 && b < 0.28) return "acoustic";
  return "pop";
}

export async function analyzeTrack(
  ctx: AudioContext,
  file: File,
): Promise<TrackReport> {
  const raw = await file.arrayBuffer();
  const buffer = await ctx.decodeAudioData(raw.slice(0));
  const samples = monoMix(buffer, 10);
  const sr = buffer.sampleRate;
  const bpm = estimateBpm(samples, sr);
  const feats = spectralFeatures(samples, sr, 24);
  const genre = pickGenre(feats.bass, feats.mid, feats.high, bpm);
  const curve = ANALOG_CURVES[genre];
  return {
    genre,
    genreLabel: curve.label,
    bpm,
    curve,
    sampleRate: sr,
    channels: buffer.numberOfChannels,
    duration: buffer.duration,
    bitLabel: "32-bit float path · source format preserved",
    spectrum: feats.spectrum,
  };
}
