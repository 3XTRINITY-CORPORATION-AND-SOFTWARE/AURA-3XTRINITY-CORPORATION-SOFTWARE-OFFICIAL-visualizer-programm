export type GenreId =
  | "electronic"
  | "hiphop"
  | "rock"
  | "acoustic"
  | "ambient"
  | "pop";

export type AnalogCurve = {
  id: GenreId;
  label: string;
  comment: string;
  /** Cuts first, then boosts — never the reverse. */
  cuts: { type: BiquadFilterType; freq: number; q: number; gain: number }[];
  boosts: { type: BiquadFilterType; freq: number; q: number; gain: number }[];
  drive: number;
  makeup: number;
};

const HPF = {
  type: "highpass" as const,
  freq: 28,
  q: 0.7,
  gain: 0,
};

export const ANALOG_CURVES: Record<GenreId, AnalogCurve> = {
  electronic: {
    id: "electronic",
    label: "Electronic",
    comment:
      "Cut 300 Hz and 4.2 kHz before a 80 Hz shelf. Fundamentals stay dry; even-harmonic mirror is light. Conservative master.",
    cuts: [
      HPF,
      { type: "peaking", freq: 300, q: 0.9, gain: -2.6 },
      { type: "peaking", freq: 4200, q: 1.1, gain: -1.3 },
    ],
    boosts: [
      { type: "lowshelf", freq: 80, q: 0.7, gain: 1.2 },
      { type: "highshelf", freq: 11000, q: 0.7, gain: 0.8 },
    ],
    drive: 0.22,
    makeup: 0.9,
  },
  hiphop: {
    id: "hiphop",
    label: "Hip-hop",
    comment:
      "Cut 350 Hz mud before a 60 Hz shelf. Kick fundamental untouched; analog mirror on the body only.",
    cuts: [
      HPF,
      { type: "peaking", freq: 350, q: 0.85, gain: -2.2 },
      { type: "peaking", freq: 3100, q: 1.0, gain: -1.5 },
    ],
    boosts: [
      { type: "lowshelf", freq: 62, q: 0.7, gain: 1.6 },
      { type: "highshelf", freq: 8500, q: 0.7, gain: 0.5 },
    ],
    drive: 0.18,
    makeup: 0.88,
  },
  rock: {
    id: "rock",
    label: "Rock",
    comment:
      "Cut 280 Hz and 4 kHz before a 2.2 kHz presence lift. Phase-coherent series path, no stereo tricks.",
    cuts: [
      HPF,
      { type: "peaking", freq: 280, q: 0.8, gain: -1.8 },
      { type: "peaking", freq: 4000, q: 1.2, gain: -1.1 },
    ],
    boosts: [
      { type: "lowshelf", freq: 120, q: 0.7, gain: 0.7 },
      { type: "peaking", freq: 2200, q: 0.9, gain: 1.3 },
    ],
    drive: 0.2,
    makeup: 0.91,
  },
  acoustic: {
    id: "acoustic",
    label: "Acoustic",
    comment:
      "Cut 400 Hz boxiness before 5 kHz air. Rounding is barely on — keeps the original transient.",
    cuts: [
      { type: "highpass", freq: 40, q: 0.7, gain: 0 },
      { type: "peaking", freq: 400, q: 0.8, gain: -1.4 },
      { type: "peaking", freq: 2500, q: 1.0, gain: -0.6 },
    ],
    boosts: [
      { type: "peaking", freq: 5200, q: 0.8, gain: 1.1 },
      { type: "highshelf", freq: 12000, q: 0.7, gain: 0.7 },
    ],
    drive: 0.12,
    makeup: 0.93,
  },
  ambient: {
    id: "ambient",
    label: "Ambient",
    comment:
      "Gentle 250 Hz cut, no hype boosts. Mirror is a soft even-order haze; master stays under unity.",
    cuts: [
      { type: "highpass", freq: 24, q: 0.7, gain: 0 },
      { type: "peaking", freq: 250, q: 0.7, gain: -1.1 },
      { type: "peaking", freq: 5000, q: 0.8, gain: -0.4 },
    ],
    boosts: [
      { type: "highshelf", freq: 10000, q: 0.7, gain: 0.5 },
      { type: "peaking", freq: 180, q: 0.6, gain: 0.3 },
    ],
    drive: 0.14,
    makeup: 0.94,
  },
  pop: {
    id: "pop",
    label: "Pop",
    comment:
      "Cut 320 Hz before a 1 dB 100 Hz shelf and 3 kHz presence. Hardware-agnostic conservative master.",
    cuts: [
      HPF,
      { type: "peaking", freq: 320, q: 0.9, gain: -2.0 },
      { type: "peaking", freq: 3500, q: 1.1, gain: -1.0 },
    ],
    boosts: [
      { type: "lowshelf", freq: 100, q: 0.7, gain: 1.0 },
      { type: "peaking", freq: 3000, q: 0.85, gain: 1.0 },
    ],
    drive: 0.16,
    makeup: 0.9,
  },
};

function makeMirrorCurve(drive: number): Float32Array {
  const n = 1024;
  const curve = new Float32Array(n);
  const k = 0.1 * drive;
  const sat = 1 + 0.28 * drive;
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * 2 - 1;
    const odd = Math.tanh(x * sat);
    const even = k * (x * x - 1 / 3);
    curve[i] = Math.max(-1, Math.min(1, (odd + even) * 0.97));
  }
  return curve;
}

/**
 * Always-connected analog path.
 * Dry = original fundamentals; wet = cut-before-boost + even-harmonic mirror.
 * No resample, no requantize — same bit format as the context (float32).
 */
export class AnalogPath {
  input: GainNode;
  output: GainNode;
  private dry: GainNode;
  private wet: GainNode;
  private makeup: GainNode;
  private shaper: WaveShaperNode;
  private cuts: BiquadFilterNode[];
  private boosts: BiquadFilterNode[];
  private ctx: AudioContext;
  enabled = true;

  constructor(ctx: AudioContext) {
    this.ctx = ctx;
    this.input = ctx.createGain();
    this.output = ctx.createGain();
    this.dry = ctx.createGain();
    this.wet = ctx.createGain();
    this.makeup = ctx.createGain();
    this.shaper = ctx.createWaveShaper();
    this.shaper.oversample = "2x";
    this.shaper.curve = makeMirrorCurve(0.16) as unknown as Float32Array<ArrayBuffer>;

    this.cuts = [0, 1, 2].map(() => ctx.createBiquadFilter());
    this.boosts = [0, 1].map(() => ctx.createBiquadFilter());

    this.input.connect(this.dry);
    this.dry.connect(this.output);

    let node: AudioNode = this.input;
    for (const f of this.cuts) {
      node.connect(f);
      node = f;
    }
    for (const f of this.boosts) {
      node.connect(f);
      node = f;
    }
    node.connect(this.shaper);
    this.shaper.connect(this.makeup);
    this.makeup.connect(this.wet);
    this.wet.connect(this.output);

    this.dry.gain.value = 0.62;
    this.wet.gain.value = 0.38;
    this.makeup.gain.value = 0.9;
    this.apply(ANALOG_CURVES.pop, true);
  }

  setEnabled(on: boolean) {
    this.enabled = on;
    const t = this.ctx.currentTime;
    if (on) {
      this.dry.gain.setTargetAtTime(0.62, t, 0.04);
      this.wet.gain.setTargetAtTime(0.38, t, 0.04);
    } else {
      this.dry.gain.setTargetAtTime(1, t, 0.04);
      this.wet.gain.setTargetAtTime(0.0001, t, 0.04);
    }
  }

  apply(curve: AnalogCurve, instant = false) {
    const t = this.ctx.currentTime;
    const tau = instant ? 0.001 : 0.06;
    curve.cuts.forEach((band, i) => {
      const f = this.cuts[i];
      if (!f) return;
      f.type = band.type;
      f.frequency.setTargetAtTime(band.freq, t, tau);
      f.Q.setTargetAtTime(band.q, t, tau);
      f.gain.setTargetAtTime(band.gain, t, tau);
    });
    curve.boosts.forEach((band, i) => {
      const f = this.boosts[i];
      if (!f) return;
      f.type = band.type;
      f.frequency.setTargetAtTime(band.freq, t, tau);
      f.Q.setTargetAtTime(band.q, t, tau);
      f.gain.setTargetAtTime(band.gain, t, tau);
    });
    this.shaper.curve = makeMirrorCurve(curve.drive) as unknown as Float32Array<ArrayBuffer>;
    this.makeup.gain.setTargetAtTime(curve.makeup, t, tau);
  }
}
