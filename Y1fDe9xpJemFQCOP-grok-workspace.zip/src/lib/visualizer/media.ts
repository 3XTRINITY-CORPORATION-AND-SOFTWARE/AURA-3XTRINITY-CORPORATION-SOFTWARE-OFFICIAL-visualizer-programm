import { create } from "zustand";
import { PLATES } from "./plates";

export type MediaKind = "audio" | "video" | "image" | "text";

export type MediaItem = {
  id: string;
  name: string;
  kind: MediaKind;
  mime: string;
  size: number;
  addedAt: number;
  builtin?: boolean;
  url?: string;
  text?: string;
};

export type AuraProject = {
  version: 1;
  kind: "aura-project";
  theme: string;
  mode: string;
  sensitivity: number;
  analogOn: boolean;
  volume: number;
  backdropName: string | null;
  lyricsName: string | null;
  media: { name: string; kind: MediaKind; mime: string }[];
};

const AUDIO_EXT = new Set([
  "mp3", "wav", "ogg", "flac", "m4a", "aac", "aiff", "aif", "opus", "weba", "caf", "fl",
]);
const VIDEO_EXT = new Set(["mp4", "webm", "mov", "m4v", "ogv", "flv", "mkv"]);
const IMAGE_EXT = new Set(["jpg", "jpeg", "png", "webp", "gif", "avif", "bmp", "svg"]);
const TEXT_EXT = new Set(["txt", "lrc", "md", "json", "csv", "srt"]);

const DB_NAME = "aura-media-v1";
const MAX_BYTES = 90 * 1024 * 1024;
const urlCache = new Map<string, string>();

const BUILTINS: MediaItem[] = PLATES.map((p) => ({
  id: `plate-${p.file}`,
  name: p.title,
  kind: "image" as const,
  mime: "image/jpeg",
  size: 0,
  addedAt: 0,
  builtin: true,
  url: `/notes/plates/${p.file}`,
}));

function extOf(name: string) {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}

export function classifyFile(file: File): MediaKind | "project" | null {
  const ext = extOf(file.name);
  const type = (file.type || "").toLowerCase();
  if (ext === "json" || file.name.toLowerCase().endsWith(".aura.json")) {
    return "project";
  }
  if (type.startsWith("audio/") || AUDIO_EXT.has(ext)) return "audio";
  if (type.startsWith("video/") || VIDEO_EXT.has(ext)) return "video";
  if (type.startsWith("image/") || IMAGE_EXT.has(ext)) return "image";
  if (type.startsWith("text/") || TEXT_EXT.has(ext)) return "text";
  return null;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta", { keyPath: "id" });
      if (!db.objectStoreNames.contains("blobs")) db.createObjectStore("blobs");
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx: IDBTransaction) {
  return new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

async function idbPut(item: MediaItem, blob: Blob) {
  const db = await openDb();
  const tx = db.transaction(["meta", "blobs"], "readwrite");
  tx.objectStore("meta").put(item);
  tx.objectStore("blobs").put(blob, item.id);
  await txDone(tx);
  db.close();
}

async function idbDelete(id: string) {
  const db = await openDb();
  const tx = db.transaction(["meta", "blobs"], "readwrite");
  tx.objectStore("meta").delete(id);
  tx.objectStore("blobs").delete(id);
  await txDone(tx);
  db.close();
}

async function idbList(): Promise<MediaItem[]> {
  const db = await openDb();
  const tx = db.transaction("meta", "readonly");
  const req = tx.objectStore("meta").getAll();
  const rows = await new Promise<MediaItem[]>((resolve, reject) => {
    req.onsuccess = () => resolve((req.result as MediaItem[]) ?? []);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return rows.sort((a, b) => b.addedAt - a.addedAt);
}

async function idbBlob(id: string): Promise<Blob | null> {
  const db = await openDb();
  const tx = db.transaction("blobs", "readonly");
  const req = tx.objectStore("blobs").get(id);
  const blob = await new Promise<Blob | null>((resolve, reject) => {
    req.onsuccess = () => resolve((req.result as Blob) ?? null);
    req.onerror = () => reject(req.error);
  });
  db.close();
  return blob;
}

function uid() {
  return `m-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

type LibraryState = {
  items: MediaItem[];
  ready: boolean;
  backdropId: string | null;
  lyricsId: string | null;
  hydrate: () => Promise<void>;
  importFiles: (files: File[]) => Promise<{ items: MediaItem[]; project: AuraProject | null; skipped: string[] }>;
  remove: (id: string) => Promise<void>;
  setBackdrop: (id: string | null) => void;
  setLyrics: (id: string | null) => void;
  objectUrl: (item: MediaItem) => Promise<string | null>;
  readText: (item: MediaItem) => Promise<string>;
  blobFor: (item: MediaItem) => Promise<Blob | null>;
};

export const useLibrary = create<LibraryState>((set, get) => ({
  items: BUILTINS,
  ready: false,
  backdropId: BUILTINS[0]?.id ?? null,
  lyricsId: null,

  hydrate: async () => {
    if (typeof indexedDB === "undefined") {
      set({ ready: true });
      return;
    }
    try {
      const stored = await idbList();
      set({ items: [...stored, ...BUILTINS], ready: true });
    } catch {
      set({ ready: true });
    }
  },

  importFiles: async (files) => {
    const added: MediaItem[] = [];
    const skipped: string[] = [];
    let project: AuraProject | null = null;

    for (const file of files) {
      const kind = classifyFile(file);
      if (!kind) {
        skipped.push(file.name);
        continue;
      }
      if (kind === "project") {
        try {
          const parsed = JSON.parse(await file.text()) as AuraProject;
          if (parsed?.kind === "aura-project") {
            project = parsed;
            continue;
          }
        } catch {
          /* fall through as text */
        }
        const item: MediaItem = {
          id: uid(),
          name: file.name,
          kind: "text",
          mime: file.type || "application/json",
          size: file.size,
          addedAt: Date.now(),
          text: await file.text().catch(() => ""),
        };
        try {
          await idbPut(item, file);
          added.push(item);
        } catch {
          skipped.push(file.name);
        }
        continue;
      }
      if (file.size > MAX_BYTES) {
        skipped.push(file.name);
        continue;
      }
      const item: MediaItem = {
        id: uid(),
        name: file.name,
        kind,
        mime: file.type || "application/octet-stream",
        size: file.size,
        addedAt: Date.now(),
      };
      if (kind === "text") {
        item.text = await file.text();
      }
      try {
        await idbPut(item, file);
        added.push(item);
        const url = URL.createObjectURL(file);
        urlCache.set(item.id, url);
      } catch {
        skipped.push(file.name);
      }
    }

    if (added.length) {
      set({ items: [...added, ...get().items] });
    }
    return { items: added, project, skipped };
  },

  remove: async (id) => {
    const item = get().items.find((x) => x.id === id);
    if (!item || item.builtin) return;
    await idbDelete(id);
    const cached = urlCache.get(id);
    if (cached) {
      URL.revokeObjectURL(cached);
      urlCache.delete(id);
    }
    set((s) => ({
      items: s.items.filter((x) => x.id !== id),
      backdropId: s.backdropId === id ? null : s.backdropId,
      lyricsId: s.lyricsId === id ? null : s.lyricsId,
    }));
  },

  setBackdrop: (id) => set({ backdropId: id }),
  setLyrics: (id) => set({ lyricsId: id }),

  objectUrl: async (item) => {
    if (item.url) return item.url;
    const cached = urlCache.get(item.id);
    if (cached) return cached;
    const blob = await idbBlob(item.id);
    if (!blob) return null;
    const url = URL.createObjectURL(blob);
    urlCache.set(item.id, url);
    return url;
  },

  readText: async (item) => {
    if (item.text != null) return item.text;
    const blob = await idbBlob(item.id);
    return blob ? blob.text() : "";
  },

  blobFor: async (item) => {
    if (item.builtin && item.url) {
      const res = await fetch(item.url);
      return res.blob();
    }
    return idbBlob(item.id);
  },
}));

export function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export function formatBytes(n: number) {
  if (n <= 0) return "built-in";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}
