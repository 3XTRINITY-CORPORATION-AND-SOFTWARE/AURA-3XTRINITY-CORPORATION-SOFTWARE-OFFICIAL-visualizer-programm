import { create } from "zustand";
import { loadLicense, type CoreLicense } from "./core";
import type { GeoMask, SourceKind, ThemeId, VizMode } from "./types";

const PREFS_KEY = "aura-prefs-v1";

type Prefs = {
  mode: VizMode;
  theme: ThemeId;
  sensitivity: number;
  volume: number;
  analogOn: boolean;
};

function loadPrefs(): Partial<Prefs> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(PREFS_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Partial<Prefs>;
  } catch {
    return {};
  }
}

function savePrefs(prefs: Prefs) {
  try {
    window.localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  } catch {
    /* ignore quota */
  }
}

export type VizStore = {
  source: SourceKind;
  mode: VizMode;
  theme: ThemeId;
  sensitivity: number;
  volume: number;
  playing: boolean;
  fileName: string | null;
  duration: number;
  currentTime: number;
  error: string | null;
  fullscreen: boolean;
  controlsOpen: boolean;
  hydrated: boolean;
  dragging: boolean;
  analogOn: boolean;
  notesOpen: boolean;
  libraryOpen: boolean;
  storeOpen: boolean;
  civilOpen: boolean;
  geo: GeoMask | null;
  booting: boolean;
  license: CoreLicense;
  overlayText: string;
  analyzing: boolean;
  genre: string | null;
  bpm: number | null;
  curveComment: string;
  sampleRate: number | null;
  channels: number | null;
  bitLabel: string;
  spectrum: number[];
  setSource: (source: SourceKind) => void;
  setMode: (mode: VizMode) => void;
  setTheme: (theme: ThemeId) => void;
  setSensitivity: (sensitivity: number) => void;
  setVolume: (volume: number) => void;
  setPlaying: (playing: boolean) => void;
  setFileMeta: (fileName: string | null, duration: number) => void;
  setCurrentTime: (currentTime: number) => void;
  setError: (error: string | null) => void;
  setFullscreen: (fullscreen: boolean) => void;
  setControlsOpen: (controlsOpen: boolean) => void;
  setDragging: (dragging: boolean) => void;
  setAnalogOn: (analogOn: boolean) => void;
  setNotesOpen: (notesOpen: boolean) => void;
  setLibraryOpen: (libraryOpen: boolean) => void;
  setStoreOpen: (storeOpen: boolean) => void;
  setCivilOpen: (civilOpen: boolean) => void;
  setGeo: (geo: GeoMask | null) => void;
  setBooting: (booting: boolean) => void;
  setLicense: (license: CoreLicense) => void;
  setOverlayText: (overlayText: string) => void;
  setAnalyzing: (analyzing: boolean) => void;
  setTrackReport: (report: {
    genre: string;
    bpm: number;
    curveComment: string;
    sampleRate: number;
    channels: number;
    bitLabel: string;
    spectrum: number[];
  }) => void;
  clearTrackReport: () => void;
  hydrate: () => void;
};

const persist = (state: VizStore) => {
  savePrefs({
    mode: state.mode,
    theme: state.theme,
    sensitivity: state.sensitivity,
    volume: state.volume,
    analogOn: state.analogOn,
  });
};

export const useViz = create<VizStore>((set, get) => ({
  source: "none",
  mode: "ring",
  theme: "ice",
  sensitivity: 1.15,
  volume: 0.72,
  playing: false,
  fileName: null,
  duration: 0,
  currentTime: 0,
  error: null,
  fullscreen: false,
  controlsOpen: true,
  hydrated: false,
  dragging: false,
  analogOn: true,
  notesOpen: false,
  libraryOpen: false,
  storeOpen: false,
  civilOpen: false,
  geo: null,
  booting: true,
  license: { plan: "demo", key: "", at: 0 },
  overlayText: "",
  analyzing: false,
  genre: null,
  bpm: null,
  curveComment: "",
  sampleRate: null,
  channels: null,
  bitLabel: "",
  spectrum: [],
  setSource: (source) => set({ source, error: null }),
  setMode: (mode) => {
    set({ mode });
    persist(get());
  },
  setTheme: (theme) => {
    set({ theme });
    persist(get());
  },
  setSensitivity: (sensitivity) => {
    set({ sensitivity });
    persist(get());
  },
  setVolume: (volume) => {
    set({ volume });
    persist(get());
  },
  setPlaying: (playing) => set({ playing }),
  setFileMeta: (fileName, duration) => set({ fileName, duration }),
  setCurrentTime: (currentTime) => set({ currentTime }),
  setError: (error) => set({ error }),
  setFullscreen: (fullscreen) => set({ fullscreen }),
  setControlsOpen: (controlsOpen) => set({ controlsOpen }),
  setDragging: (dragging) => set({ dragging }),
  setAnalogOn: (analogOn) => {
    set({ analogOn });
    persist(get());
  },
  setNotesOpen: (notesOpen) => set({ notesOpen }),
  setLibraryOpen: (libraryOpen) => set({ libraryOpen }),
  setStoreOpen: (storeOpen) => set({ storeOpen }),
  setCivilOpen: (civilOpen) => set({ civilOpen }),
  setGeo: (geo) => set({ geo }),
  setBooting: (booting) => set({ booting }),
  setLicense: (license) => set({ license }),
  setOverlayText: (overlayText) => set({ overlayText }),
  setAnalyzing: (analyzing) => set({ analyzing }),
  setTrackReport: (report) =>
    set({
      genre: report.genre,
      bpm: report.bpm,
      curveComment: report.curveComment,
      sampleRate: report.sampleRate,
      channels: report.channels,
      bitLabel: report.bitLabel,
      spectrum: report.spectrum,
      analyzing: false,
    }),
  clearTrackReport: () =>
    set({
      genre: null,
      bpm: null,
      curveComment: "",
      sampleRate: null,
      channels: null,
      bitLabel: "",
      spectrum: [],
      analyzing: false,
    }),
  hydrate: () => {
    if (get().hydrated) return;
    const prefs = loadPrefs();
    set({
      mode: prefs.mode ?? "ring",
      theme: prefs.theme ?? "ice",
      sensitivity: prefs.sensitivity ?? 1.15,
      volume: prefs.volume ?? 0.72,
      analogOn: prefs.analogOn ?? true,
      license: loadLicense(),
      booting: typeof window === "undefined" ? false : !sessionStorage.getItem("aura-booted"),
      hydrated: true,
    });
    if (typeof window !== "undefined") sessionStorage.setItem("aura-booted", "1");
  },
}));
