import { AnalogPath, ANALOG_CURVES, type AnalogCurve } from "./analog-eq";

export type Analysis = {
  freq: Uint8Array;
  wave: Uint8Array;
  bass: number;
  mids: number;
  highs: number;
  rms: number;
};

type DemoHandle = {
  oscs: OscillatorNode[];
  stopTimer: () => void;
};

function makeNoiseBuffer(ctx: AudioContext): AudioBuffer {
  const length = ctx.sampleRate * 2;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < length; i++) {
    const white = Math.random() * 2 - 1;
    last = (last + 0.02 * white) / 1.02;
    data[i] = last * 3.5;
  }
  return buffer;
}

export class AudioEngine {
  ctx: AudioContext | null = null;
  analyser: AnalyserNode | null = null;
  master: GainNode | null = null;
  bus: GainNode | null = null;
  analog: AnalogPath | null = null;
  freq = new Uint8Array(1024);
  wave = new Uint8Array(2048);

  private micStream: MediaStream | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  audioEl: HTMLAudioElement | null = null;
  videoEl: HTMLVideoElement | null = null;
  private mediaSource: MediaElementAudioSourceNode | null = null;
  private videoSource: MediaElementAudioSourceNode | null = null;
  private fileUrl: string | null = null;
  private demo: DemoHandle | null = null;
  private extraNodes: AudioNode[] = [];
  private mediaKind: "audio" | "video" | null = null;

  async unlock(): Promise<AudioContext> {
    if (!this.ctx) {
      const Ctor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      try {
        this.ctx = new Ctor({ latencyHint: "playback", sampleRate: 44100 });
      } catch {
        this.ctx = new Ctor({ latencyHint: "playback" });
      }
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.0001;
      this.bus = this.ctx.createGain();
      this.analog = new AnalogPath(this.ctx);
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 2048;
      this.analyser.smoothingTimeConstant = 0.78;
      this.analyser.minDecibels = -88;
      this.analyser.maxDecibels = -18;
      this.bus.connect(this.analog.input);
      this.analog.output.connect(this.analyser);
      this.analyser.connect(this.master);
      this.master.connect(this.ctx.destination);
      this.freq = new Uint8Array(this.analyser.frequencyBinCount);
      this.wave = new Uint8Array(this.analyser.fftSize);
    }
    if (this.ctx.state === "suspended") {
      await this.ctx.resume();
    }
    return this.ctx;
  }

  get sampleRate(): number {
    return this.ctx?.sampleRate ?? 44100;
  }

  setAnalog(on: boolean) {
    this.analog?.setEnabled(on);
  }

  applyCurve(curve: AnalogCurve) {
    this.analog?.apply(curve);
  }

  setVolume(linear: number) {
    if (!this.ctx || !this.master) return;
    const v = Math.max(0, Math.min(1, linear));
    const gain = v * v;
    this.master.gain.setTargetAtTime(
      Math.max(gain, 0.0001),
      this.ctx.currentTime,
      0.04,
    );
  }

  private tap(): AudioNode {
    return this.bus!;
  }

  private disconnectSources() {
    this.micSource?.disconnect();
    this.micSource = null;
    if (this.micStream) {
      for (const track of this.micStream.getTracks()) track.stop();
      this.micStream = null;
    }
    this.mediaSource?.disconnect();
    this.videoSource?.disconnect();
    if (this.audioEl) this.audioEl.pause();
    if (this.videoEl) this.videoEl.pause();
    this.stopDemo();
  }

  get visualVideo(): HTMLVideoElement | null {
    return this.mediaKind === "video" ? this.videoEl : null;
  }

  get mediaEl(): HTMLMediaElement | null {
    if (this.mediaKind === "video") return this.videoEl;
    return this.audioEl;
  }

  halt() {
    this.disconnectSources();
  }

  private stopDemo() {
    if (!this.demo) return;
    for (const osc of this.demo.oscs) {
      try {
        osc.stop();
      } catch {
        /* already stopped */
      }
      try {
        osc.disconnect();
      } catch {
        /* ignore */
      }
    }
    this.demo.stopTimer();
    this.demo = null;
    for (const node of this.extraNodes) {
      try {
        node.disconnect();
      } catch {
        /* ignore */
      }
    }
    this.extraNodes = [];
  }

  async startMic(): Promise<void> {
    await this.unlock();
    if (!this.ctx || !this.bus) return;
    this.disconnectSources();
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false,
      },
    });
    this.micStream = stream;
    this.micSource = this.ctx.createMediaStreamSource(stream);
    this.micSource.connect(this.tap());
    this.setVolume(0);
  }

  async startFile(file: File): Promise<HTMLMediaElement> {
    await this.unlock();
    if (!this.ctx || !this.bus) {
      throw new Error("Audio is unavailable.");
    }
    this.disconnectSources();
    const isVideo =
      file.type.startsWith("video/") ||
      /\.(mp4|webm|mov|m4v|ogv|flv|mkv)$/i.test(file.name);

    if (this.fileUrl) URL.revokeObjectURL(this.fileUrl);
    this.fileUrl = URL.createObjectURL(file);

    if (isVideo) {
      if (!this.videoEl) {
        const el = document.createElement("video");
        el.crossOrigin = "anonymous";
        el.preload = "auto";
        el.playsInline = true;
        el.setAttribute("playsinline", "true");
        el.setAttribute("webkit-playsinline", "true");
        this.videoEl = el;
        this.videoSource = this.ctx.createMediaElementSource(el);
      }
      this.videoEl.src = this.fileUrl;
      this.videoEl.loop = false;
      this.mediaKind = "video";
      this.videoSource!.connect(this.tap());
      await this.videoEl.play();
      return this.videoEl;
    }

    if (!this.audioEl) {
      const el = document.createElement("audio");
      el.crossOrigin = "anonymous";
      el.preload = "auto";
      el.setAttribute("playsinline", "true");
      el.setAttribute("webkit-playsinline", "true");
      this.audioEl = el;
      this.mediaSource = this.ctx.createMediaElementSource(el);
    }
    this.audioEl.src = this.fileUrl;
    this.mediaKind = "audio";
    this.mediaSource!.connect(this.tap());
    await this.audioEl.play();
    return this.audioEl;
  }

  async startDemo(): Promise<void> {
    const ctx = await this.unlock();
    if (!this.bus) return;
    this.disconnectSources();

    const pad = ctx.createGain();
    pad.gain.value = 0.22;
    pad.connect(this.tap());
    this.extraNodes.push(pad);

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 1400;
    filter.Q.value = 6;
    filter.connect(pad);
    this.extraNodes.push(filter);

    const flfo = ctx.createOscillator();
    flfo.type = "sine";
    flfo.frequency.value = 0.11;
    const flfoGain = ctx.createGain();
    flfoGain.gain.value = 1100;
    flfo.connect(flfoGain);
    flfoGain.connect(filter.frequency);
    flfo.start();
    this.extraNodes.push(flfoGain);

    const notes = [130.81, 164.81, 196.0, 246.94, 329.63, 392.0];
    const oscs: OscillatorNode[] = [flfo];

    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = i % 2 === 0 ? "sine" : "triangle";
      osc.frequency.value = freq;
      const g = ctx.createGain();
      g.gain.value = 0.11 - i * 0.012;
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.05 + i * 0.027;
      const lfoG = ctx.createGain();
      lfoG.gain.value = 0.035;
      lfo.connect(lfoG);
      lfoG.connect(g.gain);
      osc.connect(g);
      g.connect(filter);
      osc.start();
      lfo.start();
      oscs.push(osc, lfo);
      this.extraNodes.push(g, lfoG);
    });

    const noise = ctx.createBufferSource();
    noise.buffer = makeNoiseBuffer(ctx);
    noise.loop = true;
    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = "bandpass";
    noiseFilter.frequency.value = 2400;
    noiseFilter.Q.value = 1.4;
    const noiseGain = ctx.createGain();
    noiseGain.gain.value = 0.07;
    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.tap());
    noise.start();
    this.extraNodes.push(noise, noiseFilter, noiseGain);

    const nlfo = ctx.createOscillator();
    nlfo.frequency.value = 0.19;
    const nlfoG = ctx.createGain();
    nlfoG.gain.value = 900;
    nlfo.connect(nlfoG);
    nlfoG.connect(noiseFilter.frequency);
    nlfo.start();
    oscs.push(nlfo);
    this.extraNodes.push(nlfoG);

    let stopped = false;
    let timer = 0;
    const kick = () => {
      if (stopped || !this.ctx) return;
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(68, now);
      osc.frequency.exponentialRampToValueAtTime(36, now + 0.22);
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(0.7, now + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.32);
      osc.connect(g);
      g.connect(this.tap());
      osc.start(now);
      osc.stop(now + 0.34);
      oscs.push(osc);
      this.extraNodes.push(g);
      timer = window.setTimeout(kick, 640);
    };
    kick();

    this.demo = {
      oscs,
      stopTimer: () => {
        stopped = true;
        window.clearTimeout(timer);
      },
    };

    this.analog?.apply(ANALOG_CURVES.ambient);
  }

  pauseFile() {
    this.mediaEl?.pause();
  }

  async resumeFile() {
    await this.mediaEl?.play();
  }

  seek(time: number) {
    const el = this.mediaEl;
    if (el) el.currentTime = time;
  }

  sample(): Analysis {
    const empty: Analysis = {
      freq: this.freq,
      wave: this.wave,
      bass: 0,
      mids: 0,
      highs: 0,
      rms: 0,
    };
    if (!this.analyser) return empty;
    this.analyser.getByteFrequencyData(this.freq);
    this.analyser.getByteTimeDomainData(this.wave);

    const n = this.freq.length;
    let bass = 0;
    let mids = 0;
    let highs = 0;
    const bEnd = Math.max(1, Math.floor(n * 0.08));
    const mEnd = Math.max(bEnd + 1, Math.floor(n * 0.4));
    for (let i = 0; i < n; i++) {
      const v = this.freq[i]! / 255;
      if (i < bEnd) bass += v;
      else if (i < mEnd) mids += v;
      else highs += v;
    }
    bass /= bEnd;
    mids /= mEnd - bEnd;
    highs /= n - mEnd;

    let rms = 0;
    for (let i = 0; i < this.wave.length; i++) {
      const s = (this.wave[i]! - 128) / 128;
      rms += s * s;
    }
    rms = Math.sqrt(rms / this.wave.length);

    return { freq: this.freq, wave: this.wave, bass, mids, highs, rms };
  }

  dispose() {
    this.disconnectSources();
    if (this.fileUrl) URL.revokeObjectURL(this.fileUrl);
    this.fileUrl = null;
    void this.ctx?.close();
    this.ctx = null;
    this.analyser = null;
    this.master = null;
    this.bus = null;
    this.analog = null;
    this.audioEl = null;
    this.videoEl = null;
    this.mediaSource = null;
    this.videoSource = null;
    this.mediaKind = null;
  }
}
