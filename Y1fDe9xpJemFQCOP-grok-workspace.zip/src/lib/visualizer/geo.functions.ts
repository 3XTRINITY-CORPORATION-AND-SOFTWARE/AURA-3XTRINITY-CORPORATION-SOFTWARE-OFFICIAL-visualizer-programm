import { createServerFn } from "@tanstack/react-start";
import type { GeoMask } from "./types";

export type { GeoMask };

const FIELDS =
  "status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query,proxy,hosting,mobile";

function asQuery(raw: string) {
  const value = raw.trim();
  if (!value) return "";
  if (value.length > 253) return "";
  if (value.includes("://") || value.includes("/")) return "";
  if (
    /^[0-9a-fA-F:.]+$/.test(value) &&
    (value.includes(".") || value.includes(":"))
  ) {
    return value;
  }
  if (/^[a-zA-Z0-9][a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value)) {
    return value;
  }
  return "";
}

function isPublicIp(value: string) {
  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(value);
  if (v4) {
    const oct = v4.slice(1).map(Number);
    if (oct.some((n) => n > 255)) return false;
    const a = oct[0]!;
    const b = oct[1]!;
    if (a === 0 || a === 10 || a === 127) return false;
    if (a === 169 && b === 254) return false;
    if (a === 192 && b === 168) return false;
    if (a === 172 && b >= 16 && b <= 31) return false;
    return true;
  }
  if (value.includes(":")) {
    const lower = value.toLowerCase();
    if (lower === "::1" || lower.startsWith("::ffff:127.")) return false;
    if (lower.startsWith("fc") || lower.startsWith("fd")) return false;
    if (lower.startsWith("fe80:")) return false;
    return true;
  }
  return false;
}

function toMask(
  data: Record<string, unknown>,
  remaining: string | null,
  ttl: string | null,
): GeoMask {
  return {
    status: "success",
    country: String(data.country ?? ""),
    countryCode: String(data.countryCode ?? ""),
    region: String(data.region ?? ""),
    regionName: String(data.regionName ?? ""),
    city: String(data.city ?? ""),
    zip: String(data.zip ?? ""),
    lat: typeof data.lat === "number" ? data.lat : null,
    lon: typeof data.lon === "number" ? data.lon : null,
    timezone: String(data.timezone ?? ""),
    isp: String(data.isp ?? ""),
    org: String(data.org ?? ""),
    as: String(data.as ?? ""),
    query: String(data.query ?? ""),
    proxy: Boolean(data.proxy),
    hosting: Boolean(data.hosting),
    mobile: Boolean(data.mobile),
    source: "ip-api",
    remaining,
    ttl,
  };
}

async function lookup(
  query: string,
): Promise<{ ok: true; geo: GeoMask } | { ok: false; error: string }> {
  const path = query ? encodeURIComponent(query) : "";
  const res = await fetch(
    `http://ip-api.com/json/${path}?fields=${FIELDS}&lang=en`,
    {
      headers: { "User-Agent": "aura-core-civil-door/1.0" },
      signal: AbortSignal.timeout(8000),
    },
  );
  const remaining = res.headers.get("X-Rl");
  const ttl = res.headers.get("X-Ttl");
  if (res.status === 429 || remaining === "0") {
    return { ok: false, error: `rate limit · wait ${ttl ?? "60"}s` };
  }
  if (!res.ok) return { ok: false, error: `upstream ${res.status}` };
  const data = (await res.json()) as Record<string, unknown>;
  if (data.status !== "success") {
    return { ok: false, error: String(data.message ?? "fail") };
  }
  return { ok: true, geo: toMask(data, remaining, ttl) };
}

export const probeCivil = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object") return { query: "" };
    const q = (input as { query?: unknown }).query;
    return { query: typeof q === "string" ? q : "" };
  })
  .handler(
    async ({
      data,
    }): Promise<{ ok: true; geo: GeoMask } | { ok: false; error: string }> => {
      try {
        const raw = data.query.trim();
        let query = "";
        if (raw) {
          query = asQuery(raw);
          if (!query) return { ok: false, error: "invalid query" };
        } else {
          try {
            const { getRequestIP } = await import(
              "@tanstack/react-start/server"
            );
            const seen = asQuery(getRequestIP({ xForwardedFor: true }) ?? "");
            query = seen && isPublicIp(seen) ? seen : "";
          } catch {
            query = "";
          }
        }
        return await lookup(query);
      } catch (err) {
        return {
          ok: false,
          error: err instanceof Error ? err.message : "upstream failed",
        };
      }
    },
  );
