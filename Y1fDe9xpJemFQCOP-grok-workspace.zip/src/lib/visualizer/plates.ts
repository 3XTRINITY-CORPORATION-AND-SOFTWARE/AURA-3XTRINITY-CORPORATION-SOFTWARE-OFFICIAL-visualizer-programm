export const PLATES = [
  {
    file: "158.jpg",
    title: "Blue hour",
    note: "Crescent over the field. Analog path keeps the fundamental; the haze is the mirror.",
  },
  {
    file: "114.jpg",
    title: "Canopy",
    note: "Sun through leaves — cut mud before any lift.",
  },
  {
    file: "110.jpg",
    title: "Waterline",
    note: "Moon over still water. Phase-coherent series path.",
  },
  {
    file: "89.jpg",
    title: "Pink hour",
    note: "Same sky, quieter take. Conservative master.",
  },
  {
    file: "90.jpg",
    title: "Bloom",
    note: "Flower and moon. Light even-harmonic rounding.",
  },
  {
    file: "159.jpg",
    title: "Road",
    note: "Sunrise on dirt. The curve scales with the speakers.",
  },
  {
    file: "120.jpg",
    title: "Mark",
    note: "Identity plate. Same bit format through the chain.",
  },
] as const;

export const NOTE_FILES = [
  { href: "/notes/AURA-Import-Export.docx", label: "Spec" },
  { href: "/notes/AURA-Analog-44.1.pdf", label: "PDF" },
  { href: "/notes/AURA-Analog-44.1.pptx", label: "Slides" },
  { href: "/notes/AURA-Analog-44.1.xlsx", label: "Curves" },
] as const;
