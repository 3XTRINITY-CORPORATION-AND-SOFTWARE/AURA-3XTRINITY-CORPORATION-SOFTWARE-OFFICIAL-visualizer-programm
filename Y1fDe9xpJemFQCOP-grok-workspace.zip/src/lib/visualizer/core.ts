export const CORE_VERSION = "0.9";
export const CORE_PRICE = "€49";
export const CHECKOUT_URL =
  "https://buy.stripe.com/test_8x29ASemJ3pXb7w9S2gjC00";
export const GITHUB_REPO = "https://github.com/antonioportfelli-boop/aura-core";
export const LICENSE_KEY = "aura-core-license-v1";

export type CorePlan = "demo" | "launch" | "studio";

export type CoreLicense = {
  plan: CorePlan;
  key: string;
  at: number;
};

const KEYS: Record<string, CorePlan> = {
  "CORE-1900": "launch",
  "CORE-STUDIO": "studio",
  "CORE-LIVE": "studio",
};

export function loadLicense(): CoreLicense {
  if (typeof window === "undefined") {
    return { plan: "demo", key: "", at: 0 };
  }
  try {
    const raw = window.localStorage.getItem(LICENSE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as CoreLicense;
      if (parsed?.plan && parsed.plan !== "demo") return parsed;
    }
  } catch {
    /* ignore */
  }
  return { plan: "demo", key: "", at: 0 };
}

export function saveLicense(license: CoreLicense) {
  try {
    window.localStorage.setItem(LICENSE_KEY, JSON.stringify(license));
  } catch {
    /* ignore */
  }
}

export function redeemKey(raw: string): CoreLicense | null {
  const key = raw.trim().toUpperCase().replace(/\s+/g, "");
  const plan = KEYS[key];
  if (!plan) return null;
  const license: CoreLicense = { plan, key, at: Date.now() };
  saveLicense(license);
  return license;
}

export function isLicensed(plan: CorePlan) {
  return plan === "launch" || plan === "studio";
}

export function isStandalone() {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    (navigator as Navigator & { standalone?: boolean }).standalone === true
  );
}

export const BOOT_LINES = [
  "AURA CORE 0.9",
  "kernel ………… analog bus",
  "clock ………… 44.1 kHz request",
  "path ………… dry 0.62 / wet 0.38",
  "media ………… indexed store",
  "install ………… ready",
];
