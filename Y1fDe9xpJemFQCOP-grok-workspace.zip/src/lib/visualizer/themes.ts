import type { ThemeId } from "./types";

export type Rgb = readonly [number, number, number];

export type VizTheme = {
  id: ThemeId;
  label: string;
  a: Rgb;
  b: Rgb;
  c: Rgb;
  bg: Rgb;
};

export const THEMES: Record<ThemeId, VizTheme> = {
  ice: {
    id: "ice",
    label: "Ice",
    a: [56, 189, 248],
    b: [125, 211, 252],
    c: [224, 242, 254],
    bg: [5, 8, 12],
  },
  ember: {
    id: "ember",
    label: "Ember",
    a: [251, 113, 133],
    b: [251, 146, 60],
    c: [254, 215, 170],
    bg: [10, 6, 5],
  },
  tide: {
    id: "tide",
    label: "Tide",
    a: [34, 211, 238],
    b: [56, 189, 248],
    c: [147, 197, 253],
    bg: [4, 8, 12],
  },
  rose: {
    id: "rose",
    label: "Rose",
    a: [251, 113, 133],
    b: [253, 164, 175],
    c: [255, 228, 230],
    bg: [12, 5, 7],
  },
  mono: {
    id: "mono",
    label: "Mono",
    a: [228, 228, 231],
    b: [212, 212, 216],
    c: [250, 250, 250],
    bg: [7, 7, 8],
  },
};

export function rgb(c: Rgb, alpha = 1): string {
  if (alpha >= 1) return `rgb(${c[0]},${c[1]},${c[2]})`;
  return `rgba(${c[0]},${c[1]},${c[2]},${alpha})`;
}

export function mix(a: Rgb, b: Rgb, t: number): Rgb {
  const u = Math.max(0, Math.min(1, t));
  return [
    a[0] + (b[0] - a[0]) * u,
    a[1] + (b[1] - a[1]) * u,
    a[2] + (b[2] - a[2]) * u,
  ];
}
