import { mix, rgb, THEMES } from "./themes";
import type { ThemeId, VizMode } from "./types";
import type { Analysis } from "./audio";

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  band: number;
};

const BIN_COUNT = 72;

export class VisualizerRenderer {
  private ctx: CanvasRenderingContext2D;
  private smoothed = new Float32Array(BIN_COUNT);
  private peaks = new Float32Array(BIN_COUNT);
  private scratch = new Float32Array(BIN_COUNT);
  private particles: Particle[] = [];
  private rotation = 0;
  private lastMode: VizMode | null = null;
  private bass = 0;
  private bloom = 0;

  constructor(private canvas: HTMLCanvasElement) {
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("Canvas is unavailable.");
    this.ctx = ctx;
  }

  resize() {
    const parent = this.canvas.parentElement;
    if (!parent) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = parent.clientWidth;
    const h = parent.clientHeight;
    const pw = Math.max(1, Math.floor(w * dpr));
    const ph = Math.max(1, Math.floor(h * dpr));
    if (this.canvas.width !== pw || this.canvas.height !== ph) {
      this.canvas.width = pw;
      this.canvas.height = ph;
      this.canvas.style.width = `${w}px`;
      this.canvas.style.height = `${h}px`;
    }
  }

  frame(
    dt: number,
    analysis: Analysis | null,
    live: boolean,
    mode: VizMode,
    themeId: ThemeId,
    sensitivity: number,
    time: number,
    media: CanvasImageSource | null = null,
  ) {
    this.resize();
    const { ctx, canvas } = this;
    const w = canvas.width;
    const h = canvas.height;
    const theme = THEMES[themeId];

    if (this.lastMode !== mode) {
      this.particles.length = 0;
      this.lastMode = mode;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalAlpha = 1;
      ctx.fillStyle = rgb(theme.bg);
      ctx.fillRect(0, 0, w, h);
    }

    if (live && analysis) {
      toLogBins(analysis.freq, this.scratch);
      const gain = Math.max(0.4, sensitivity);
      for (let i = 0; i < BIN_COUNT; i++) {
        this.scratch[i] = Math.min(1, this.scratch[i]! * gain);
      }
    } else {
      fillIdle(this.scratch, time);
      const idleGain = 0.62 + Math.min(0.4, Math.max(0, sensitivity - 0.4) * 0.18);
      for (let i = 0; i < BIN_COUNT; i++) {
        this.scratch[i] = this.scratch[i]! * idleGain;
      }
    }

    const follow = 1 - Math.exp(-dt * (live ? 11 : 4.5));
    let energy = 0;
    let bass = 0;
    for (let i = 0; i < BIN_COUNT; i++) {
      const next = this.smoothed[i]! + (this.scratch[i]! - this.smoothed[i]!) * follow;
      this.smoothed[i] = next;
      energy += next;
      if (i < 10) bass += next;
      const fall = dt * 0.42;
      this.peaks[i] = Math.max(this.peaks[i]! - fall, next);
    }
    energy /= BIN_COUNT;
    bass /= 10;
    this.bass += (bass - this.bass) * (1 - Math.exp(-dt * 8));
    this.bloom += (energy - this.bloom) * (1 - Math.exp(-dt * 5));
    this.rotation += dt * (0.08 + this.bass * 0.35);

    this.drawMedia(w, h, media, theme);

    if (mode === "bloom") {
      this.drawBloom(dt, w, h, theme, analysis, live, time);
    } else {
      this.fillBackdrop(w, h, theme, mode, Boolean(media));
      if (mode === "bars") this.drawBars(w, h, theme);
      else if (mode === "ring") this.drawRing(w, h, theme);
      else this.drawWave(w, h, theme, analysis, time);
    }
  }

  private drawMedia(
    w: number,
    h: number,
    media: CanvasImageSource | null,
    theme: (typeof THEMES)[ThemeId],
  ) {
    const ctx = this.ctx;
    if (!media) {
      ctx.fillStyle = rgb(theme.bg);
      ctx.fillRect(0, 0, w, h);
      return;
    }
    const mw =
      media instanceof HTMLVideoElement
        ? media.videoWidth
        : media instanceof HTMLImageElement
          ? media.naturalWidth
          : 0;
    const mh =
      media instanceof HTMLVideoElement
        ? media.videoHeight
        : media instanceof HTMLImageElement
          ? media.naturalHeight
          : 0;
    if (mw < 2 || mh < 2) {
      ctx.fillStyle = rgb(theme.bg);
      ctx.fillRect(0, 0, w, h);
      return;
    }
    const ir = mw / mh;
    const wr = w / h;
    let sx = 0;
    let sy = 0;
    let sw = mw;
    let sh = mh;
    if (ir > wr) {
      sw = mh * wr;
      sx = (mw - sw) / 2;
    } else {
      sh = mw / wr;
      sy = (mh - sh) / 2;
    }
    ctx.drawImage(media, sx, sy, sw, sh, 0, 0, w, h);
    ctx.fillStyle = rgb(theme.bg, 0.46 + this.bloom * 0.12);
    ctx.fillRect(0, 0, w, h);
  }

  private fillBackdrop(
    w: number,
    h: number,
    theme: (typeof THEMES)[ThemeId],
    mode: VizMode,
    hasMedia: boolean,
  ) {
    if (hasMedia) return;
    const ctx = this.ctx;
    const g = ctx.createRadialGradient(
      w * 0.5,
      h * (mode === "bars" ? 0.58 : 0.5),
      0,
      w * 0.5,
      h * 0.5,
      Math.max(w, h) * 0.72,
    );
    const lift = 0.04 + this.bloom * 0.08;
    g.addColorStop(0, rgb(mix(theme.bg, theme.a, lift)));
    g.addColorStop(0.55, rgb(theme.bg));
    g.addColorStop(1, rgb(mix(theme.bg, [0, 0, 0], 0.55)));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }

  private drawBars(w: number, h: number, theme: (typeof THEMES)[ThemeId]) {
    const ctx = this.ctx;
    const count = BIN_COUNT;
    const margin = w * 0.08;
    const usable = w - margin * 2;
    const gap = Math.max(2, usable * 0.006);
    const bw = (usable - gap * (count - 1)) / count;
    const baseY = h * 0.62;
    const maxH = h * 0.42;
    const radius = Math.min(bw * 0.45, 6);

    for (let i = 0; i < count; i++) {
      const v = this.smoothed[i]!;
      const peak = this.peaks[i]!;
      const x = margin + i * (bw + gap);
      const bh = Math.max(2, v * maxH);
      const y = baseY - bh;
      const t = i / (count - 1);
      const col = mix(theme.a, mix(theme.b, theme.c, v), t * 0.65 + v * 0.35);

      ctx.fillStyle = rgb(col, 0.16);
      ctx.beginPath();
      roundRect(ctx, x - 1.5, y - 8, bw + 3, bh + 10, radius + 2);
      ctx.fill();

      const grad = ctx.createLinearGradient(x, y, x, baseY);
      grad.addColorStop(0, rgb(theme.c, 0.95));
      grad.addColorStop(0.45, rgb(col));
      grad.addColorStop(1, rgb(theme.a, 0.75));
      ctx.fillStyle = grad;
      ctx.beginPath();
      roundRect(ctx, x, y, bw, bh, radius);
      ctx.fill();

      ctx.fillStyle = rgb(theme.c, 0.85);
      const py = baseY - peak * maxH - 2;
      ctx.fillRect(x, py, bw, Math.max(2, bw * 0.18));

      const rh = bh * 0.45;
      const rg = ctx.createLinearGradient(x, baseY, x, baseY + rh);
      rg.addColorStop(0, rgb(col, 0.28));
      rg.addColorStop(1, rgb(col, 0));
      ctx.fillStyle = rg;
      ctx.fillRect(x, baseY + 4, bw, rh);
    }
  }

  private drawRing(w: number, h: number, theme: (typeof THEMES)[ThemeId]) {
    const ctx = this.ctx;
    const cx = w * 0.5;
    const cy = h * 0.5;
    const min = Math.min(w, h);
    const pulse = 1 + this.bass * 0.07;
    const inner = min * 0.22 * pulse;
    const maxLen = min * 0.28;
    const count = BIN_COUNT;
    const step = (Math.PI * 2) / count;
    const rot = this.rotation;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(rot);

    ctx.beginPath();
    ctx.arc(0, 0, inner - 6, 0, Math.PI * 2);
    ctx.strokeStyle = rgb(theme.c, 0.12 + this.bass * 0.2);
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(0, 0, inner + maxLen * 0.15, 0, Math.PI * 2);
    ctx.strokeStyle = rgb(theme.a, 0.08);
    ctx.lineWidth = 1;
    ctx.stroke();

    for (let i = 0; i < count; i++) {
      const v = this.smoothed[i]!;
      const peak = this.peaks[i]!;
      const a = i * step;
      const len = Math.max(4, v * maxLen);
      const t = i / count;
      const col = mix(theme.a, mix(theme.b, theme.c, v), 0.25 + 0.5 * Math.abs(Math.sin(t * Math.PI)));
      const bw = (inner * step) * 0.62;
      const x0 = Math.cos(a) * inner;
      const y0 = Math.sin(a) * inner;
      const x1 = Math.cos(a) * (inner + len);
      const y1 = Math.sin(a) * (inner + len);

      ctx.strokeStyle = rgb(col, 0.2);
      ctx.lineWidth = bw + 5;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.stroke();

      ctx.strokeStyle = rgb(col, 0.95);
      ctx.lineWidth = bw;
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.stroke();

      const px = Math.cos(a) * (inner + peak * maxLen + 3);
      const py = Math.sin(a) * (inner + peak * maxLen + 3);
      ctx.fillStyle = rgb(theme.c, 0.8);
      ctx.beginPath();
      ctx.arc(px, py, Math.max(1.4, bw * 0.22), 0, Math.PI * 2);
      ctx.fill();
    }

    const core = inner * (0.38 + this.bass * 0.12);
    const cg = ctx.createRadialGradient(0, 0, 0, 0, 0, core);
    cg.addColorStop(0, rgb(theme.c, 0.28 + this.bass * 0.35));
    cg.addColorStop(1, rgb(theme.a, 0));
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(0, 0, core, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private drawWave(
    w: number,
    h: number,
    theme: (typeof THEMES)[ThemeId],
    analysis: Analysis | null,
    time: number,
  ) {
    const ctx = this.ctx;
    const cx = w * 0.5;
    const cy = h * 0.5;
    const min = Math.min(w, h);
    const baseR = min * (0.2 + this.bass * 0.04);

    ctx.save();
    ctx.translate(cx, cy);

    for (let layer = 0; layer < 3; layer++) {
      const scale = 1 + layer * 0.18;
      const alpha = 0.55 - layer * 0.16;
      ctx.beginPath();
      const samples = analysis?.wave.length ?? 0;
      const n = samples > 0 ? Math.min(samples, 720) : 360;
      for (let i = 0; i <= n; i++) {
        const t = i / n;
        const ang = t * Math.PI * 2 + this.rotation * (0.4 + layer * 0.2);
        let amp = 0;
        if (samples > 0 && analysis) {
          const idx = Math.floor(t * (samples - 1)) % samples;
          amp = (analysis.wave[idx]! - 128) / 128;
        } else {
          amp =
            Math.sin(time * 1.6 + t * Math.PI * 8) * 0.18 +
            Math.sin(time * 0.7 + t * Math.PI * 4) * 0.12;
        }
        const r = (baseR + amp * min * 0.16 * (1.15 - layer * 0.2)) * scale;
        const x = Math.cos(ang) * r;
        const y = Math.sin(ang) * r;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.strokeStyle = rgb(layer === 0 ? theme.c : theme.a, alpha);
      ctx.lineWidth = layer === 0 ? 2.4 : 1.4;
      ctx.stroke();
      if (layer === 0) {
        ctx.fillStyle = rgb(theme.a, 0.08 + this.bass * 0.1);
        ctx.fill();
      }
    }

    const count = BIN_COUNT;
    const step = (Math.PI * 2) / count;
    for (let i = 0; i < count; i++) {
      const v = this.smoothed[i]!;
      const a = i * step + Math.PI / 2;
      const inner = baseR * 0.42;
      const len = v * min * 0.1;
      ctx.strokeStyle = rgb(mix(theme.a, theme.c, v), 0.55);
      ctx.lineWidth = 2;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * inner, Math.sin(a) * inner);
      ctx.lineTo(Math.cos(a) * (inner + len), Math.sin(a) * (inner + len));
      ctx.stroke();
    }

    ctx.restore();
  }

  private drawBloom(
    dt: number,
    w: number,
    h: number,
    theme: (typeof THEMES)[ThemeId],
    _analysis: Analysis | null,
    _live: boolean,
    _time: number,
  ) {
    const ctx = this.ctx;
    ctx.fillStyle = rgb(theme.bg, 0.22);
    ctx.fillRect(0, 0, w, h);

    const cx = w * 0.5;
    const cy = h * 0.5;
    const min = Math.min(w, h);

    const spawn =
      (this.particles.length < 90 ? 28 : 7) + Math.floor(this.bass * 18);
    for (let s = 0; s < spawn; s++) {
      if (this.particles.length > 420) break;
      const band = Math.floor(Math.random() * BIN_COUNT);
      const ang = (band / BIN_COUNT) * Math.PI * 2 + this.rotation;
      const speed = (0.08 + this.smoothed[band]! * 0.55) * min * 0.35;
      this.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(ang) * speed,
        vy: Math.sin(ang) * speed,
        life: 1,
        max: 0.7 + Math.random() * 1.1,
        size: 1.2 + this.smoothed[band]! * 5 + Math.random() * 2,
        band,
      });
    }

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i]!;
      p.life -= dt / p.max;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 0.992;
      p.vy *= 0.992;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      const col = mix(theme.a, theme.c, this.smoothed[p.band]!);
      ctx.fillStyle = rgb(col, Math.max(0, p.life) * 0.7);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (0.6 + p.life * 0.6), 0, Math.PI * 2);
      ctx.fill();
    }

    const core = min * (0.08 + this.bass * 0.06);
    const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, core * 2.4);
    cg.addColorStop(0, rgb(theme.c, 0.45 + this.bass * 0.4));
    cg.addColorStop(0.4, rgb(theme.a, 0.18));
    cg.addColorStop(1, rgb(theme.a, 0));
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(cx, cy, core * 2.4, 0, Math.PI * 2);
    ctx.fill();
  }
}

function toLogBins(freq: Uint8Array, out: Float32Array) {
  const n = out.length;
  const len = freq.length;
  for (let i = 0; i < n; i++) {
    const t0 = i / n;
    const t1 = (i + 1) / n;
    const i0 = Math.floor(Math.pow(t0, 2.15) * len);
    const i1 = Math.max(i0 + 1, Math.floor(Math.pow(t1, 2.15) * len));
    let sum = 0;
    let count = 0;
    const end = Math.min(len, i1);
    for (let b = i0; b < end; b++) {
      sum += freq[b]!;
      count++;
    }
    out[i] = count ? Math.pow(sum / count / 255, 1.1) : 0;
  }
}

function fillIdle(out: Float32Array, t: number) {
  const beat = Math.pow(Math.sin(t * 1.35) * 0.5 + 0.5, 1.8);
  const n = out.length;
  for (let i = 0; i < n; i++) {
    const x = i / (n - 1);
    const bass = Math.exp(-x * 3.6) * (0.32 + 0.55 * beat);
    const mid =
      Math.exp(-((x - 0.32) * (x - 0.32)) / 0.045) *
      (0.18 + 0.28 * (Math.sin(t * 0.85 + i * 0.18) * 0.5 + 0.5));
    const high = (0.06 + 0.1 * Math.sin(t * 2.05 + x * 14)) * Math.pow(x, 0.7);
    const shimmer = 0.04 * Math.sin(t * 3.1 + i * 0.41);
    out[i] = Math.min(1, Math.max(0, bass + mid + high + shimmer));
  }
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const radius = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.roundRect(x, y, w, h, radius);
}
