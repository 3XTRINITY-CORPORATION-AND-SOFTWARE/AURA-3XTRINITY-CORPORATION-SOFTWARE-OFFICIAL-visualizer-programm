export type VizMode = "bars" | "ring" | "wave" | "bloom";
export type SourceKind = "none" | "mic" | "file" | "demo";
export type ThemeId = "ice" | "ember" | "tide" | "rose" | "mono";

export type GeoMask = {
  status: string;
  country: string;
  countryCode: string;
  region: string;
  regionName: string;
  city: string;
  zip: string;
  lat: number | null;
  lon: number | null;
  timezone: string;
  isp: string;
  org: string;
  as: string;
  query: string;
  proxy: boolean;
  hosting: boolean;
  mobile: boolean;
  source: "ip-api" | "mmdb";
  remaining: string | null;
  ttl: string | null;
};

export const MODES: { id: VizMode; label: string }[] = [
  { id: "bars", label: "Bars" },
  { id: "ring", label: "Ring" },
  { id: "wave", label: "Wave" },
  { id: "bloom", label: "Bloom" },
];

export const THEME_IDS: ThemeId[] = ["ice", "ember", "tide", "rose", "mono"];
