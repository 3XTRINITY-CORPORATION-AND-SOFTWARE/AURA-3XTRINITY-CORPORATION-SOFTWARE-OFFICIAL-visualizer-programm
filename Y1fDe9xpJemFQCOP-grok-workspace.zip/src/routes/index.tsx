import { createFileRoute } from "@tanstack/react-router";
import { AuraApp } from "@/components/visualizer/aura-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AuraApp />;
}
