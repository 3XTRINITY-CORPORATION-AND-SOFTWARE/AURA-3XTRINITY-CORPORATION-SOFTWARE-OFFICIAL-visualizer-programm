import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as getServerFnById, n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
import { C as ChevronRight, D as AudioLines, E as BookOpen, O as Aperture, S as CircleDot, T as ChartColumn, _ as FolderOpen, a as Upload, b as Download, c as Play, d as Minimize2, f as Mic, g as Globe, h as Image$1, i as Volume2, l as Pause, m as KeyRound, n as Waves, p as Maximize2, r as VolumeX, s as Trash2, t as X, u as Music, v as Film, w as ChevronLeft, x as Disc3, y as FileText } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BcPadbd6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HPF = {
	type: "highpass",
	freq: 28,
	q: .7,
	gain: 0
};
var ANALOG_CURVES = {
	electronic: {
		id: "electronic",
		label: "Electronic",
		comment: "Cut 300 Hz and 4.2 kHz before a 80 Hz shelf. Fundamentals stay dry; even-harmonic mirror is light. Conservative master.",
		cuts: [
			HPF,
			{
				type: "peaking",
				freq: 300,
				q: .9,
				gain: -2.6
			},
			{
				type: "peaking",
				freq: 4200,
				q: 1.1,
				gain: -1.3
			}
		],
		boosts: [{
			type: "lowshelf",
			freq: 80,
			q: .7,
			gain: 1.2
		}, {
			type: "highshelf",
			freq: 11e3,
			q: .7,
			gain: .8
		}],
		drive: .22,
		makeup: .9
	},
	hiphop: {
		id: "hiphop",
		label: "Hip-hop",
		comment: "Cut 350 Hz mud before a 60 Hz shelf. Kick fundamental untouched; analog mirror on the body only.",
		cuts: [
			HPF,
			{
				type: "peaking",
				freq: 350,
				q: .85,
				gain: -2.2
			},
			{
				type: "peaking",
				freq: 3100,
				q: 1,
				gain: -1.5
			}
		],
		boosts: [{
			type: "lowshelf",
			freq: 62,
			q: .7,
			gain: 1.6
		}, {
			type: "highshelf",
			freq: 8500,
			q: .7,
			gain: .5
		}],
		drive: .18,
		makeup: .88
	},
	rock: {
		id: "rock",
		label: "Rock",
		comment: "Cut 280 Hz and 4 kHz before a 2.2 kHz presence lift. Phase-coherent series path, no stereo tricks.",
		cuts: [
			HPF,
			{
				type: "peaking",
				freq: 280,
				q: .8,
				gain: -1.8
			},
			{
				type: "peaking",
				freq: 4e3,
				q: 1.2,
				gain: -1.1
			}
		],
		boosts: [{
			type: "lowshelf",
			freq: 120,
			q: .7,
			gain: .7
		}, {
			type: "peaking",
			freq: 2200,
			q: .9,
			gain: 1.3
		}],
		drive: .2,
		makeup: .91
	},
	acoustic: {
		id: "acoustic",
		label: "Acoustic",
		comment: "Cut 400 Hz boxiness before 5 kHz air. Rounding is barely on — keeps the original transient.",
		cuts: [
			{
				type: "highpass",
				freq: 40,
				q: .7,
				gain: 0
			},
			{
				type: "peaking",
				freq: 400,
				q: .8,
				gain: -1.4
			},
			{
				type: "peaking",
				freq: 2500,
				q: 1,
				gain: -.6
			}
		],
		boosts: [{
			type: "peaking",
			freq: 5200,
			q: .8,
			gain: 1.1
		}, {
			type: "highshelf",
			freq: 12e3,
			q: .7,
			gain: .7
		}],
		drive: .12,
		makeup: .93
	},
	ambient: {
		id: "ambient",
		label: "Ambient",
		comment: "Gentle 250 Hz cut, no hype boosts. Mirror is a soft even-order haze; master stays under unity.",
		cuts: [
			{
				type: "highpass",
				freq: 24,
				q: .7,
				gain: 0
			},
			{
				type: "peaking",
				freq: 250,
				q: .7,
				gain: -1.1
			},
			{
				type: "peaking",
				freq: 5e3,
				q: .8,
				gain: -.4
			}
		],
		boosts: [{
			type: "highshelf",
			freq: 1e4,
			q: .7,
			gain: .5
		}, {
			type: "peaking",
			freq: 180,
			q: .6,
			gain: .3
		}],
		drive: .14,
		makeup: .94
	},
	pop: {
		id: "pop",
		label: "Pop",
		comment: "Cut 320 Hz before a 1 dB 100 Hz shelf and 3 kHz presence. Hardware-agnostic conservative master.",
		cuts: [
			HPF,
			{
				type: "peaking",
				freq: 320,
				q: .9,
				gain: -2
			},
			{
				type: "peaking",
				freq: 3500,
				q: 1.1,
				gain: -1
			}
		],
		boosts: [{
			type: "lowshelf",
			freq: 100,
			q: .7,
			gain: 1
		}, {
			type: "peaking",
			freq: 3e3,
			q: .85,
			gain: 1
		}],
		drive: .16,
		makeup: .9
	}
};
function makeMirrorCurve(drive) {
	const n = 1024;
	const curve = new Float32Array(n);
	const k = .1 * drive;
	const sat = 1 + .28 * drive;
	for (let i = 0; i < n; i++) {
		const x = i / 1023 * 2 - 1;
		const odd = Math.tanh(x * sat);
		const even = k * (x * x - 1 / 3);
		curve[i] = Math.max(-1, Math.min(1, (odd + even) * .97));
	}
	return curve;
}
/**
* Always-connected analog path.
* Dry = original fundamentals; wet = cut-before-boost + even-harmonic mirror.
* No resample, no requantize — same bit format as the context (float32).
*/
var AnalogPath = class {
	input;
	output;
	dry;
	wet;
	makeup;
	shaper;
	cuts;
	boosts;
	ctx;
	enabled = true;
	constructor(ctx) {
		this.ctx = ctx;
		this.input = ctx.createGain();
		this.output = ctx.createGain();
		this.dry = ctx.createGain();
		this.wet = ctx.createGain();
		this.makeup = ctx.createGain();
		this.shaper = ctx.createWaveShaper();
		this.shaper.oversample = "2x";
		this.shaper.curve = makeMirrorCurve(.16);
		this.cuts = [
			0,
			1,
			2
		].map(() => ctx.createBiquadFilter());
		this.boosts = [0, 1].map(() => ctx.createBiquadFilter());
		this.input.connect(this.dry);
		this.dry.connect(this.output);
		let node = this.input;
		for (const f of this.cuts) {
			node.connect(f);
			node = f;
		}
		for (const f of this.boosts) {
			node.connect(f);
			node = f;
		}
		node.connect(this.shaper);
		this.shaper.connect(this.makeup);
		this.makeup.connect(this.wet);
		this.wet.connect(this.output);
		this.dry.gain.value = .62;
		this.wet.gain.value = .38;
		this.makeup.gain.value = .9;
		this.apply(ANALOG_CURVES.pop, true);
	}
	setEnabled(on) {
		this.enabled = on;
		const t = this.ctx.currentTime;
		if (on) {
			this.dry.gain.setTargetAtTime(.62, t, .04);
			this.wet.gain.setTargetAtTime(.38, t, .04);
		} else {
			this.dry.gain.setTargetAtTime(1, t, .04);
			this.wet.gain.setTargetAtTime(1e-4, t, .04);
		}
	}
	apply(curve, instant = false) {
		const t = this.ctx.currentTime;
		const tau = instant ? .001 : .06;
		curve.cuts.forEach((band, i) => {
			const f = this.cuts[i];
			if (!f) return;
			f.type = band.type;
			f.frequency.setTargetAtTime(band.freq, t, tau);
			f.Q.setTargetAtTime(band.q, t, tau);
			f.gain.setTargetAtTime(band.gain, t, tau);
		});
		curve.boosts.forEach((band, i) => {
			const f = this.boosts[i];
			if (!f) return;
			f.type = band.type;
			f.frequency.setTargetAtTime(band.freq, t, tau);
			f.Q.setTargetAtTime(band.q, t, tau);
			f.gain.setTargetAtTime(band.gain, t, tau);
		});
		this.shaper.curve = makeMirrorCurve(curve.drive);
		this.makeup.gain.setTargetAtTime(curve.makeup, t, tau);
	}
};
function makeNoiseBuffer(ctx) {
	const length = ctx.sampleRate * 2;
	const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
	const data = buffer.getChannelData(0);
	let last = 0;
	for (let i = 0; i < length; i++) {
		const white = Math.random() * 2 - 1;
		last = (last + .02 * white) / 1.02;
		data[i] = last * 3.5;
	}
	return buffer;
}
var AudioEngine = class {
	ctx = null;
	analyser = null;
	master = null;
	bus = null;
	analog = null;
	freq = /* @__PURE__ */ new Uint8Array(1024);
	wave = /* @__PURE__ */ new Uint8Array(2048);
	micStream = null;
	micSource = null;
	audioEl = null;
	videoEl = null;
	mediaSource = null;
	videoSource = null;
	fileUrl = null;
	demo = null;
	extraNodes = [];
	mediaKind = null;
	async unlock() {
		if (!this.ctx) {
			const Ctor = window.AudioContext || window.webkitAudioContext;
			try {
				this.ctx = new Ctor({
					latencyHint: "playback",
					sampleRate: 44100
				});
			} catch {
				this.ctx = new Ctor({ latencyHint: "playback" });
			}
			this.master = this.ctx.createGain();
			this.master.gain.value = 1e-4;
			this.bus = this.ctx.createGain();
			this.analog = new AnalogPath(this.ctx);
			this.analyser = this.ctx.createAnalyser();
			this.analyser.fftSize = 2048;
			this.analyser.smoothingTimeConstant = .78;
			this.analyser.minDecibels = -88;
			this.analyser.maxDecibels = -18;
			this.bus.connect(this.analog.input);
			this.analog.output.connect(this.analyser);
			this.analyser.connect(this.master);
			this.master.connect(this.ctx.destination);
			this.freq = new Uint8Array(this.analyser.frequencyBinCount);
			this.wave = new Uint8Array(this.analyser.fftSize);
		}
		if (this.ctx.state === "suspended") await this.ctx.resume();
		return this.ctx;
	}
	get sampleRate() {
		return this.ctx?.sampleRate ?? 44100;
	}
	setAnalog(on) {
		this.analog?.setEnabled(on);
	}
	applyCurve(curve) {
		this.analog?.apply(curve);
	}
	setVolume(linear) {
		if (!this.ctx || !this.master) return;
		const v = Math.max(0, Math.min(1, linear));
		const gain = v * v;
		this.master.gain.setTargetAtTime(Math.max(gain, 1e-4), this.ctx.currentTime, .04);
	}
	tap() {
		return this.bus;
	}
	disconnectSources() {
		this.micSource?.disconnect();
		this.micSource = null;
		if (this.micStream) {
			for (const track of this.micStream.getTracks()) track.stop();
			this.micStream = null;
		}
		this.mediaSource?.disconnect();
		this.videoSource?.disconnect();
		if (this.audioEl) this.audioEl.pause();
		if (this.videoEl) this.videoEl.pause();
		this.stopDemo();
	}
	get visualVideo() {
		return this.mediaKind === "video" ? this.videoEl : null;
	}
	get mediaEl() {
		if (this.mediaKind === "video") return this.videoEl;
		return this.audioEl;
	}
	halt() {
		this.disconnectSources();
	}
	stopDemo() {
		if (!this.demo) return;
		for (const osc of this.demo.oscs) {
			try {
				osc.stop();
			} catch {}
			try {
				osc.disconnect();
			} catch {}
		}
		this.demo.stopTimer();
		this.demo = null;
		for (const node of this.extraNodes) try {
			node.disconnect();
		} catch {}
		this.extraNodes = [];
	}
	async startMic() {
		await this.unlock();
		if (!this.ctx || !this.bus) return;
		this.disconnectSources();
		const stream = await navigator.mediaDevices.getUserMedia({ audio: {
			echoCancellation: false,
			noiseSuppression: false,
			autoGainControl: false
		} });
		this.micStream = stream;
		this.micSource = this.ctx.createMediaStreamSource(stream);
		this.micSource.connect(this.tap());
		this.setVolume(0);
	}
	async startFile(file) {
		await this.unlock();
		if (!this.ctx || !this.bus) throw new Error("Audio is unavailable.");
		this.disconnectSources();
		const isVideo = file.type.startsWith("video/") || /\.(mp4|webm|mov|m4v|ogv|flv|mkv)$/i.test(file.name);
		if (this.fileUrl) URL.revokeObjectURL(this.fileUrl);
		this.fileUrl = URL.createObjectURL(file);
		if (isVideo) {
			if (!this.videoEl) {
				const el = document.createElement("video");
				el.crossOrigin = "anonymous";
				el.preload = "auto";
				el.playsInline = true;
				el.setAttribute("playsinline", "true");
				el.setAttribute("webkit-playsinline", "true");
				this.videoEl = el;
				this.videoSource = this.ctx.createMediaElementSource(el);
			}
			this.videoEl.src = this.fileUrl;
			this.videoEl.loop = false;
			this.mediaKind = "video";
			this.videoSource.connect(this.tap());
			await this.videoEl.play();
			return this.videoEl;
		}
		if (!this.audioEl) {
			const el = document.createElement("audio");
			el.crossOrigin = "anonymous";
			el.preload = "auto";
			el.setAttribute("playsinline", "true");
			el.setAttribute("webkit-playsinline", "true");
			this.audioEl = el;
			this.mediaSource = this.ctx.createMediaElementSource(el);
		}
		this.audioEl.src = this.fileUrl;
		this.mediaKind = "audio";
		this.mediaSource.connect(this.tap());
		await this.audioEl.play();
		return this.audioEl;
	}
	async startDemo() {
		const ctx = await this.unlock();
		if (!this.bus) return;
		this.disconnectSources();
		const pad = ctx.createGain();
		pad.gain.value = .22;
		pad.connect(this.tap());
		this.extraNodes.push(pad);
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = 1400;
		filter.Q.value = 6;
		filter.connect(pad);
		this.extraNodes.push(filter);
		const flfo = ctx.createOscillator();
		flfo.type = "sine";
		flfo.frequency.value = .11;
		const flfoGain = ctx.createGain();
		flfoGain.gain.value = 1100;
		flfo.connect(flfoGain);
		flfoGain.connect(filter.frequency);
		flfo.start();
		this.extraNodes.push(flfoGain);
		const notes = [
			130.81,
			164.81,
			196,
			246.94,
			329.63,
			392
		];
		const oscs = [flfo];
		notes.forEach((freq, i) => {
			const osc = ctx.createOscillator();
			osc.type = i % 2 === 0 ? "sine" : "triangle";
			osc.frequency.value = freq;
			const g = ctx.createGain();
			g.gain.value = .11 - i * .012;
			const lfo = ctx.createOscillator();
			lfo.frequency.value = .05 + i * .027;
			const lfoG = ctx.createGain();
			lfoG.gain.value = .035;
			lfo.connect(lfoG);
			lfoG.connect(g.gain);
			osc.connect(g);
			g.connect(filter);
			osc.start();
			lfo.start();
			oscs.push(osc, lfo);
			this.extraNodes.push(g, lfoG);
		});
		const noise = ctx.createBufferSource();
		noise.buffer = makeNoiseBuffer(ctx);
		noise.loop = true;
		const noiseFilter = ctx.createBiquadFilter();
		noiseFilter.type = "bandpass";
		noiseFilter.frequency.value = 2400;
		noiseFilter.Q.value = 1.4;
		const noiseGain = ctx.createGain();
		noiseGain.gain.value = .07;
		noise.connect(noiseFilter);
		noiseFilter.connect(noiseGain);
		noiseGain.connect(this.tap());
		noise.start();
		this.extraNodes.push(noise, noiseFilter, noiseGain);
		const nlfo = ctx.createOscillator();
		nlfo.frequency.value = .19;
		const nlfoG = ctx.createGain();
		nlfoG.gain.value = 900;
		nlfo.connect(nlfoG);
		nlfoG.connect(noiseFilter.frequency);
		nlfo.start();
		oscs.push(nlfo);
		this.extraNodes.push(nlfoG);
		let stopped = false;
		let timer = 0;
		const kick = () => {
			if (stopped || !this.ctx) return;
			const now = this.ctx.currentTime;
			const osc = this.ctx.createOscillator();
			const g = this.ctx.createGain();
			osc.type = "sine";
			osc.frequency.setValueAtTime(68, now);
			osc.frequency.exponentialRampToValueAtTime(36, now + .22);
			g.gain.setValueAtTime(1e-4, now);
			g.gain.exponentialRampToValueAtTime(.7, now + .012);
			g.gain.exponentialRampToValueAtTime(1e-4, now + .32);
			osc.connect(g);
			g.connect(this.tap());
			osc.start(now);
			osc.stop(now + .34);
			oscs.push(osc);
			this.extraNodes.push(g);
			timer = window.setTimeout(kick, 640);
		};
		kick();
		this.demo = {
			oscs,
			stopTimer: () => {
				stopped = true;
				window.clearTimeout(timer);
			}
		};
		this.analog?.apply(ANALOG_CURVES.ambient);
	}
	pauseFile() {
		this.mediaEl?.pause();
	}
	async resumeFile() {
		await this.mediaEl?.play();
	}
	seek(time) {
		const el = this.mediaEl;
		if (el) el.currentTime = time;
	}
	sample() {
		const empty = {
			freq: this.freq,
			wave: this.wave,
			bass: 0,
			mids: 0,
			highs: 0,
			rms: 0
		};
		if (!this.analyser) return empty;
		this.analyser.getByteFrequencyData(this.freq);
		this.analyser.getByteTimeDomainData(this.wave);
		const n = this.freq.length;
		let bass = 0;
		let mids = 0;
		let highs = 0;
		const bEnd = Math.max(1, Math.floor(n * .08));
		const mEnd = Math.max(bEnd + 1, Math.floor(n * .4));
		for (let i = 0; i < n; i++) {
			const v = this.freq[i] / 255;
			if (i < bEnd) bass += v;
			else if (i < mEnd) mids += v;
			else highs += v;
		}
		bass /= bEnd;
		mids /= mEnd - bEnd;
		highs /= n - mEnd;
		let rms = 0;
		for (let i = 0; i < this.wave.length; i++) {
			const s = (this.wave[i] - 128) / 128;
			rms += s * s;
		}
		rms = Math.sqrt(rms / this.wave.length);
		return {
			freq: this.freq,
			wave: this.wave,
			bass,
			mids,
			highs,
			rms
		};
	}
	dispose() {
		this.disconnectSources();
		if (this.fileUrl) URL.revokeObjectURL(this.fileUrl);
		this.fileUrl = null;
		this.ctx?.close();
		this.ctx = null;
		this.analyser = null;
		this.master = null;
		this.bus = null;
		this.analog = null;
		this.audioEl = null;
		this.videoEl = null;
		this.mediaSource = null;
		this.videoSource = null;
		this.mediaKind = null;
	}
};
function monoMix(buffer, maxSeconds) {
	const sr = buffer.sampleRate;
	const len = Math.min(buffer.length, Math.floor(sr * maxSeconds));
	const out = new Float32Array(len);
	const ch = buffer.numberOfChannels;
	for (let c = 0; c < ch; c++) {
		const data = buffer.getChannelData(c);
		for (let i = 0; i < len; i++) out[i] += data[i] / ch;
	}
	return out;
}
function estimateBpm(samples, sr) {
	const hop = 512;
	const win = 1024;
	const env = [];
	const limit = Math.min(samples.length, sr * 8);
	for (let i = 0; i + win < limit; i += hop) {
		let e = 0;
		for (let j = 0; j < win; j++) e += Math.abs(samples[i + j]);
		env.push(e / win);
	}
	if (env.length < 24) return 120;
	const flux = env.map((v, i) => i === 0 ? 0 : Math.max(0, v - env[i - 1]));
	const hopTime = hop / sr;
	let bestBpm = 120;
	let best = 0;
	for (let bpm = 70; bpm <= 180; bpm++) {
		const lag = Math.round(60 / bpm / hopTime);
		if (lag < 1 || lag >= flux.length) continue;
		let s = 0;
		for (let i = 0; i < flux.length - lag; i++) s += flux[i] * flux[i + lag];
		if (s > best) {
			best = s;
			bestBpm = bpm;
		}
	}
	return bestBpm;
}
function dftRadix2(re, im) {
	const n = re.length;
	for (let i = 1, j = 0; i < n; i++) {
		let bit = n >> 1;
		for (; j & bit; bit >>= 1) j ^= bit;
		j ^= bit;
		if (i < j) {
			const tr = re[i];
			re[i] = re[j];
			re[j] = tr;
			const ti = im[i];
			im[i] = im[j];
			im[j] = ti;
		}
	}
	for (let size = 2; size <= n; size <<= 1) {
		const half = size >> 1;
		const step = 2 * Math.PI / size;
		for (let i = 0; i < n; i += size) for (let k = 0; k < half; k++) {
			const c = Math.cos(step * k);
			const s = -Math.sin(step * k);
			const tr = c * re[i + k + half] - s * im[i + k + half];
			const ti = s * re[i + k + half] + c * im[i + k + half];
			re[i + k + half] = re[i + k] - tr;
			im[i + k + half] = im[i + k] - ti;
			re[i + k] += tr;
			im[i + k] += ti;
		}
	}
}
function spectralFeatures(samples, sr, bands) {
	const fftSize = 2048;
	const hop = 2048;
	const half = fftSize / 2;
	const mag = new Float32Array(half);
	const re = new Float32Array(fftSize);
	const im = new Float32Array(fftSize);
	let frames = 0;
	const limit = Math.min(samples.length, sr * 6);
	for (let off = 0; off + fftSize < limit; off += hop) {
		re.fill(0);
		im.fill(0);
		for (let i = 0; i < fftSize; i++) {
			const w = .5 - .5 * Math.cos(2 * Math.PI * i / 2047);
			re[i] = samples[off + i] * w;
		}
		dftRadix2(re, im);
		for (let k = 0; k < half; k++) mag[k] += re[k] * re[k] + im[k] * im[k];
		frames++;
	}
	if (frames) for (let k = 0; k < half; k++) mag[k] = mag[k] / frames;
	const sumRange = (lo, hi) => {
		const i0 = Math.max(1, Math.floor(lo / sr * fftSize));
		const i1 = Math.min(1023, Math.ceil(hi / sr * fftSize));
		let e = 0;
		for (let k = i0; k <= i1; k++) e += mag[k];
		return e / Math.max(1, i1 - i0 + 1);
	};
	const spectrum = [];
	let max = 1e-9;
	for (let i = 0; i < bands; i++) {
		const t0 = i / bands;
		const t1 = (i + 1) / bands;
		const f0 = 40 * Math.pow((sr / 2 - 40) / 40, t0);
		const f1 = 40 * Math.pow((sr / 2 - 40) / 40, t1);
		const v = Math.sqrt(sumRange(f0, f1));
		spectrum.push(v);
		if (v > max) max = v;
	}
	return {
		bass: sumRange(30, 140),
		mid: sumRange(140, 2e3),
		high: sumRange(2e3, 1e4),
		spectrum: spectrum.map((v) => Math.min(1, v / max))
	};
}
function pickGenre(bass, mid, high, bpm) {
	const tot = bass + mid + high + 1e-6;
	const b = bass / tot;
	const m = mid / tot;
	const h = high / tot;
	if (bpm < 88 && h < .28 && b < .4) return "ambient";
	if (b > .42 && bpm <= 102) return "hiphop";
	if (b > .34 && bpm >= 118 && h > .22) return "electronic";
	if (m > .36 && b < .4 && bpm >= 90 && bpm <= 160) return "rock";
	if (h + m > .7 && b < .28) return "acoustic";
	return "pop";
}
async function analyzeTrack(ctx, file) {
	const raw = await file.arrayBuffer();
	const buffer = await ctx.decodeAudioData(raw.slice(0));
	const samples = monoMix(buffer, 10);
	const sr = buffer.sampleRate;
	const bpm = estimateBpm(samples, sr);
	const feats = spectralFeatures(samples, sr, 24);
	const genre = pickGenre(feats.bass, feats.mid, feats.high, bpm);
	const curve = ANALOG_CURVES[genre];
	return {
		genre,
		genreLabel: curve.label,
		bpm,
		curve,
		sampleRate: sr,
		channels: buffer.numberOfChannels,
		duration: buffer.duration,
		bitLabel: "32-bit float path · source format preserved",
		spectrum: feats.spectrum
	};
}
var CORE_PRICE = "€49";
var CHECKOUT_URL = "https://buy.stripe.com/test_8x29ASemJ3pXb7w9S2gjC00";
var GITHUB_REPO = "https://github.com/antonioportfelli-boop/aura-core";
var LICENSE_KEY = "aura-core-license-v1";
var KEYS = {
	"CORE-1900": "launch",
	"CORE-STUDIO": "studio",
	"CORE-LIVE": "studio"
};
function loadLicense() {
	if (typeof window === "undefined") return {
		plan: "demo",
		key: "",
		at: 0
	};
	try {
		const raw = window.localStorage.getItem(LICENSE_KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			if (parsed?.plan && parsed.plan !== "demo") return parsed;
		}
	} catch {}
	return {
		plan: "demo",
		key: "",
		at: 0
	};
}
function saveLicense(license) {
	try {
		window.localStorage.setItem(LICENSE_KEY, JSON.stringify(license));
	} catch {}
}
function redeemKey(raw) {
	const key = raw.trim().toUpperCase().replace(/\s+/g, "");
	const plan = KEYS[key];
	if (!plan) return null;
	const license = {
		plan,
		key,
		at: Date.now()
	};
	saveLicense(license);
	return license;
}
function isLicensed(plan) {
	return plan === "launch" || plan === "studio";
}
function isStandalone() {
	if (typeof window === "undefined") return false;
	return window.matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
}
var BOOT_LINES = [
	"AURA CORE 0.9",
	"kernel ………… analog bus",
	"clock ………… 44.1 kHz request",
	"path ………… dry 0.62 / wet 0.38",
	"media ………… indexed store",
	"install ………… ready"
];
var PLATES = [
	{
		file: "158.jpg",
		title: "Blue hour",
		note: "Crescent over the field. Analog path keeps the fundamental; the haze is the mirror."
	},
	{
		file: "114.jpg",
		title: "Canopy",
		note: "Sun through leaves — cut mud before any lift."
	},
	{
		file: "110.jpg",
		title: "Waterline",
		note: "Moon over still water. Phase-coherent series path."
	},
	{
		file: "89.jpg",
		title: "Pink hour",
		note: "Same sky, quieter take. Conservative master."
	},
	{
		file: "90.jpg",
		title: "Bloom",
		note: "Flower and moon. Light even-harmonic rounding."
	},
	{
		file: "159.jpg",
		title: "Road",
		note: "Sunrise on dirt. The curve scales with the speakers."
	},
	{
		file: "120.jpg",
		title: "Mark",
		note: "Identity plate. Same bit format through the chain."
	}
];
var NOTE_FILES = [
	{
		href: "/notes/AURA-Import-Export.docx",
		label: "Spec"
	},
	{
		href: "/notes/AURA-Analog-44.1.pdf",
		label: "PDF"
	},
	{
		href: "/notes/AURA-Analog-44.1.pptx",
		label: "Slides"
	},
	{
		href: "/notes/AURA-Analog-44.1.xlsx",
		label: "Curves"
	}
];
var AUDIO_EXT = /* @__PURE__ */ new Set([
	"mp3",
	"wav",
	"ogg",
	"flac",
	"m4a",
	"aac",
	"aiff",
	"aif",
	"opus",
	"weba",
	"caf",
	"fl"
]);
var VIDEO_EXT = /* @__PURE__ */ new Set([
	"mp4",
	"webm",
	"mov",
	"m4v",
	"ogv",
	"flv",
	"mkv"
]);
var IMAGE_EXT = /* @__PURE__ */ new Set([
	"jpg",
	"jpeg",
	"png",
	"webp",
	"gif",
	"avif",
	"bmp",
	"svg"
]);
var TEXT_EXT = /* @__PURE__ */ new Set([
	"txt",
	"lrc",
	"md",
	"json",
	"csv",
	"srt"
]);
var DB_NAME = "aura-media-v1";
var MAX_BYTES = 94371840;
var urlCache = /* @__PURE__ */ new Map();
var BUILTINS = PLATES.map((p) => ({
	id: `plate-${p.file}`,
	name: p.title,
	kind: "image",
	mime: "image/jpeg",
	size: 0,
	addedAt: 0,
	builtin: true,
	url: `/notes/plates/${p.file}`
}));
function extOf(name) {
	const i = name.lastIndexOf(".");
	return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}
function classifyFile(file) {
	const ext = extOf(file.name);
	const type = (file.type || "").toLowerCase();
	if (ext === "json" || file.name.toLowerCase().endsWith(".aura.json")) return "project";
	if (type.startsWith("audio/") || AUDIO_EXT.has(ext)) return "audio";
	if (type.startsWith("video/") || VIDEO_EXT.has(ext)) return "video";
	if (type.startsWith("image/") || IMAGE_EXT.has(ext)) return "image";
	if (type.startsWith("text/") || TEXT_EXT.has(ext)) return "text";
	return null;
}
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta", { keyPath: "id" });
			if (!db.objectStoreNames.contains("blobs")) db.createObjectStore("blobs");
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
function txDone(tx) {
	return new Promise((resolve, reject) => {
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
		tx.onabort = () => reject(tx.error);
	});
}
async function idbPut(item, blob) {
	const db = await openDb();
	const tx = db.transaction(["meta", "blobs"], "readwrite");
	tx.objectStore("meta").put(item);
	tx.objectStore("blobs").put(blob, item.id);
	await txDone(tx);
	db.close();
}
async function idbDelete(id) {
	const db = await openDb();
	const tx = db.transaction(["meta", "blobs"], "readwrite");
	tx.objectStore("meta").delete(id);
	tx.objectStore("blobs").delete(id);
	await txDone(tx);
	db.close();
}
async function idbList() {
	const db = await openDb();
	const req = db.transaction("meta", "readonly").objectStore("meta").getAll();
	const rows = await new Promise((resolve, reject) => {
		req.onsuccess = () => resolve(req.result ?? []);
		req.onerror = () => reject(req.error);
	});
	db.close();
	return rows.sort((a, b) => b.addedAt - a.addedAt);
}
async function idbBlob(id) {
	const db = await openDb();
	const req = db.transaction("blobs", "readonly").objectStore("blobs").get(id);
	const blob = await new Promise((resolve, reject) => {
		req.onsuccess = () => resolve(req.result ?? null);
		req.onerror = () => reject(req.error);
	});
	db.close();
	return blob;
}
function uid() {
	return `m-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
var useLibrary = create((set, get) => ({
	items: BUILTINS,
	ready: false,
	backdropId: BUILTINS[0]?.id ?? null,
	lyricsId: null,
	hydrate: async () => {
		if (typeof indexedDB === "undefined") {
			set({ ready: true });
			return;
		}
		try {
			set({
				items: [...await idbList(), ...BUILTINS],
				ready: true
			});
		} catch {
			set({ ready: true });
		}
	},
	importFiles: async (files) => {
		const added = [];
		const skipped = [];
		let project = null;
		for (const file of files) {
			const kind = classifyFile(file);
			if (!kind) {
				skipped.push(file.name);
				continue;
			}
			if (kind === "project") {
				try {
					const parsed = JSON.parse(await file.text());
					if (parsed?.kind === "aura-project") {
						project = parsed;
						continue;
					}
				} catch {}
				const item = {
					id: uid(),
					name: file.name,
					kind: "text",
					mime: file.type || "application/json",
					size: file.size,
					addedAt: Date.now(),
					text: await file.text().catch(() => "")
				};
				try {
					await idbPut(item, file);
					added.push(item);
				} catch {
					skipped.push(file.name);
				}
				continue;
			}
			if (file.size > MAX_BYTES) {
				skipped.push(file.name);
				continue;
			}
			const item = {
				id: uid(),
				name: file.name,
				kind,
				mime: file.type || "application/octet-stream",
				size: file.size,
				addedAt: Date.now()
			};
			if (kind === "text") item.text = await file.text();
			try {
				await idbPut(item, file);
				added.push(item);
				const url = URL.createObjectURL(file);
				urlCache.set(item.id, url);
			} catch {
				skipped.push(file.name);
			}
		}
		if (added.length) set({ items: [...added, ...get().items] });
		return {
			items: added,
			project,
			skipped
		};
	},
	remove: async (id) => {
		const item = get().items.find((x) => x.id === id);
		if (!item || item.builtin) return;
		await idbDelete(id);
		const cached = urlCache.get(id);
		if (cached) {
			URL.revokeObjectURL(cached);
			urlCache.delete(id);
		}
		set((s) => ({
			items: s.items.filter((x) => x.id !== id),
			backdropId: s.backdropId === id ? null : s.backdropId,
			lyricsId: s.lyricsId === id ? null : s.lyricsId
		}));
	},
	setBackdrop: (id) => set({ backdropId: id }),
	setLyrics: (id) => set({ lyricsId: id }),
	objectUrl: async (item) => {
		if (item.url) return item.url;
		const cached = urlCache.get(item.id);
		if (cached) return cached;
		const blob = await idbBlob(item.id);
		if (!blob) return null;
		const url = URL.createObjectURL(blob);
		urlCache.set(item.id, url);
		return url;
	},
	readText: async (item) => {
		if (item.text != null) return item.text;
		const blob = await idbBlob(item.id);
		return blob ? blob.text() : "";
	},
	blobFor: async (item) => {
		if (item.builtin && item.url) return (await fetch(item.url)).blob();
		return idbBlob(item.id);
	}
}));
function downloadBlob(blob, name) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	a.click();
	window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function formatBytes(n) {
	if (n <= 0) return "built-in";
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(1)} MB`;
}
var PREFS_KEY = "aura-prefs-v1";
function loadPrefs() {
	if (typeof window === "undefined") return {};
	try {
		const raw = window.localStorage.getItem(PREFS_KEY);
		if (!raw) return {};
		return JSON.parse(raw);
	} catch {
		return {};
	}
}
function savePrefs(prefs) {
	try {
		window.localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
	} catch {}
}
var persist = (state) => {
	savePrefs({
		mode: state.mode,
		theme: state.theme,
		sensitivity: state.sensitivity,
		volume: state.volume,
		analogOn: state.analogOn
	});
};
var useViz = create((set, get) => ({
	source: "none",
	mode: "ring",
	theme: "ice",
	sensitivity: 1.15,
	volume: .72,
	playing: false,
	fileName: null,
	duration: 0,
	currentTime: 0,
	error: null,
	fullscreen: false,
	controlsOpen: true,
	hydrated: false,
	dragging: false,
	analogOn: true,
	notesOpen: false,
	libraryOpen: false,
	storeOpen: false,
	civilOpen: false,
	geo: null,
	booting: true,
	license: {
		plan: "demo",
		key: "",
		at: 0
	},
	overlayText: "",
	analyzing: false,
	genre: null,
	bpm: null,
	curveComment: "",
	sampleRate: null,
	channels: null,
	bitLabel: "",
	spectrum: [],
	setSource: (source) => set({
		source,
		error: null
	}),
	setMode: (mode) => {
		set({ mode });
		persist(get());
	},
	setTheme: (theme) => {
		set({ theme });
		persist(get());
	},
	setSensitivity: (sensitivity) => {
		set({ sensitivity });
		persist(get());
	},
	setVolume: (volume) => {
		set({ volume });
		persist(get());
	},
	setPlaying: (playing) => set({ playing }),
	setFileMeta: (fileName, duration) => set({
		fileName,
		duration
	}),
	setCurrentTime: (currentTime) => set({ currentTime }),
	setError: (error) => set({ error }),
	setFullscreen: (fullscreen) => set({ fullscreen }),
	setControlsOpen: (controlsOpen) => set({ controlsOpen }),
	setDragging: (dragging) => set({ dragging }),
	setAnalogOn: (analogOn) => {
		set({ analogOn });
		persist(get());
	},
	setNotesOpen: (notesOpen) => set({ notesOpen }),
	setLibraryOpen: (libraryOpen) => set({ libraryOpen }),
	setStoreOpen: (storeOpen) => set({ storeOpen }),
	setCivilOpen: (civilOpen) => set({ civilOpen }),
	setGeo: (geo) => set({ geo }),
	setBooting: (booting) => set({ booting }),
	setLicense: (license) => set({ license }),
	setOverlayText: (overlayText) => set({ overlayText }),
	setAnalyzing: (analyzing) => set({ analyzing }),
	setTrackReport: (report) => set({
		genre: report.genre,
		bpm: report.bpm,
		curveComment: report.curveComment,
		sampleRate: report.sampleRate,
		channels: report.channels,
		bitLabel: report.bitLabel,
		spectrum: report.spectrum,
		analyzing: false
	}),
	clearTrackReport: () => set({
		genre: null,
		bpm: null,
		curveComment: "",
		sampleRate: null,
		channels: null,
		bitLabel: "",
		spectrum: [],
		analyzing: false
	}),
	hydrate: () => {
		if (get().hydrated) return;
		const prefs = loadPrefs();
		set({
			mode: prefs.mode ?? "ring",
			theme: prefs.theme ?? "ice",
			sensitivity: prefs.sensitivity ?? 1.15,
			volume: prefs.volume ?? .72,
			analogOn: prefs.analogOn ?? true,
			license: loadLicense(),
			booting: typeof window === "undefined" ? false : !sessionStorage.getItem("aura-booted"),
			hydrated: true
		});
		if (typeof window !== "undefined") sessionStorage.setItem("aura-booted", "1");
	}
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatTime(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
	return `${Math.floor(seconds / 60)}:${Math.floor(seconds % 60).toString().padStart(2, "0")}`;
}
function AnalogDesk() {
	const analogOn = useViz((s) => s.analogOn);
	const analyzing = useViz((s) => s.analyzing);
	const genre = useViz((s) => s.genre);
	const bpm = useViz((s) => s.bpm);
	const curveComment = useViz((s) => s.curveComment);
	const sampleRate = useViz((s) => s.sampleRate);
	const channels = useViz((s) => s.channels);
	const bitLabel = useViz((s) => s.bitLabel);
	const spectrum = useViz((s) => s.spectrum);
	const fileName = useViz((s) => s.fileName);
	const source = useViz((s) => s.source);
	const controlsOpen = useViz((s) => s.controlsOpen);
	if (source === "none") return null;
	if (!analogOn && !genre && !analyzing) return null;
	const rateLabel = sampleRate != null ? `${(sampleRate / 1e3).toFixed(1)} kHz` : "44.1 kHz";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: cn("pointer-events-none absolute top-10 left-0 z-20 max-w-sm p-3 pt-[max(0.75rem,env(safe-area-inset-top))]", "transition-opacity duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]", controlsOpen ? "opacity-100" : "opacity-0"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto rounded-xl bg-surface/92 p-3 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase",
				children: "Analog desk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-3 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-subtle uppercase",
						children: "1 · Genre"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm font-medium text-fg",
						children: analyzing ? "Reading the room…" : genre ?? "Awaiting a track"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-subtle uppercase",
							children: "2 · Decision"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex h-8 items-end gap-px",
							children: (spectrum.length ? spectrum : Array.from({ length: 24 }, () => .12)).map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 rounded-sm bg-fg/70",
								style: { height: `${Math.max(8, Math.round(v * 100))}%` }
							}, i))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1.5 font-mono text-xs tabular-nums text-muted",
							children: [bpm != null ? `${bpm} BPM` : "— BPM", " · spectrogram"]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-subtle uppercase",
							children: "3 · Track"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate text-sm text-fg",
							children: fileName ?? (source === "demo" ? "Ambient demo" : "Live input")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 font-mono text-xs text-subtle",
							children: [
								rateLabel,
								channels ? ` · ${channels} ch` : "",
								" · ",
								bitLabel || "same bit format"
							]
						}),
						curveComment ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 line-clamp-3 text-xs leading-relaxed text-muted text-pretty",
							children: curveComment
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs leading-relaxed text-muted",
							children: "Original fundamentals mixed with analog mirroring. Cut before boost. No resample."
						})
					] })
				]
			})]
		})
	});
}
function BootScreen() {
	const booting = useViz((s) => s.booting);
	const setBooting = useViz((s) => s.setBooting);
	const [n, setN] = (0, import_react.useState)(1);
	(0, import_react.useEffect)(() => {
		if (!booting) return;
		const id = window.setInterval(() => {
			setN((v) => {
				if (v >= BOOT_LINES.length) {
					window.clearInterval(id);
					window.setTimeout(() => setBooting(false), 280);
					return v;
				}
				return v + 1;
			});
		}, 220);
		return () => window.clearInterval(id);
	}, [booting, setBooting]);
	if (!booting) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-50 flex items-center justify-center bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm px-6 font-mono text-xs leading-6 text-muted",
			children: [BOOT_LINES.slice(0, n).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: line.startsWith("AURA") ? "text-fg" : void 0,
				children: line
			}, line)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-subtle",
				children: "ok"
			})]
		})
	});
}
var THEMES = {
	ice: {
		id: "ice",
		label: "Ice",
		a: [
			56,
			189,
			248
		],
		b: [
			125,
			211,
			252
		],
		c: [
			224,
			242,
			254
		],
		bg: [
			5,
			8,
			12
		]
	},
	ember: {
		id: "ember",
		label: "Ember",
		a: [
			251,
			113,
			133
		],
		b: [
			251,
			146,
			60
		],
		c: [
			254,
			215,
			170
		],
		bg: [
			10,
			6,
			5
		]
	},
	tide: {
		id: "tide",
		label: "Tide",
		a: [
			34,
			211,
			238
		],
		b: [
			56,
			189,
			248
		],
		c: [
			147,
			197,
			253
		],
		bg: [
			4,
			8,
			12
		]
	},
	rose: {
		id: "rose",
		label: "Rose",
		a: [
			251,
			113,
			133
		],
		b: [
			253,
			164,
			175
		],
		c: [
			255,
			228,
			230
		],
		bg: [
			12,
			5,
			7
		]
	},
	mono: {
		id: "mono",
		label: "Mono",
		a: [
			228,
			228,
			231
		],
		b: [
			212,
			212,
			216
		],
		c: [
			250,
			250,
			250
		],
		bg: [
			7,
			7,
			8
		]
	}
};
function rgb(c, alpha = 1) {
	if (alpha >= 1) return `rgb(${c[0]},${c[1]},${c[2]})`;
	return `rgba(${c[0]},${c[1]},${c[2]},${alpha})`;
}
function mix(a, b, t) {
	const u = Math.max(0, Math.min(1, t));
	return [
		a[0] + (b[0] - a[0]) * u,
		a[1] + (b[1] - a[1]) * u,
		a[2] + (b[2] - a[2]) * u
	];
}
var BIN_COUNT = 72;
var VisualizerRenderer = class {
	canvas;
	ctx;
	smoothed = new Float32Array(BIN_COUNT);
	peaks = new Float32Array(BIN_COUNT);
	scratch = new Float32Array(BIN_COUNT);
	particles = [];
	rotation = 0;
	lastMode = null;
	bass = 0;
	bloom = 0;
	constructor(canvas) {
		this.canvas = canvas;
		const ctx = canvas.getContext("2d", { alpha: false });
		if (!ctx) throw new Error("Canvas is unavailable.");
		this.ctx = ctx;
	}
	resize() {
		const parent = this.canvas.parentElement;
		if (!parent) return;
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const w = parent.clientWidth;
		const h = parent.clientHeight;
		const pw = Math.max(1, Math.floor(w * dpr));
		const ph = Math.max(1, Math.floor(h * dpr));
		if (this.canvas.width !== pw || this.canvas.height !== ph) {
			this.canvas.width = pw;
			this.canvas.height = ph;
			this.canvas.style.width = `${w}px`;
			this.canvas.style.height = `${h}px`;
		}
	}
	frame(dt, analysis, live, mode, themeId, sensitivity, time, media = null) {
		this.resize();
		const { ctx, canvas } = this;
		const w = canvas.width;
		const h = canvas.height;
		const theme = THEMES[themeId];
		if (this.lastMode !== mode) {
			this.particles.length = 0;
			this.lastMode = mode;
			ctx.setTransform(1, 0, 0, 1, 0, 0);
			ctx.globalAlpha = 1;
			ctx.fillStyle = rgb(theme.bg);
			ctx.fillRect(0, 0, w, h);
		}
		if (live && analysis) {
			toLogBins(analysis.freq, this.scratch);
			const gain = Math.max(.4, sensitivity);
			for (let i = 0; i < BIN_COUNT; i++) this.scratch[i] = Math.min(1, this.scratch[i] * gain);
		} else {
			fillIdle(this.scratch, time);
			const idleGain = .62 + Math.min(.4, Math.max(0, sensitivity - .4) * .18);
			for (let i = 0; i < BIN_COUNT; i++) this.scratch[i] = this.scratch[i] * idleGain;
		}
		const follow = 1 - Math.exp(-dt * (live ? 11 : 4.5));
		let energy = 0;
		let bass = 0;
		for (let i = 0; i < BIN_COUNT; i++) {
			const next = this.smoothed[i] + (this.scratch[i] - this.smoothed[i]) * follow;
			this.smoothed[i] = next;
			energy += next;
			if (i < 10) bass += next;
			const fall = dt * .42;
			this.peaks[i] = Math.max(this.peaks[i] - fall, next);
		}
		energy /= BIN_COUNT;
		bass /= 10;
		this.bass += (bass - this.bass) * (1 - Math.exp(-dt * 8));
		this.bloom += (energy - this.bloom) * (1 - Math.exp(-dt * 5));
		this.rotation += dt * (.08 + this.bass * .35);
		this.drawMedia(w, h, media, theme);
		if (mode === "bloom") this.drawBloom(dt, w, h, theme, analysis, live, time);
		else {
			this.fillBackdrop(w, h, theme, mode, Boolean(media));
			if (mode === "bars") this.drawBars(w, h, theme);
			else if (mode === "ring") this.drawRing(w, h, theme);
			else this.drawWave(w, h, theme, analysis, time);
		}
	}
	drawMedia(w, h, media, theme) {
		const ctx = this.ctx;
		if (!media) {
			ctx.fillStyle = rgb(theme.bg);
			ctx.fillRect(0, 0, w, h);
			return;
		}
		const mw = media instanceof HTMLVideoElement ? media.videoWidth : media instanceof HTMLImageElement ? media.naturalWidth : 0;
		const mh = media instanceof HTMLVideoElement ? media.videoHeight : media instanceof HTMLImageElement ? media.naturalHeight : 0;
		if (mw < 2 || mh < 2) {
			ctx.fillStyle = rgb(theme.bg);
			ctx.fillRect(0, 0, w, h);
			return;
		}
		const ir = mw / mh;
		const wr = w / h;
		let sx = 0;
		let sy = 0;
		let sw = mw;
		let sh = mh;
		if (ir > wr) {
			sw = mh * wr;
			sx = (mw - sw) / 2;
		} else {
			sh = mw / wr;
			sy = (mh - sh) / 2;
		}
		ctx.drawImage(media, sx, sy, sw, sh, 0, 0, w, h);
		ctx.fillStyle = rgb(theme.bg, .46 + this.bloom * .12);
		ctx.fillRect(0, 0, w, h);
	}
	fillBackdrop(w, h, theme, mode, hasMedia) {
		if (hasMedia) return;
		const ctx = this.ctx;
		const g = ctx.createRadialGradient(w * .5, h * (mode === "bars" ? .58 : .5), 0, w * .5, h * .5, Math.max(w, h) * .72);
		const lift = .04 + this.bloom * .08;
		g.addColorStop(0, rgb(mix(theme.bg, theme.a, lift)));
		g.addColorStop(.55, rgb(theme.bg));
		g.addColorStop(1, rgb(mix(theme.bg, [
			0,
			0,
			0
		], .55)));
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, w, h);
	}
	drawBars(w, h, theme) {
		const ctx = this.ctx;
		const count = BIN_COUNT;
		const margin = w * .08;
		const usable = w - margin * 2;
		const gap = Math.max(2, usable * .006);
		const bw = (usable - gap * 71) / count;
		const baseY = h * .62;
		const maxH = h * .42;
		const radius = Math.min(bw * .45, 6);
		for (let i = 0; i < count; i++) {
			const v = this.smoothed[i];
			const peak = this.peaks[i];
			const x = margin + i * (bw + gap);
			const bh = Math.max(2, v * maxH);
			const y = baseY - bh;
			const t = i / 71;
			const col = mix(theme.a, mix(theme.b, theme.c, v), t * .65 + v * .35);
			ctx.fillStyle = rgb(col, .16);
			ctx.beginPath();
			roundRect(ctx, x - 1.5, y - 8, bw + 3, bh + 10, radius + 2);
			ctx.fill();
			const grad = ctx.createLinearGradient(x, y, x, baseY);
			grad.addColorStop(0, rgb(theme.c, .95));
			grad.addColorStop(.45, rgb(col));
			grad.addColorStop(1, rgb(theme.a, .75));
			ctx.fillStyle = grad;
			ctx.beginPath();
			roundRect(ctx, x, y, bw, bh, radius);
			ctx.fill();
			ctx.fillStyle = rgb(theme.c, .85);
			const py = baseY - peak * maxH - 2;
			ctx.fillRect(x, py, bw, Math.max(2, bw * .18));
			const rh = bh * .45;
			const rg = ctx.createLinearGradient(x, baseY, x, baseY + rh);
			rg.addColorStop(0, rgb(col, .28));
			rg.addColorStop(1, rgb(col, 0));
			ctx.fillStyle = rg;
			ctx.fillRect(x, baseY + 4, bw, rh);
		}
	}
	drawRing(w, h, theme) {
		const ctx = this.ctx;
		const cx = w * .5;
		const cy = h * .5;
		const min = Math.min(w, h);
		const pulse = 1 + this.bass * .07;
		const inner = min * .22 * pulse;
		const maxLen = min * .28;
		const count = BIN_COUNT;
		const step = Math.PI * 2 / count;
		const rot = this.rotation;
		ctx.save();
		ctx.translate(cx, cy);
		ctx.rotate(rot);
		ctx.beginPath();
		ctx.arc(0, 0, inner - 6, 0, Math.PI * 2);
		ctx.strokeStyle = rgb(theme.c, .12 + this.bass * .2);
		ctx.lineWidth = 2;
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(0, 0, inner + maxLen * .15, 0, Math.PI * 2);
		ctx.strokeStyle = rgb(theme.a, .08);
		ctx.lineWidth = 1;
		ctx.stroke();
		for (let i = 0; i < count; i++) {
			const v = this.smoothed[i];
			const peak = this.peaks[i];
			const a = i * step;
			const len = Math.max(4, v * maxLen);
			const t = i / count;
			const col = mix(theme.a, mix(theme.b, theme.c, v), .25 + .5 * Math.abs(Math.sin(t * Math.PI)));
			const bw = inner * step * .62;
			const x0 = Math.cos(a) * inner;
			const y0 = Math.sin(a) * inner;
			const x1 = Math.cos(a) * (inner + len);
			const y1 = Math.sin(a) * (inner + len);
			ctx.strokeStyle = rgb(col, .2);
			ctx.lineWidth = bw + 5;
			ctx.lineCap = "round";
			ctx.beginPath();
			ctx.moveTo(x0, y0);
			ctx.lineTo(x1, y1);
			ctx.stroke();
			ctx.strokeStyle = rgb(col, .95);
			ctx.lineWidth = bw;
			ctx.beginPath();
			ctx.moveTo(x0, y0);
			ctx.lineTo(x1, y1);
			ctx.stroke();
			const px = Math.cos(a) * (inner + peak * maxLen + 3);
			const py = Math.sin(a) * (inner + peak * maxLen + 3);
			ctx.fillStyle = rgb(theme.c, .8);
			ctx.beginPath();
			ctx.arc(px, py, Math.max(1.4, bw * .22), 0, Math.PI * 2);
			ctx.fill();
		}
		const core = inner * (.38 + this.bass * .12);
		const cg = ctx.createRadialGradient(0, 0, 0, 0, 0, core);
		cg.addColorStop(0, rgb(theme.c, .28 + this.bass * .35));
		cg.addColorStop(1, rgb(theme.a, 0));
		ctx.fillStyle = cg;
		ctx.beginPath();
		ctx.arc(0, 0, core, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
	}
	drawWave(w, h, theme, analysis, time) {
		const ctx = this.ctx;
		const cx = w * .5;
		const cy = h * .5;
		const min = Math.min(w, h);
		const baseR = min * (.2 + this.bass * .04);
		ctx.save();
		ctx.translate(cx, cy);
		for (let layer = 0; layer < 3; layer++) {
			const scale = 1 + layer * .18;
			const alpha = .55 - layer * .16;
			ctx.beginPath();
			const samples = analysis?.wave.length ?? 0;
			const n = samples > 0 ? Math.min(samples, 720) : 360;
			for (let i = 0; i <= n; i++) {
				const t = i / n;
				const ang = t * Math.PI * 2 + this.rotation * (.4 + layer * .2);
				let amp = 0;
				if (samples > 0 && analysis) {
					const idx = Math.floor(t * (samples - 1)) % samples;
					amp = (analysis.wave[idx] - 128) / 128;
				} else amp = Math.sin(time * 1.6 + t * Math.PI * 8) * .18 + Math.sin(time * .7 + t * Math.PI * 4) * .12;
				const r = (baseR + amp * min * .16 * (1.15 - layer * .2)) * scale;
				const x = Math.cos(ang) * r;
				const y = Math.sin(ang) * r;
				if (i === 0) ctx.moveTo(x, y);
				else ctx.lineTo(x, y);
			}
			ctx.closePath();
			ctx.strokeStyle = rgb(layer === 0 ? theme.c : theme.a, alpha);
			ctx.lineWidth = layer === 0 ? 2.4 : 1.4;
			ctx.stroke();
			if (layer === 0) {
				ctx.fillStyle = rgb(theme.a, .08 + this.bass * .1);
				ctx.fill();
			}
		}
		const count = BIN_COUNT;
		const step = Math.PI * 2 / count;
		for (let i = 0; i < count; i++) {
			const v = this.smoothed[i];
			const a = i * step + Math.PI / 2;
			const inner = baseR * .42;
			const len = v * min * .1;
			ctx.strokeStyle = rgb(mix(theme.a, theme.c, v), .55);
			ctx.lineWidth = 2;
			ctx.lineCap = "round";
			ctx.beginPath();
			ctx.moveTo(Math.cos(a) * inner, Math.sin(a) * inner);
			ctx.lineTo(Math.cos(a) * (inner + len), Math.sin(a) * (inner + len));
			ctx.stroke();
		}
		ctx.restore();
	}
	drawBloom(dt, w, h, theme, _analysis, _live, _time) {
		const ctx = this.ctx;
		ctx.fillStyle = rgb(theme.bg, .22);
		ctx.fillRect(0, 0, w, h);
		const cx = w * .5;
		const cy = h * .5;
		const min = Math.min(w, h);
		const spawn = (this.particles.length < 90 ? 28 : 7) + Math.floor(this.bass * 18);
		for (let s = 0; s < spawn; s++) {
			if (this.particles.length > 420) break;
			const band = Math.floor(Math.random() * BIN_COUNT);
			const ang = band / BIN_COUNT * Math.PI * 2 + this.rotation;
			const speed = (.08 + this.smoothed[band] * .55) * min * .35;
			this.particles.push({
				x: cx,
				y: cy,
				vx: Math.cos(ang) * speed,
				vy: Math.sin(ang) * speed,
				life: 1,
				max: .7 + Math.random() * 1.1,
				size: 1.2 + this.smoothed[band] * 5 + Math.random() * 2,
				band
			});
		}
		for (let i = this.particles.length - 1; i >= 0; i--) {
			const p = this.particles[i];
			p.life -= dt / p.max;
			p.x += p.vx * dt;
			p.y += p.vy * dt;
			p.vx *= .992;
			p.vy *= .992;
			if (p.life <= 0) {
				this.particles.splice(i, 1);
				continue;
			}
			ctx.fillStyle = rgb(mix(theme.a, theme.c, this.smoothed[p.band]), Math.max(0, p.life) * .7);
			ctx.beginPath();
			ctx.arc(p.x, p.y, p.size * (.6 + p.life * .6), 0, Math.PI * 2);
			ctx.fill();
		}
		const core = min * (.08 + this.bass * .06);
		const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, core * 2.4);
		cg.addColorStop(0, rgb(theme.c, .45 + this.bass * .4));
		cg.addColorStop(.4, rgb(theme.a, .18));
		cg.addColorStop(1, rgb(theme.a, 0));
		ctx.fillStyle = cg;
		ctx.beginPath();
		ctx.arc(cx, cy, core * 2.4, 0, Math.PI * 2);
		ctx.fill();
	}
};
function toLogBins(freq, out) {
	const n = out.length;
	const len = freq.length;
	for (let i = 0; i < n; i++) {
		const t0 = i / n;
		const t1 = (i + 1) / n;
		const i0 = Math.floor(Math.pow(t0, 2.15) * len);
		const i1 = Math.max(i0 + 1, Math.floor(Math.pow(t1, 2.15) * len));
		let sum = 0;
		let count = 0;
		const end = Math.min(len, i1);
		for (let b = i0; b < end; b++) {
			sum += freq[b];
			count++;
		}
		out[i] = count ? Math.pow(sum / count / 255, 1.1) : 0;
	}
}
function fillIdle(out, t) {
	const beat = Math.pow(Math.sin(t * 1.35) * .5 + .5, 1.8);
	const n = out.length;
	for (let i = 0; i < n; i++) {
		const x = i / (n - 1);
		const bass = Math.exp(-x * 3.6) * (.32 + .55 * beat);
		const mid = Math.exp(-((x - .32) * (x - .32)) / .045) * (.18 + .28 * (Math.sin(t * .85 + i * .18) * .5 + .5));
		const high = (.06 + .1 * Math.sin(t * 2.05 + x * 14)) * Math.pow(x, .7);
		const shimmer = .04 * Math.sin(t * 3.1 + i * .41);
		out[i] = Math.min(1, Math.max(0, bass + mid + high + shimmer));
	}
}
function roundRect(ctx, x, y, w, h, r) {
	const radius = Math.max(0, Math.min(r, w / 2, h / 2));
	ctx.roundRect(x, y, w, h, radius);
}
function CanvasStage({ engineRef, canvasOut }) {
	const canvasRef = (0, import_react.useRef)(null);
	const imgRef = (0, import_react.useRef)(null);
	const loopVideoRef = (0, import_react.useRef)(null);
	const mode = useViz((s) => s.mode);
	const theme = useViz((s) => s.theme);
	const sensitivity = useViz((s) => s.sensitivity);
	const source = useViz((s) => s.source);
	const playing = useViz((s) => s.playing);
	const backdropId = useLibrary((s) => s.backdropId);
	const items = useLibrary((s) => s.items);
	(0, import_react.useEffect)(() => {
		canvasOut.current = canvasRef.current;
	});
	(0, import_react.useEffect)(() => {
		const item = items.find((x) => x.id === backdropId);
		let dead = false;
		const prevLoop = loopVideoRef.current;
		if (prevLoop) {
			prevLoop.pause();
			loopVideoRef.current = null;
		}
		if (!item || item.kind !== "image" && item.kind !== "video") {
			imgRef.current = null;
			return;
		}
		useLibrary.getState().objectUrl(item).then((url) => {
			if (!url || dead) return;
			if (item.kind === "image") {
				const img = new Image();
				img.crossOrigin = "anonymous";
				img.onload = () => {
					if (!dead) imgRef.current = img;
				};
				img.src = url;
				return;
			}
			const v = document.createElement("video");
			v.crossOrigin = "anonymous";
			v.muted = true;
			v.loop = true;
			v.playsInline = true;
			v.src = url;
			v.onloadeddata = () => {
				if (dead) return;
				loopVideoRef.current = v;
				v.play().catch(() => void 0);
			};
		});
		return () => {
			dead = true;
		};
	}, [backdropId, items]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const renderer = new VisualizerRenderer(canvas);
		let raf = 0;
		let last = performance.now();
		const empty = null;
		const loop = (now) => {
			const raw = (now - last) / 1e3;
			const dt = Math.min(raw, .1);
			last = now;
			const state = useViz.getState();
			const engine = engineRef.current;
			const live = state.source !== "none" && (state.source === "mic" || state.playing);
			const analysis = live && engine ? engine.sample() : empty;
			const media = engine?.visualVideo && engine.visualVideo.readyState >= 2 ? engine.visualVideo : loopVideoRef.current && loopVideoRef.current.readyState >= 2 ? loopVideoRef.current : imgRef.current;
			renderer.frame(dt, analysis, live, state.mode, state.theme, state.sensitivity, now / 1e3, media);
			const el = engine?.mediaEl;
			if (state.source === "file" && el) {
				const t = el.currentTime;
				if (Math.abs(t - state.currentTime) > .15) useViz.getState().setCurrentTime(t);
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		const onVis = () => {
			if (document.visibilityState === "visible") engineRef.current?.unlock();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => {
			cancelAnimationFrame(raf);
			document.removeEventListener("visibilitychange", onVis);
		};
	}, [engineRef]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvasRef,
		className: "absolute inset-0 size-full touch-none",
		"aria-hidden": "true",
		"data-mode": mode,
		"data-theme": theme,
		"data-sensitivity": sensitivity,
		"data-source": source,
		"data-playing": playing ? "1" : "0"
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[opacity,transform,background-color,box-shadow,color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg shadow-[var(--shadow-border)] hover:opacity-90",
			secondary: "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:bg-surface-2/80",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-fg/5",
			ghost: "text-muted hover:bg-fg/10 hover:text-fg",
			solid: "bg-fg text-bg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-md px-3 text-xs",
			lg: "h-12 rounded-xl px-5",
			icon: "size-11",
			"icon-sm": "size-10 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var probeCivil = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") return { query: "" };
	const q = input.query;
	return { query: typeof q === "string" ? q : "" };
}).handler(createSsrRpc("1ece0b3480406ffe5afb289a296331a875a52a843bf70c259fb5ee970475471b"));
function unwrap(res) {
	const root = res && typeof res === "object" ? res : null;
	const payload = root && "result" in root && root.result && typeof root.result === "object" ? root.result : root;
	if (payload?.ok === true && payload.geo && typeof payload.geo === "object") return {
		ok: true,
		geo: payload.geo
	};
	return {
		ok: false,
		error: typeof payload?.error === "string" && payload.error ? payload.error : "Civil door returned no mask."
	};
}
function CivilDoor() {
	const open = useViz((s) => s.civilOpen);
	const setCivilOpen = useViz((s) => s.setCivilOpen);
	const geo = useViz((s) => s.geo);
	const setGeo = useViz((s) => s.setGeo);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") setCivilOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, setCivilOpen]);
	if (!open) return null;
	const flags = geo ? [
		geo.hosting ? "hosting" : null,
		geo.proxy ? "proxy" : null,
		geo.mobile ? "mobile" : null
	].filter(Boolean).join(" · ") || "none" : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "pointer-events-auto absolute top-12 left-0 z-30 w-full max-w-sm p-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[min(70dvh,36rem)] overflow-y-auto rounded-xl bg-surface/95 p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase",
							children: "Civil door"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "One backend GET. Same field mask. Not an extra on the analog path."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Close civil door",
						onClick: () => setCivilOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				geo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 space-y-1 font-mono text-xs text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "engine",
							v: geo.source
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "country",
							v: `${geo.country} (${geo.countryCode})`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "city",
							v: geo.city || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "region",
							v: geo.regionName || geo.region || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "zip",
							v: geo.zip || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "coord",
							v: geo.lat != null && geo.lon != null ? `${geo.lat.toFixed(2)}, ${geo.lon.toFixed(2)}` : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "timezone",
							v: geo.timezone || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "isp",
							v: geo.isp || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "org",
							v: geo.org || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "as",
							v: geo.as || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "query",
							v: geo.query
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "flags",
							v: flags
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "rate",
							v: `X-Rl ${geo.remaining ?? "—"} · X-Ttl ${geo.ttl ?? "—"}`
						})
					]
				}) : !error && !busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "No probe yet."
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-danger",
					role: "alert",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-4 block text-xs font-medium tracking-wide text-subtle uppercase",
					children: "Query"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "caller, or an IP",
					className: "mt-1 h-11 w-full rounded-lg bg-surface-2 px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none focus-visible:ring-2 focus-visible:ring-fg/40",
					"aria-label": "Civil query",
					autoCapitalize: "off",
					autoCorrect: "off",
					spellCheck: false,
					onKeyDown: (e) => {
						if (e.key === "Enter") {
							e.preventDefault();
							runProbe(query, setBusy, setError, setGeo);
						}
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "solid",
					className: "mt-3 w-full",
					disabled: busy,
					onClick: () => void runProbe(query, setBusy, setError, setGeo),
					children: busy ? "Probing…" : "Probe caller"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 font-mono text-[0.65rem] leading-relaxed text-subtle",
					children: [
						"bus · analog kernel (curve) · civil door (ip-api)",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"once-only mask · no hidden listener · coordinates stay off analog extras"
					]
				})
			]
		})
	});
}
async function runProbe(query, setBusy, setError, setGeo) {
	setBusy(true);
	setError(null);
	const ac = new AbortController();
	const timer = window.setTimeout(() => ac.abort(), 12e3);
	try {
		const parsed = unwrap(await probeCivil({
			data: { query },
			signal: ac.signal
		}));
		if (!parsed.ok) {
			setError(parsed.error);
			return;
		}
		setGeo(parsed.geo);
	} catch {
		setError("Civil door failed.");
	} finally {
		window.clearTimeout(timer);
		setBusy(false);
	}
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "w-20 shrink-0 text-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "min-w-0 truncate",
			title: v,
			children: v
		})]
	});
}
function Slider({ className, defaultValue, value, min = 0, max = 100, ...props }) {
	const _values = import_react.useMemo(() => Array.isArray(value) ? value : Array.isArray(defaultValue) ? defaultValue : [min], [
		value,
		defaultValue,
		min
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		"data-slot": "slider",
		defaultValue,
		value,
		min,
		max,
		className: cn("relative flex w-full touch-none items-center select-none py-3", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "bg-fg/15 relative h-1 w-full grow overflow-hidden rounded-full",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "bg-fg absolute h-full" })
		}), _values.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "border-bg bg-fg block size-3.5 rounded-full border-2 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-[var(--motion-micro)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40" }, i))]
	});
}
var THEME_IDS = [
	"ice",
	"ember",
	"tide",
	"rose",
	"mono"
];
var MODE_ICONS = {
	bars: ChartColumn,
	ring: CircleDot,
	wave: Waves,
	bloom: Aperture
};
function ControlDock({ onMic, onFile, onDemo, onTogglePlay, onSeek, onFullscreen, onToggleAnalog, onLibrary }) {
	const source = useViz((s) => s.source);
	const playing = useViz((s) => s.playing);
	const mode = useViz((s) => s.mode);
	const theme = useViz((s) => s.theme);
	const sensitivity = useViz((s) => s.sensitivity);
	const volume = useViz((s) => s.volume);
	const fileName = useViz((s) => s.fileName);
	const duration = useViz((s) => s.duration);
	const currentTime = useViz((s) => s.currentTime);
	const fullscreen = useViz((s) => s.fullscreen);
	const open = useViz((s) => s.controlsOpen);
	const analogOn = useViz((s) => s.analogOn);
	const libraryOpen = useViz((s) => s.libraryOpen);
	const setMode = useViz((s) => s.setMode);
	const setTheme = useViz((s) => s.setTheme);
	const setSensitivity = useViz((s) => s.setSensitivity);
	const setVolume = useViz((s) => s.setVolume);
	const canPlay = source === "file" || source === "demo";
	const showProgress = source === "file" && duration > 0;
	const status = source === "mic" ? "Listening" : source === "demo" ? "Ambient demo" : source === "file" ? fileName ?? "Track" : "Idle";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pointer-events-none absolute inset-x-0 bottom-0 z-20 flex justify-center px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-10", "transition-[opacity,transform] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]", open ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2 pointer-events-none"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("pointer-events-auto w-full max-w-4xl rounded-xl bg-surface/92 p-2 shadow-[var(--shadow-border)]", "flex flex-col gap-2"),
			onPointerDown: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 px-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("size-1.5 shrink-0 rounded-full", source === "mic" && playing ? "bg-fg animate-pulse" : source !== "none" && playing ? "bg-fg" : "bg-subtle"),
							"aria-hidden": true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-0 flex-1 truncate text-xs font-medium text-muted",
							children: status
						}),
						showProgress ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "shrink-0 font-mono text-[0.7rem] tabular-nums text-subtle",
							children: [
								formatTime(currentTime),
								" / ",
								formatTime(duration)
							]
						}) : null
					]
				}),
				showProgress ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: duration,
					step: .1,
					value: [currentTime],
					onValueChange: (v) => onSeek(v[0] ?? 0),
					"aria-label": "Seek",
					className: "px-1 py-1"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1.5 sm:flex-row sm:items-center sm:gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: "Microphone",
								pressed: source === "mic",
								onClick: onMic,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: "Open track",
								pressed: source === "file",
								onClick: onFile,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {})
							}),
							canPlay ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: playing ? "Pause" : "Play",
								onClick: onTogglePlay,
								children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-px" })
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: "Play demo",
								onClick: onDemo,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-px" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-1 hidden h-6 w-px bg-border sm:block" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center",
								role: "group",
								"aria-label": "Visualization mode",
								children: [
									"bars",
									"ring",
									"wave",
									"bloom"
								].map((id) => {
									const Icon = MODE_ICONS[id];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: id[0].toUpperCase() + id.slice(1),
										pressed: mode === id,
										onClick: () => setMode(id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
									}, id);
								})
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1.5 px-1",
								role: "group",
								"aria-label": "Color theme",
								children: THEME_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeDot, {
									id,
									active: theme === id,
									onClick: () => setTheme(id)
								}, id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "hidden shrink-0 text-[0.65rem] font-medium tracking-wide text-subtle uppercase md:block",
								children: "Sense"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: .4,
								max: 2.2,
								step: .01,
								value: [sensitivity],
								onValueChange: (v) => setSensitivity(v[0] ?? 1),
								"aria-label": "Sensitivity",
								className: "min-w-0 flex-1 py-2"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: volume <= .01 ? "Unmute" : "Mute",
								onClick: () => setVolume(volume <= .01 ? .72 : 0),
								children: volume <= .01 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								min: 0,
								max: 1,
								step: .01,
								value: [volume],
								onValueChange: (v) => setVolume(v[0] ?? 0),
								"aria-label": "Volume",
								className: "hidden min-w-16 max-w-24 py-2 sm:flex"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: analogOn ? "Analog path on" : "Analog path off",
								pressed: analogOn,
								onClick: onToggleAnalog,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disc3, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: "Media library",
								pressed: libraryOpen,
								onClick: onLibrary,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: fullscreen ? "Exit fullscreen" : "Fullscreen",
								onClick: onFullscreen,
								children: fullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, {})
							})
						]
					})]
				})
			]
		})
	});
}
function IconBtn({ label, pressed, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		variant: "ghost",
		size: "icon-sm",
		"aria-label": label,
		"aria-pressed": pressed,
		title: label,
		onClick,
		className: cn(pressed && "bg-fg/10 text-fg"),
		children
	});
}
function ThemeDot({ id, active, onClick }) {
	const t = THEMES[id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		title: t.label,
		"aria-label": `${t.label} theme`,
		"aria-pressed": active,
		onClick,
		className: cn("size-6 rounded-full transition-[transform,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)]", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-fg/40", active ? "scale-110" : "opacity-80 hover:opacity-100"),
		style: {
			background: `rgb(${t.a[0]}, ${t.a[1]}, ${t.a[2]})`,
			boxShadow: active ? `0 0 0 2px var(--color-bg), 0 0 0 4px rgb(${t.c[0]} ${t.c[1]} ${t.c[2]})` : "0 0 0 1px rgb(242 242 243 / 0.18)"
		}
	});
}
function FieldNotes() {
	const open = useViz((s) => s.notesOpen);
	const setNotesOpen = useViz((s) => s.setNotesOpen);
	const [i, setI] = (0, import_react.useState)(0);
	const plate = PLATES[i];
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") setNotesOpen(false);
			if (e.key === "ArrowRight") setI((n) => (n + 1) % PLATES.length);
			if (e.key === "ArrowLeft") setI((n) => (n - 1 + PLATES.length) % PLATES.length);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, setNotesOpen]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-40 flex bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-w-0 flex-1 bg-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: `/notes/plates/${plate.file}`,
					alt: plate.title,
					className: "h-full w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 bg-bg/70 p-4 sm:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-semibold",
						children: plate.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: plate.note
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden w-[min(100%,22rem)] shrink-0 flex-col justify-between overflow-y-auto p-5 sm:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase",
						children: "Field notes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display mt-3 text-3xl font-semibold tracking-[-0.04em]",
						children: "Analog 44.1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted text-pretty",
						children: "Original fundamentals mixed with analog mirroring. Same bit format. Cut before boost."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-8 text-xs font-medium tracking-wide text-subtle uppercase",
						children: [
							"Plate ",
							String(i + 1).padStart(2, "0"),
							" / ",
							String(PLATES.length).padStart(2, "0")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-xl font-semibold",
						children: plate.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: plate.note
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-subtle uppercase",
					children: "Downloads"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 grid grid-cols-2 gap-2",
					children: NOTE_FILES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: f.href,
						download: true,
						className: cn("inline-flex h-11 items-center justify-center rounded-lg text-sm font-medium", "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:bg-surface-2/80"),
						children: f.label
					}, f.href))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-3 right-3 flex gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Previous plate",
						onClick: () => setI((n) => (n - 1 + PLATES.length) % PLATES.length),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Next plate",
						onClick: () => setI((n) => (n + 1) % PLATES.length),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Close field notes",
						onClick: () => setNotesOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute right-3 bottom-3 grid grid-cols-2 gap-2 sm:hidden",
				children: NOTE_FILES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: f.href,
					download: true,
					className: "inline-flex h-10 items-center justify-center rounded-md bg-surface px-3 text-xs font-medium text-fg shadow-[var(--shadow-border)]",
					children: f.label
				}, f.href))
			})
		]
	});
}
function KernelBar({ onInstall, canInstall }) {
	const analogOn = useViz((s) => s.analogOn);
	const sampleRate = useViz((s) => s.sampleRate);
	const license = useViz((s) => s.license);
	const storeOpen = useViz((s) => s.storeOpen);
	const setStoreOpen = useViz((s) => s.setStoreOpen);
	const civilOpen = useViz((s) => s.civilOpen);
	const setCivilOpen = useViz((s) => s.setCivilOpen);
	const geo = useViz((s) => s.geo);
	const installed = isStandalone();
	const rate = sampleRate != null ? `${(sampleRate / 1e3).toFixed(1)}` : "44.1";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "pointer-events-none absolute inset-x-0 top-0 z-30 flex items-center justify-between gap-2 px-3 pt-[max(0.4rem,env(safe-area-inset-top))]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "pointer-events-none min-w-0 truncate font-mono text-[0.65rem] tracking-wide text-subtle",
			children: [
				"CORE ",
				"0.9",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-2 text-border-strong",
					children: "·"
				}),
				analogOn ? "analog" : "dry",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-2 text-border-strong",
					children: "·"
				}),
				rate,
				" kHz",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-2 text-border-strong",
					children: "·"
				}),
				isLicensed(license.plan) ? license.plan : "demo",
				geo?.countryCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-2 text-border-strong",
					children: "·"
				}), geo.countryCode] }) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex shrink-0 items-center gap-1",
			children: [
				canInstall && !installed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: onInstall,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Install"]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					"aria-pressed": civilOpen,
					onClick: () => {
						const next = !civilOpen;
						setCivilOpen(next);
						if (next) setStoreOpen(false);
					},
					className: cn(civilOpen && "bg-fg/10 text-fg"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {}), "Civil"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					"aria-pressed": storeOpen,
					onClick: () => {
						const next = !storeOpen;
						setStoreOpen(next);
						if (next) setCivilOpen(false);
					},
					className: cn(storeOpen && "bg-fg/10 text-fg"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {}), "License"]
				})
			]
		})]
	});
}
function LicenseDesk() {
	const open = useViz((s) => s.storeOpen);
	const setStoreOpen = useViz((s) => s.setStoreOpen);
	const license = useViz((s) => s.license);
	const setLicense = useViz((s) => s.setLicense);
	const [key, setKey] = (0, import_react.useState)("");
	const [msg, setMsg] = (0, import_react.useState)(null);
	if (!open) return null;
	const licensed = isLicensed(license.plan);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "absolute top-12 right-0 z-30 w-full max-w-sm p-3 sm:top-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface/95 p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase",
								children: "License"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display mt-2 text-2xl font-semibold tracking-[-0.04em]",
								children: "AURA CORE"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: "Installable kernel. Analog 44.1 path. Same bit format. Clean exports without a demo stamp."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Close license",
						onClick: () => setStoreOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-display text-3xl font-semibold",
					children: CORE_PRICE
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-subtle",
					children: "one-time · CORE studio seat"
				}),
				licensed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 rounded-lg bg-fg/10 px-3 py-2 text-sm text-fg",
					children: [
						"Licensed · ",
						license.plan,
						" · ",
						license.key
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: CHECKOUT_URL,
						target: "_blank",
						rel: "noreferrer",
						className: "mt-4 inline-flex h-11 w-full items-center justify-center rounded-lg bg-fg text-sm font-medium text-bg hover:opacity-90",
						children: "Buy CORE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "mt-2 w-full",
						onClick: () => {
							const next = redeemKey("CORE-1900");
							if (next) {
								setLicense(next);
								setMsg("Tonight’s launch seat is active.");
							}
						},
						children: "Unlock tonight"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-4 block text-xs font-medium tracking-wide text-subtle uppercase",
						children: "License key"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: key,
						onChange: (e) => setKey(e.target.value),
						placeholder: "CORE-1900",
						className: "mt-1 h-11 w-full rounded-lg bg-surface-2 px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none focus-visible:ring-2 focus-visible:ring-fg/40",
						"aria-label": "License key"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "mt-2 w-full",
						onClick: () => {
							const next = redeemKey(key);
							if (!next) {
								setMsg("That key is not valid.");
								return;
							}
							setLicense(next);
							setMsg("Seat unlocked.");
						},
						children: "Redeem"
					}),
					msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: msg
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs leading-relaxed text-subtle",
						children: "Tonight’s launch key is CORE-1900. After checkout, redeem the key from the receipt."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: GITHUB_REPO,
					target: "_blank",
					rel: "noreferrer",
					className: "mt-4 inline-block text-xs text-muted underline-offset-2 hover:text-fg hover:underline",
					children: "Source on GitHub"
				})
			]
		})
	});
}
function LyricsOverlay() {
	const text = useViz((s) => s.overlayText);
	if (!text.trim()) return null;
	const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).slice(0, 8);
	if (!lines.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-x-0 bottom-24 z-10 flex justify-center px-6 sm:bottom-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-xl text-center font-display text-sm leading-relaxed text-fg/90 text-balance sm:text-base",
			children: lines.join(" · ")
		})
	});
}
var ACCEPT = "audio/*,video/*,image/*,text/plain,.mp3,.wav,.ogg,.flac,.fl,.m4a,.aac,.mp4,.webm,.mov,.m4v,.jpg,.jpeg,.png,.webp,.gif,.svg,.txt,.lrc,.md,.json,.srt,.csv,.aura.json";
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "audio",
		label: "Audio"
	},
	{
		id: "image",
		label: "Image"
	},
	{
		id: "video",
		label: "Video"
	},
	{
		id: "text",
		label: "Text"
	}
];
function MediaLibrary({ onPlayItem, onExportFrame, onExportProject, onImportFiles }) {
	const open = useViz((s) => s.libraryOpen);
	const setLibraryOpen = useViz((s) => s.setLibraryOpen);
	const items = useLibrary((s) => s.items);
	const backdropId = useLibrary((s) => s.backdropId);
	const lyricsId = useLibrary((s) => s.lyricsId);
	const remove = useLibrary((s) => s.remove);
	const setBackdrop = useLibrary((s) => s.setBackdrop);
	const setLyrics = useLibrary((s) => s.setLyrics);
	const setOverlayText = useViz((s) => s.setOverlayText);
	const inputRef = (0, import_react.useRef)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const visible = (0, import_react.useMemo)(() => filter === "all" ? items : items.filter((i) => i.kind === filter), [filter, items]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") setLibraryOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [open, setLibraryOpen]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "absolute top-0 right-0 z-30 flex h-full w-full max-w-sm flex-col bg-surface/95 p-3 pt-[max(0.75rem,env(safe-area-inset-top))] shadow-[var(--shadow-border)] sm:m-3 sm:h-auto sm:max-h-[min(34rem,calc(100dvh-6rem))] sm:rounded-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs font-medium tracking-[0.18em] text-subtle uppercase",
						children: "Library"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate text-sm text-muted",
						children: "Import a track, still, clip, or text."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon-sm",
					"aria-label": "Close library",
					onClick: () => setLibraryOpen(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "solid",
						size: "sm",
						className: "flex-1",
						onClick: () => inputRef.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), "Import"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						size: "sm",
						onClick: onExportFrame,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Frame"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: onExportProject,
						children: "Project"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex gap-1",
				role: "tablist",
				"aria-label": "Media type",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": filter === f.id,
					onClick: () => setFilter(f.id),
					className: cn("h-9 flex-1 rounded-md text-xs font-medium", filter === f.id ? "bg-fg/10 text-fg" : "text-muted hover:text-fg"),
					children: f.label
				}, f.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 min-h-0 flex-1 space-y-1 overflow-y-auto",
				children: visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-1 py-6 text-center text-sm text-muted",
					children: "Nothing here yet. Import a file or drop it on the stage."
				}) : visible.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cn("flex items-center gap-2 rounded-lg px-2 py-1.5", backdropId === item.id || lyricsId === item.id ? "bg-fg/10" : "hover:bg-fg/5"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindIcon, { kind: item.kind }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "min-w-0 flex-1 text-left",
							onClick: () => {
								if (item.kind === "audio" || item.kind === "video") onPlayItem(item);
								else if (item.kind === "image") setBackdrop(item.id);
								else useLibrary.getState().readText(item).then((t) => {
									setOverlayText(t);
									setLyrics(item.id);
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium text-fg",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-subtle",
								children: [
									item.kind,
									" · ",
									formatBytes(item.size)
								]
							})]
						}),
						!item.builtin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": `Remove ${item.name}`,
							onClick: () => void remove(item.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
						}) : null
					]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				multiple: true,
				accept: ACCEPT,
				className: "hidden",
				onChange: (e) => {
					const list = e.target.files;
					if (list?.length) onImportFiles(Array.from(list));
					e.target.value = "";
				}
			})
		]
	});
}
function KindIcon({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex size-9 shrink-0 items-center justify-center rounded-md bg-surface-2 text-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(kind === "audio" ? Music : kind === "video" ? Film : kind === "text" ? FileText : Image$1, { className: "size-4" })
	});
}
function StartPanel({ onMic, onFile, onDemo, onLibrary }) {
	const error = useViz((s) => s.error);
	const source = useViz((s) => s.source);
	const notesOpen = useViz((s) => s.notesOpen);
	const libraryOpen = useViz((s) => s.libraryOpen);
	const storeOpen = useViz((s) => s.storeOpen);
	const civilOpen = useViz((s) => s.civilOpen);
	const booting = useViz((s) => s.booting);
	const setNotesOpen = useViz((s) => s.setNotesOpen);
	const setStoreOpen = useViz((s) => s.setStoreOpen);
	if (source !== "none") return null;
	if (booting || notesOpen || libraryOpen || storeOpen || civilOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 z-10 flex items-center justify-center p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto w-full max-w-md rounded-2xl bg-surface/90 p-6 text-center shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs font-medium tracking-[0.22em] text-muted uppercase",
					children: "CORE 0.9"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-3 text-4xl font-semibold tracking-[-0.04em] text-fg text-balance sm:text-5xl",
					children: "AURA"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-3 max-w-sm text-sm leading-relaxed text-muted text-pretty",
					children: "Analog kernel. Install it. Import a track. Same bit format out."
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-danger",
					role: "alert",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-col gap-2 min-[520px]:grid min-[520px]:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "solid",
							onClick: onMic,
							className: "w-full rounded-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {}), "Microphone"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							onClick: onFile,
							className: "w-full rounded-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), "Open track"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: onDemo,
							className: "w-full rounded-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, {}), "Play demo"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex flex-col gap-2 min-[520px]:grid min-[520px]:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							className: "w-full",
							onClick: onLibrary,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, {}), "Import"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							className: "w-full",
							onClick: () => setNotesOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {}), "Notes"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "w-full",
							onClick: () => setStoreOpen(true),
							children: "License"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-subtle",
					children: "Install from the kernel bar. L library · E frame · K license."
				})
			]
		})
	});
}
var IMPORT_ACCEPT = "audio/*,video/*,image/*,text/plain,.mp3,.wav,.ogg,.flac,.fl,.m4a,.aac,.mp4,.webm,.mov,.m4v,.jpg,.jpeg,.png,.webp,.gif,.svg,.txt,.lrc,.md,.json,.srt,.csv,.aura.json";
function AuraApp() {
	const engineRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const rootRef = (0, import_react.useRef)(null);
	const canvasOut = (0, import_react.useRef)(null);
	const hideTimer = (0, import_react.useRef)(0);
	const installRef = (0, import_react.useRef)(null);
	const [canInstall, setCanInstall] = (0, import_react.useState)(true);
	const source = useViz((s) => s.source);
	const volume = useViz((s) => s.volume);
	const analogOn = useViz((s) => s.analogOn);
	const hydrate = useViz((s) => s.hydrate);
	const setSource = useViz((s) => s.setSource);
	const setPlaying = useViz((s) => s.setPlaying);
	const setFileMeta = useViz((s) => s.setFileMeta);
	const setCurrentTime = useViz((s) => s.setCurrentTime);
	const setError = useViz((s) => s.setError);
	const setFullscreen = useViz((s) => s.setFullscreen);
	const setControlsOpen = useViz((s) => s.setControlsOpen);
	const setDragging = useViz((s) => s.setDragging);
	const setVolume = useViz((s) => s.setVolume);
	const setAnalogOn = useViz((s) => s.setAnalogOn);
	const setAnalyzing = useViz((s) => s.setAnalyzing);
	const setTrackReport = useViz((s) => s.setTrackReport);
	const clearTrackReport = useViz((s) => s.clearTrackReport);
	const setLibraryOpen = useViz((s) => s.setLibraryOpen);
	const setOverlayText = useViz((s) => s.setOverlayText);
	(0, import_react.useEffect)(() => {
		hydrate();
		useLibrary.getState().hydrate();
		const engine = new AudioEngine();
		engineRef.current = engine;
		return () => {
			engine.dispose();
			engineRef.current = null;
		};
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const engine = engineRef.current;
		if (!engine) return;
		if (useViz.getState().source === "mic") return;
		engine.setVolume(volume);
	}, [volume]);
	(0, import_react.useEffect)(() => {
		engineRef.current?.setAnalog(analogOn);
	}, [analogOn]);
	const bumpControls = (0, import_react.useCallback)(() => {
		setControlsOpen(true);
		window.clearTimeout(hideTimer.current);
		if (useViz.getState().source === "none") return;
		hideTimer.current = window.setTimeout(() => {
			if (useViz.getState().source !== "none") setControlsOpen(false);
		}, 3200);
	}, [setControlsOpen]);
	(0, import_react.useEffect)(() => {
		if (source === "none") setControlsOpen(true);
		else bumpControls();
	}, [
		source,
		bumpControls,
		setControlsOpen
	]);
	const runAnalysis = (0, import_react.useCallback)(async (file) => {
		const engine = engineRef.current;
		if (!engine?.ctx) return;
		setAnalyzing(true);
		try {
			const report = await analyzeTrack(engine.ctx, file);
			engine.applyCurve(report.curve);
			setTrackReport({
				genre: report.genreLabel,
				bpm: report.bpm,
				curveComment: report.curve.comment,
				sampleRate: engine.sampleRate,
				channels: report.channels,
				bitLabel: report.bitLabel,
				spectrum: report.spectrum
			});
		} catch {
			engine.applyCurve(ANALOG_CURVES.pop);
			setTrackReport({
				genre: "Pop",
				bpm: 120,
				curveComment: ANALOG_CURVES.pop.comment,
				sampleRate: engine.sampleRate,
				channels: 2,
				bitLabel: "32-bit float path · source format preserved",
				spectrum: []
			});
		}
	}, [setAnalyzing, setTrackReport]);
	const onMic = (0, import_react.useCallback)(async () => {
		setError(null);
		try {
			const engine = engineRef.current;
			if (!engine) return;
			await engine.unlock();
			engine.setAnalog(useViz.getState().analogOn);
			await engine.startMic();
			engine.setVolume(0);
			setSource("mic");
			setPlaying(true);
			setFileMeta(null, 0);
			setCurrentTime(0);
			clearTrackReport();
		} catch {
			setError("Microphone permission was denied or is unavailable.");
		}
	}, [
		clearTrackReport,
		setCurrentTime,
		setError,
		setFileMeta,
		setPlaying,
		setSource
	]);
	const playFile = (0, import_react.useCallback)(async (file) => {
		setError(null);
		try {
			const engine = engineRef.current;
			if (!engine) return;
			await engine.unlock();
			engine.setAnalog(useViz.getState().analogOn);
			const el = await engine.startFile(file);
			engine.setVolume(useViz.getState().volume);
			setSource("file");
			setPlaying(true);
			setFileMeta(file.name, Number.isFinite(el.duration) ? el.duration : 0);
			setCurrentTime(0);
			el.onloadedmetadata = () => {
				setFileMeta(file.name, el.duration || 0);
			};
			el.onended = () => {
				setPlaying(false);
			};
			runAnalysis(file);
		} catch {
			setError("Could not play that file. Try another audio or video format.");
		}
	}, [
		runAnalysis,
		setCurrentTime,
		setError,
		setFileMeta,
		setPlaying,
		setSource
	]);
	const playItem = (0, import_react.useCallback)(async (item) => {
		const blob = await useLibrary.getState().blobFor(item);
		if (!blob) {
			setError("That file is no longer in the library.");
			return;
		}
		if (item.kind === "video" || item.kind === "image") useLibrary.getState().setBackdrop(item.id);
		const file = new File([blob], item.name, { type: item.mime || blob.type });
		await playFile(file);
	}, [playFile, setError]);
	const applyProject = (0, import_react.useCallback)((project) => {
		const viz = useViz.getState();
		viz.setTheme(project.theme);
		viz.setMode(project.mode);
		viz.setSensitivity(project.sensitivity);
		viz.setAnalogOn(project.analogOn);
		viz.setVolume(project.volume);
		const lib = useLibrary.getState();
		if (project.backdropName) {
			const hit = lib.items.find((i) => i.name === project.backdropName);
			if (hit) lib.setBackdrop(hit.id);
		}
		if (project.lyricsName) {
			const hit = lib.items.find((i) => i.name === project.lyricsName);
			if (hit) {
				lib.setLyrics(hit.id);
				lib.readText(hit).then(setOverlayText);
			}
		}
	}, [setOverlayText]);
	const ingestFiles = (0, import_react.useCallback)(async (files) => {
		if (!files.length) return;
		setLibraryOpen(true);
		const result = await useLibrary.getState().importFiles(files);
		if (result.project) applyProject(result.project);
		if (result.skipped.length) setError(`Skipped ${result.skipped.slice(0, 3).join(", ")}.`);
		else setError(null);
		const firstSound = result.items.find((i) => i.kind === "audio" || i.kind === "video");
		const firstImage = result.items.find((i) => i.kind === "image");
		const firstText = result.items.find((i) => i.kind === "text");
		if (firstImage) useLibrary.getState().setBackdrop(firstImage.id);
		if (firstText) {
			useLibrary.getState().setLyrics(firstText.id);
			setOverlayText(firstText.text ?? await useLibrary.getState().readText(firstText));
		}
		if (firstSound) await playItem(firstSound);
	}, [
		applyProject,
		playItem,
		setError,
		setLibraryOpen,
		setOverlayText
	]);
	const onFile = (0, import_react.useCallback)(() => {
		fileRef.current?.click();
	}, []);
	const onDemo = (0, import_react.useCallback)(async () => {
		setError(null);
		try {
			const engine = engineRef.current;
			if (!engine) return;
			await engine.unlock();
			engine.setAnalog(useViz.getState().analogOn);
			await engine.startDemo();
			engine.setVolume(useViz.getState().volume);
			setSource("demo");
			setPlaying(true);
			setFileMeta(null, 0);
			setCurrentTime(0);
			setTrackReport({
				genre: "Ambient",
				bpm: 94,
				curveComment: ANALOG_CURVES.ambient.comment,
				sampleRate: engine.sampleRate,
				channels: 2,
				bitLabel: "32-bit float path · source format preserved",
				spectrum: Array.from({ length: 24 }, (_, i) => Math.max(.08, .55 * Math.exp(-((i - 6) * (i - 6)) / 40)))
			});
		} catch {
			setError("Could not start the demo.");
		}
	}, [
		setCurrentTime,
		setError,
		setFileMeta,
		setPlaying,
		setSource,
		setTrackReport
	]);
	const onTogglePlay = (0, import_react.useCallback)(async () => {
		const engine = engineRef.current;
		const state = useViz.getState();
		if (!engine) return;
		if (state.source === "file") {
			if (state.playing) {
				engine.pauseFile();
				setPlaying(false);
			} else {
				await engine.unlock();
				await engine.resumeFile();
				engine.setVolume(state.volume);
				setPlaying(true);
			}
			return;
		}
		if (state.source === "demo") {
			if (state.playing) {
				engine.halt();
				setPlaying(false);
			} else await onDemo();
		}
	}, [onDemo, setPlaying]);
	const onSeek = (0, import_react.useCallback)((time) => {
		engineRef.current?.seek(time);
		setCurrentTime(time);
	}, [setCurrentTime]);
	const onFullscreen = (0, import_react.useCallback)(async () => {
		const root = rootRef.current;
		if (!root) return;
		try {
			if (document.fullscreenElement) await document.exitFullscreen();
			else await root.requestFullscreen();
		} catch {
			setError("Fullscreen is not available here.");
		}
	}, [setError]);
	const onToggleAnalog = (0, import_react.useCallback)(() => {
		const next = !useViz.getState().analogOn;
		setAnalogOn(next);
		engineRef.current?.setAnalog(next);
	}, [setAnalogOn]);
	const exportFrame = (0, import_react.useCallback)(() => {
		const canvas = canvasOut.current;
		if (!canvas) {
			setError("Nothing to export yet.");
			return;
		}
		if (!isLicensed(useViz.getState().license.plan)) {
			const ctx = canvas.getContext("2d");
			if (ctx) {
				ctx.save();
				ctx.fillStyle = "rgba(242,242,243,0.55)";
				ctx.font = "500 14px Outfit, system-ui, sans-serif";
				ctx.fillText("AURA CORE demo", 18, canvas.height - 22);
				ctx.restore();
			}
		}
		canvas.toBlob((blob) => {
			if (!blob) {
				setError("Could not export the frame.");
				return;
			}
			downloadBlob(blob, `aura-frame-${Date.now()}.png`);
		}, "image/png");
	}, [setError]);
	const exportProject = (0, import_react.useCallback)(() => {
		const viz = useViz.getState();
		const lib = useLibrary.getState();
		const backdrop = lib.items.find((i) => i.id === lib.backdropId);
		const lyrics = lib.items.find((i) => i.id === lib.lyricsId);
		const project = {
			version: 1,
			kind: "aura-project",
			theme: viz.theme,
			mode: viz.mode,
			sensitivity: viz.sensitivity,
			analogOn: viz.analogOn,
			volume: viz.volume,
			backdropName: backdrop?.name ?? null,
			lyricsName: lyrics?.name ?? null,
			media: lib.items.filter((i) => !i.builtin).map((i) => ({
				name: i.name,
				kind: i.kind,
				mime: i.mime
			}))
		};
		downloadBlob(new Blob([JSON.stringify(project, null, 2)], { type: "application/json" }), "aura-project.json");
	}, []);
	(0, import_react.useEffect)(() => {
		const onChange = () => setFullscreen(Boolean(document.fullscreenElement));
		document.addEventListener("fullscreenchange", onChange);
		return () => document.removeEventListener("fullscreenchange", onChange);
	}, [setFullscreen]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			if (e.key === " " || e.code === "Space") {
				e.preventDefault();
				onTogglePlay();
			} else if (e.key === "f" || e.key === "F") {
				e.preventDefault();
				onFullscreen();
			} else if (e.key === "m" || e.key === "M") {
				const v = useViz.getState().volume;
				setVolume(v <= .01 ? .72 : 0);
			} else if (e.key === "a" || e.key === "A") onToggleAnalog();
			else if (e.key === "l" || e.key === "L") {
				e.preventDefault();
				setLibraryOpen(!useViz.getState().libraryOpen);
			} else if (e.key === "k" || e.key === "K") {
				e.preventDefault();
				const openStore = !useViz.getState().storeOpen;
				useViz.getState().setStoreOpen(openStore);
				if (openStore) useViz.getState().setCivilOpen(false);
			} else if (e.key === "g" || e.key === "G") {
				e.preventDefault();
				const openCivil = !useViz.getState().civilOpen;
				useViz.getState().setCivilOpen(openCivil);
				if (openCivil) useViz.getState().setStoreOpen(false);
			} else if (e.key === "e" || e.key === "E") {
				e.preventDefault();
				exportFrame();
			} else if (e.key === "1") useViz.getState().setMode("bars");
			else if (e.key === "2") useViz.getState().setMode("ring");
			else if (e.key === "3") useViz.getState().setMode("wave");
			else if (e.key === "4") useViz.getState().setMode("bloom");
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		exportFrame,
		onFullscreen,
		onToggleAnalog,
		onTogglePlay,
		setLibraryOpen,
		setVolume
	]);
	(0, import_react.useEffect)(() => {
		const root = rootRef.current;
		if (!root) return;
		const onOver = (e) => {
			e.preventDefault();
			if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
			setDragging(true);
		};
		const onLeave = (e) => {
			if (e.currentTarget === root && !root.contains(e.relatedTarget)) setDragging(false);
		};
		const onDrop = (e) => {
			e.preventDefault();
			setDragging(false);
			const files = e.dataTransfer?.files;
			if (files?.length) ingestFiles(Array.from(files));
		};
		root.addEventListener("dragover", onOver);
		root.addEventListener("dragleave", onLeave);
		root.addEventListener("drop", onDrop);
		return () => {
			root.removeEventListener("dragover", onOver);
			root.removeEventListener("dragleave", onLeave);
			root.removeEventListener("drop", onDrop);
		};
	}, [ingestFiles, setDragging]);
	const onInstall = (0, import_react.useCallback)(async () => {
		const pending = installRef.current;
		if (pending) try {
			await pending.prompt();
			installRef.current = null;
			setCanInstall(false);
			return;
		} catch {}
		window.location.assign("?install=1");
	}, []);
	(0, import_react.useEffect)(() => {
		const onPrompt = (event) => {
			event.preventDefault();
			installRef.current = event;
			setCanInstall(true);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		return () => window.removeEventListener("beforeinstallprompt", onPrompt);
	}, []);
	const dragging = useViz((s) => s.dragging);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: rootRef,
		id: "aura-root",
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		onPointerMove: bumpControls,
		onPointerDown: bumpControls,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasStage, {
				engineRef,
				canvasOut
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KernelBar, {
				onInstall,
				canInstall
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StartPanel, {
				onMic,
				onFile,
				onDemo,
				onLibrary: () => {
					setLibraryOpen(true);
					fileRef.current?.click();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalogDesk, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CivilDoor, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LyricsOverlay, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldNotes, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LicenseDesk, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaLibrary, {
				onPlayItem: (item) => void playItem(item),
				onExportFrame: exportFrame,
				onExportProject: exportProject,
				onImportFiles: (files) => void ingestFiles(files)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlDock, {
				onMic,
				onFile,
				onDemo,
				onTogglePlay: () => void onTogglePlay(),
				onSeek,
				onFullscreen: () => void onFullscreen(),
				onToggleAnalog,
				onLibrary: () => setLibraryOpen(!useViz.getState().libraryOpen)
			}),
			dragging ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-30 flex items-center justify-center bg-bg/55",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-xl bg-surface px-6 py-3 text-sm font-medium text-fg shadow-[var(--shadow-border)]",
					children: "Drop to import"
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				multiple: true,
				accept: IMPORT_ACCEPT,
				className: "hidden",
				onChange: (e) => {
					const list = e.target.files;
					if (list?.length) ingestFiles(Array.from(list));
					e.target.value = "";
				}
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuraApp, {});
}
//#endregion
export { Home as component };
