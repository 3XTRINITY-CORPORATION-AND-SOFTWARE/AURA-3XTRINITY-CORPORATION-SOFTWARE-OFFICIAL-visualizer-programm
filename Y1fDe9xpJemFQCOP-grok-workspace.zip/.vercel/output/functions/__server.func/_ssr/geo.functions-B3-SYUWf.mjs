import { n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/geo.functions-B3-SYUWf.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var FIELDS = "status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query,proxy,hosting,mobile";
function asQuery(raw) {
	const value = raw.trim();
	if (!value) return "";
	if (value.length > 253) return "";
	if (value.includes("://") || value.includes("/")) return "";
	if (/^[0-9a-fA-F:.]+$/.test(value) && (value.includes(".") || value.includes(":"))) return value;
	if (/^[a-zA-Z0-9][a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value)) return value;
	return "";
}
function isPublicIp(value) {
	const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(value);
	if (v4) {
		const oct = v4.slice(1).map(Number);
		if (oct.some((n) => n > 255)) return false;
		const a = oct[0];
		const b = oct[1];
		if (a === 0 || a === 10 || a === 127) return false;
		if (a === 169 && b === 254) return false;
		if (a === 192 && b === 168) return false;
		if (a === 172 && b >= 16 && b <= 31) return false;
		return true;
	}
	if (value.includes(":")) {
		const lower = value.toLowerCase();
		if (lower === "::1" || lower.startsWith("::ffff:127.")) return false;
		if (lower.startsWith("fc") || lower.startsWith("fd")) return false;
		if (lower.startsWith("fe80:")) return false;
		return true;
	}
	return false;
}
function toMask(data, remaining, ttl) {
	return {
		status: "success",
		country: String(data.country ?? ""),
		countryCode: String(data.countryCode ?? ""),
		region: String(data.region ?? ""),
		regionName: String(data.regionName ?? ""),
		city: String(data.city ?? ""),
		zip: String(data.zip ?? ""),
		lat: typeof data.lat === "number" ? data.lat : null,
		lon: typeof data.lon === "number" ? data.lon : null,
		timezone: String(data.timezone ?? ""),
		isp: String(data.isp ?? ""),
		org: String(data.org ?? ""),
		as: String(data.as ?? ""),
		query: String(data.query ?? ""),
		proxy: Boolean(data.proxy),
		hosting: Boolean(data.hosting),
		mobile: Boolean(data.mobile),
		source: "ip-api",
		remaining,
		ttl
	};
}
async function lookup(query) {
	const res = await fetch(`http://ip-api.com/json/${query ? encodeURIComponent(query) : ""}?fields=${FIELDS}&lang=en`, {
		headers: { "User-Agent": "aura-core-civil-door/1.0" },
		signal: AbortSignal.timeout(8e3)
	});
	const remaining = res.headers.get("X-Rl");
	const ttl = res.headers.get("X-Ttl");
	if (res.status === 429 || remaining === "0") return {
		ok: false,
		error: `rate limit · wait ${ttl ?? "60"}s`
	};
	if (!res.ok) return {
		ok: false,
		error: `upstream ${res.status}`
	};
	const data = await res.json();
	if (data.status !== "success") return {
		ok: false,
		error: String(data.message ?? "fail")
	};
	return {
		ok: true,
		geo: toMask(data, remaining, ttl)
	};
}
var probeCivil_createServerFn_handler = createServerRpc({
	id: "1ece0b3480406ffe5afb289a296331a875a52a843bf70c259fb5ee970475471b",
	name: "probeCivil",
	filename: "src/lib/visualizer/geo.functions.ts"
}, (opts) => probeCivil.__executeServer(opts));
var probeCivil = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") return { query: "" };
	const q = input.query;
	return { query: typeof q === "string" ? q : "" };
}).handler(probeCivil_createServerFn_handler, async ({ data }) => {
	try {
		const raw = data.query.trim();
		let query = "";
		if (raw) {
			query = asQuery(raw);
			if (!query) return {
				ok: false,
				error: "invalid query"
			};
		} else try {
			const { getRequestIP } = await import("./ssr.mjs").then((n) => n.a).then((n) => n.t);
			const seen = asQuery(getRequestIP({ xForwardedFor: true }) ?? "");
			query = seen && isPublicIp(seen) ? seen : "";
		} catch {
			query = "";
		}
		return await lookup(query);
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "upstream failed"
		};
	}
});
//#endregion
export { probeCivil_createServerFn_handler };
